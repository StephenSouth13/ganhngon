<?php
if (!defined('ABSPATH')) exit;

require_once get_template_directory() . '/inc/i18n.php';
require_once get_template_directory() . '/inc/ops.php';
require_once get_template_directory() . '/inc/advisor.php';

function gn_theme_setup() {
    add_theme_support('post-thumbnails');
    add_theme_support('title-tag');
    add_theme_support('custom-logo');
    add_theme_support('automatic-feed-links');
    add_theme_support('html5', ['search-form','comment-form','comment-list','gallery','caption']);
    register_nav_menus([
        'primary' => __('Primary Menu', 'ganhngon-restaurant'),
        'footer'  => __('Footer Menu', 'ganhngon-restaurant'),
    ]);
}
add_action('after_setup_theme', 'gn_theme_setup');

function gn_theme_scripts() {
    wp_enqueue_style('gn-fonts', 'https://fonts.googleapis.com/css2?family=Playfair+Display:wght@500;600;700&family=Be+Vietnam+Pro:ital,wght@0,300;0,400;0,500;0,600;0,700;1,400&family=Open+Sans:wght@400;500;600;700&display=swap', [], null);
    wp_enqueue_style('gn-style', get_stylesheet_uri(), [], '4.7.0');
    wp_enqueue_script('gn-main', get_template_directory_uri() . '/assets/main.js', [], '4.7.0', true);
}
add_action('wp_enqueue_scripts', 'gn_theme_scripts');

// Render homepage sections on language-root URLs (/en/ /zh/ ...) which Polylang
// shows as blog-home. Forces the translated front-page layout for all languages.
add_action('template_redirect', function () {
    if (is_admin()) return;
    if (gn_cur_lang() === 'vi') return;          // VI uses normal front-page.php
    if (!is_home() && !is_front_page()) return;  // only the language root
    // Avoid intercepting real blog archives (paged, category, etc.)
    if (is_paged() || is_archive() || is_search() || is_singular()) return;

    status_header(200);
    get_header();
    foreach (['hero','menu','location','reservation','about','customer-types','gallery','testimonials','faq'] as $s) {
        get_template_part('template-parts/section-' . $s);
    }
    get_footer();
    exit;
}, 1);

// Force front-page template for translated home-* pages (if accessed directly)
add_filter('template_include', function ($t) {
    if (is_page() && preg_match('/^home-(en|zh|ko|ru|ar)$/', get_post_field('post_name', get_the_ID()))) {
        $fp = locate_template('front-page.php');
        if ($fp) return $fp;
    }
    return $t;
}, 99);

// Disable wpautop on pages whose content is hand-built HTML (grids/forms).
// wpautop injects <br>/<p> that become extra CSS-grid items and break layout.
add_action('wp', function () {
    $raw_html_pages = ['dat-ban', 'khach-doan-tiec-rieng', 'ai-tu-van', 'doi-tac', 'cong-doi-tac'];
    if (is_page($raw_html_pages) || (function_exists('gn_is_advisor_page') && gn_is_advisor_page())) {
        remove_filter('the_content', 'wpautop');
        remove_filter('the_content', 'shortcode_unautop');
    }
});

// Polylang-aware: get translated page URL by Vietnamese slug
function gn_page_url($vi_slug) {
    if ($vi_slug === '') return gn_home('/');
    $lang = gn_cur_lang();
    $vi_post = get_page_by_path($vi_slug);
    if ($vi_post && $lang !== 'vi' && function_exists('pll_get_post')) {
        $tid = pll_get_post($vi_post->ID, $lang);
        if ($tid) return get_permalink($tid);
    }
    if ($vi_post) return get_permalink($vi_post->ID);
    return gn_home('/' . $vi_slug . '/');
}

function gn_default_menu() {
    $items = [
        ''                        => gn_t('nav_home'),
        've-ganh-ngon'            => gn_t('nav_about'),
        'thuc-don'                => gn_t('nav_menu'),
        'dat-ban'                 => gn_t('nav_book'),
        'khach-doan-tiec-rieng'   => gn_t('nav_groups'),
        'lien-he'                 => gn_t('nav_contact'),
    ];
    $current = rtrim($_SERVER['REQUEST_URI'] ?? '/', '/');
    foreach ($items as $slug => $label) {
        $url = gn_page_url($slug);
        $path = rtrim(parse_url($url, PHP_URL_PATH), '/');
        $active = ($current === $path) ? ' active' : '';
        echo '<a class="' . esc_attr(trim($active)) . '" href="' . esc_url($url) . '">' . esc_html($label) . '</a>';
    }
}

// Language switcher — clean dropdown (closed by default, JS toggle)
function gn_lang_switcher() {
    $flags = ['vi'=>'🇻🇳','en'=>'🇬🇧','zh'=>'🇨🇳','ko'=>'🇰🇷','ru'=>'🇷🇺','ar'=>'🇸🇦'];
    $names = ['vi'=>'Tiếng Việt','en'=>'English','zh'=>'中文','ko'=>'한국어','ru'=>'Русский','ar'=>'العربية'];
    $cur = gn_cur_lang();

    // Build language list (Polylang if available, else static)
    $items = [];
    if (function_exists('pll_the_languages')) {
        $langs = pll_the_languages(['raw' => 1, 'hide_if_empty' => 0]);
        foreach ($langs as $l) {
            $items[$l['slug']] = $l['url'];
        }
    }
    if (empty($items)) {
        foreach (['vi'=>'/','en'=>'/en/','zh'=>'/zh/','ko'=>'/ko/','ru'=>'/ru/','ar'=>'/ar/'] as $s=>$u) $items[$s] = home_url($u);
    }

    echo '<div class="gn-lang-switch">';
    echo '<button class="gn-lang-current" type="button" aria-haspopup="true" aria-expanded="false" onclick="gnToggleLang(this)">';
    echo '<span class="flag">' . ($flags[$cur] ?? '🌐') . '</span><span class="code">' . strtoupper($cur) . '</span><span class="caret">▾</span></button>';
    echo '<ul class="gn-lang-dropdown" role="menu">';
    foreach ($items as $slug => $url) {
        $active = ($slug === $cur) ? ' aria-current="true"' : '';
        $cls = ($slug === $cur) ? ' class="active"' : '';
        echo '<li role="none"><a role="menuitem"' . $active . $cls . ' href="' . esc_url($url) . '">';
        echo '<span class="flag">' . ($flags[$slug] ?? '🌐') . '</span> ' . esc_html($names[$slug] ?? strtoupper($slug)) . '</a></li>';
    }
    echo '</ul></div>';
}

function gn_phone_raw()     { return '+84979232233'; }
function gn_phone_display() { return '0979 232 233'; }
function gn_zalo_raw()      { return '2216004914337654583'; }
function gn_whatsapp_raw()  { return '84979232233'; }
function gn_telegram()      { return 'https://t.me/ganhngon'; }
function gn_facebook()      { return 'https://facebook.com/ganhngon'; }
function gn_instagram()     { return 'https://instagram.com/ganhngon'; }
function gn_tiktok()        { return 'https://tiktok.com/@ganhngon'; }
function gn_wechat_id()     { return 'ganhngon'; }
function gn_youtube()       { return ''; } // 2026-06-20: kênh chưa tạo (404) → ẩn
function gn_twitter_x()     { return ''; } // 2026-06-20: kênh chưa tạo (404) → ẩn
function gn_address()       { return '113 Trần Hưng Đạo, Dương Đông, Phú Quốc'; }
function gn_maps_url()      { return 'https://maps.google.com/?q=113+Tran+Hung+Dao+Duong+Dong+Phu+Quoc'; }
function gn_today_ymd() {
    return (new DateTime('now', new DateTimeZone('Asia/Ho_Chi_Minh')))->format('Y-m-d');
}
function gn_hours_short()   { return function_exists('gn_t') ? gn_t('hours_clock') : 'Mở cửa hằng ngày 6:30–2:00'; }
function gn_tagline_vi()    { return 'Đặc sản Việt Nam. Không gian sang trọng. Trải nghiệm đáng nhớ.'; }
function gn_tagline_en()    { return 'Vietnamese Flavors. Elegant Dining. Memorable Moments.'; }

// Social icons rendered as inline SVG (no external deps)
function gn_social_icons($size = 24, $color = 'currentColor') {
    return [
        'zalo' => [
            'href'  => 'https://zalo.me/' . gn_zalo_raw(),
            'label' => 'Zalo',
            'svg'   => '<svg width="'.$size.'" height="'.$size.'" viewBox="0 0 24 24" fill="'.esc_attr($color).'"><path d="M12 2C6.477 2 2 5.91 2 10.73c0 2.74 1.46 5.18 3.74 6.78-.12.98-.5 2.26-1.04 3.13-.13.21.04.48.28.43 1.78-.38 3.2-1.1 4.1-1.67.93.21 1.9.33 2.92.33 5.523 0 10-3.91 10-8.73S17.523 2 12 2zm-3.05 10.5H7.2a.5.5 0 0 1-.4-.8l1.9-2.6H7.3a.5.5 0 0 1 0-1h2.05a.5.5 0 0 1 .4.8l-1.9 2.6h1.1a.5.5 0 0 1 0 1zm2.3-.5a.5.5 0 0 1-1 0V9a.5.5 0 0 1 1 0v3zm3.2.5a.5.5 0 0 1-.4-.2 1.7 1.7 0 0 1-.9.25 1.75 1.75 0 1 1 0-3.5c.33 0 .64.09.9.25a.5.5 0 0 1 .9.3v2.4a.5.5 0 0 1-.5.5zm2.55 0a.5.5 0 0 1-.5-.5V8.5a.5.5 0 0 1 1 0V12a.5.5 0 0 1-.5.5z"/></svg>'
        ],
        'whatsapp' => [
            'href'  => 'https://wa.me/' . gn_whatsapp_raw(),
            'label' => 'WhatsApp',
            'svg'   => '<svg width="'.$size.'" height="'.$size.'" viewBox="0 0 24 24" fill="'.esc_attr($color).'"><path d="M17.472 14.382c-.297-.149-1.758-.867-2.03-.967-.273-.099-.471-.148-.67.15-.197.297-.767.966-.94 1.164-.173.199-.347.223-.644.075-.297-.15-1.255-.463-2.39-1.475-.883-.788-1.48-1.761-1.653-2.059-.173-.297-.018-.458.13-.606.134-.133.298-.347.446-.52.149-.174.198-.298.298-.497.099-.198.05-.371-.025-.52-.075-.149-.669-1.612-.916-2.207-.242-.579-.487-.5-.669-.51l-.57-.01c-.198 0-.52.074-.792.372-.272.297-1.04 1.016-1.04 2.479 0 1.462 1.065 2.875 1.213 3.074.149.198 2.096 3.2 5.077 4.487.709.306 1.262.489 1.694.625.712.227 1.36.195 1.871.118.571-.085 1.758-.719 2.006-1.413.248-.694.248-1.289.173-1.413-.074-.124-.272-.198-.57-.347m-5.421 7.403h-.004a9.87 9.87 0 01-5.031-1.378l-.361-.214-3.741.982.998-3.648-.235-.374a9.86 9.86 0 01-1.51-5.26c.001-5.45 4.436-9.884 9.888-9.884 2.64 0 5.122 1.03 6.988 2.898a9.825 9.825 0 012.893 6.994c-.003 5.45-4.437 9.884-9.885 9.884m8.413-18.297A11.815 11.815 0 0012.05 0C5.495 0 .16 5.335.157 11.892c0 2.096.547 4.142 1.588 5.945L.057 24l6.305-1.654a11.882 11.882 0 005.683 1.448h.005c6.554 0 11.89-5.335 11.893-11.893a11.821 11.821 0 00-3.48-8.413"/></svg>'
        ],
        'facebook' => [
            'href'  => gn_facebook(),
            'label' => 'Facebook',
            'svg'   => '<svg width="'.$size.'" height="'.$size.'" viewBox="0 0 24 24" fill="'.esc_attr($color).'"><path d="M24 12.073c0-6.627-5.373-12-12-12s-12 5.373-12 12c0 5.99 4.388 10.954 10.125 11.854v-8.385H7.078v-3.47h3.047V9.43c0-3.007 1.792-4.669 4.533-4.669 1.312 0 2.686.235 2.686.235v2.953H15.83c-1.491 0-1.956.925-1.956 1.874v2.25h3.328l-.532 3.47h-2.796v8.385C19.612 23.027 24 18.062 24 12.073z"/></svg>'
        ],
        'instagram' => [
            'href'  => gn_instagram(),
            'label' => 'Instagram',
            'svg'   => '<svg width="'.$size.'" height="'.$size.'" viewBox="0 0 24 24" fill="'.esc_attr($color).'"><path d="M12 0C8.74 0 8.333.015 7.053.072 5.775.132 4.905.333 4.14.63c-.789.306-1.459.717-2.126 1.384S.935 3.35.63 4.14C.333 4.905.131 5.775.072 7.053.012 8.333 0 8.74 0 12s.015 3.667.072 4.947c.06 1.277.261 2.148.558 2.913.306.788.717 1.459 1.384 2.126.667.666 1.336 1.079 2.126 1.384.766.296 1.636.499 2.913.558C8.333 23.988 8.74 24 12 24s3.667-.015 4.947-.072c1.277-.06 2.148-.262 2.913-.558.788-.306 1.459-.718 2.126-1.384.666-.667 1.079-1.335 1.384-2.126.296-.765.499-1.636.558-2.913.06-1.28.072-1.687.072-4.947s-.015-3.667-.072-4.947c-.06-1.277-.262-2.149-.558-2.913-.306-.789-.718-1.459-1.384-2.126C21.319 1.347 20.651.935 19.86.63c-.765-.297-1.636-.499-2.913-.558C15.667.012 15.26 0 12 0zm0 2.16c3.203 0 3.585.016 4.85.071 1.17.055 1.805.249 2.227.415.562.217.96.477 1.382.896.419.42.679.819.896 1.381.164.422.36 1.057.413 2.227.057 1.266.07 1.646.07 4.85s-.015 3.585-.074 4.85c-.061 1.17-.256 1.805-.421 2.227-.224.562-.479.96-.897 1.382-.419.419-.824.679-1.38.896-.42.164-1.065.36-2.235.413-1.274.057-1.649.07-4.859.07-3.211 0-3.586-.015-4.859-.074-1.171-.061-1.816-.256-2.236-.421-.569-.224-.96-.479-1.379-.897-.421-.419-.69-.824-.9-1.38-.165-.42-.359-1.065-.42-2.235-.045-1.26-.061-1.649-.061-4.844 0-3.196.016-3.586.061-4.861.061-1.17.255-1.814.42-2.234.21-.57.479-.96.9-1.381.419-.419.81-.689 1.379-.898.42-.166 1.051-.361 2.221-.421 1.275-.045 1.65-.06 4.859-.06l.045.03zm0 3.678c-3.405 0-6.162 2.76-6.162 6.162 0 3.405 2.76 6.162 6.162 6.162 3.405 0 6.162-2.76 6.162-6.162 0-3.405-2.76-6.162-6.162-6.162zM12 16c-2.21 0-4-1.79-4-4s1.79-4 4-4 4 1.79 4 4-1.79 4-4 4zm7.846-10.405c0 .795-.646 1.44-1.44 1.44-.795 0-1.44-.646-1.44-1.44 0-.794.646-1.439 1.44-1.439.793-.001 1.44.645 1.44 1.439z"/></svg>'
        ],
        'telegram' => [
            'href'  => gn_telegram(),
            'label' => 'Telegram',
            'svg'   => '<svg width="'.$size.'" height="'.$size.'" viewBox="0 0 24 24" fill="'.esc_attr($color).'"><path d="M12 0C5.374 0 0 5.373 0 12s5.374 12 12 12 12-5.373 12-12S18.626 0 12 0zm5.894 8.221l-1.97 9.28c-.145.658-.537.818-1.084.508l-3-2.21-1.446 1.394c-.14.18-.357.295-.6.295-.002 0-.003 0-.005 0l.213-3.054 5.56-5.022c.24-.213-.054-.334-.373-.121l-6.869 4.326-2.96-.924c-.64-.203-.658-.643.135-.953l11.566-4.458c.538-.196 1.006.128.832.941z"/></svg>'
        ],
        'wechat' => [
            'href'  => '#wechat-qr',
            'label' => 'WeChat',
            'svg'   => '<svg width="'.$size.'" height="'.$size.'" viewBox="0 0 24 24" fill="'.esc_attr($color).'"><path fill-rule="evenodd" clip-rule="evenodd" d="M8.691 2.188C3.891 2.188 0 5.476 0 9.53c0 2.212 1.17 4.203 3.002 5.55a.59.59 0 0 1 .213.665l-.39 1.48c-.019.07-.048.141-.048.213 0 .163.13.295.29.295a.327.327 0 0 0 .167-.054l1.903-1.114a.864.864 0 0 1 .717-.098 10.16 10.16 0 0 0 2.837.403c.276 0 .543-.027.811-.05-.857-2.578.157-4.972 1.932-6.446 1.703-1.415 3.882-1.98 5.853-1.838-.576-3.583-4.196-6.348-8.596-6.348zM5.785 5.991c.642 0 1.162.529 1.162 1.18a1.17 1.17 0 0 1-1.162 1.178A1.17 1.17 0 0 1 4.623 7.17c0-.651.52-1.18 1.162-1.18zm5.813 0c.642 0 1.162.529 1.162 1.18a1.17 1.17 0 0 1-1.162 1.178 1.17 1.17 0 0 1-1.162-1.178c0-.651.52-1.18 1.162-1.18zm5.34 2.867c-1.797-.052-3.746.512-5.28 1.786-1.72 1.428-2.687 3.72-1.78 6.22.942 2.453 3.666 4.229 6.884 4.229.826 0 1.622-.12 2.361-.336a.722.722 0 0 1 .598.082l1.584.926a.272.272 0 0 0 .14.047c.134 0 .24-.111.24-.247 0-.06-.023-.12-.038-.177-.005-.02-.327-1.233-.327-1.233a.582.582 0 0 1 .184-.553c1.512-1.06 2.502-2.677 2.502-4.479 0-3.336-3.181-6.041-7.105-6.146-.022.001-.043-.001-.063-.001-.001 0-.001 0 0 0zm-2.213 2.474c.535 0 .967.44.967.981a.972.972 0 0 1-.967.981.972.972 0 0 1-.969-.981c0-.541.434-.981.969-.981zm4.842 0c.534 0 .967.44.967.981a.972.972 0 0 1-.967.981.972.972 0 0 1-.969-.981c0-.541.435-.981.969-.981z"/></svg>'
        ],
        'youtube' => [
            'href'  => gn_youtube(),
            'label' => 'YouTube',
            'svg'   => '<svg width="'.$size.'" height="'.$size.'" viewBox="0 0 24 24" fill="'.esc_attr($color).'"><path d="M23.498 6.186a3.016 3.016 0 0 0-2.122-2.136C19.505 3.545 12 3.545 12 3.545s-7.505 0-9.377.505A3.017 3.017 0 0 0 .502 6.186C0 8.07 0 12 0 12s0 3.93.502 5.814a3.016 3.016 0 0 0 2.122 2.136c1.871.505 9.376.505 9.376.505s7.505 0 9.377-.505a3.015 3.015 0 0 0 2.122-2.136C24 15.93 24 12 24 12s0-3.93-.502-5.814zM9.545 15.568V8.432L15.818 12l-6.273 3.568z"/></svg>'
        ],
        'tiktok' => [
            'href'  => gn_tiktok(),
            'label' => 'TikTok',
            'svg'   => '<svg width="'.$size.'" height="'.$size.'" viewBox="0 0 24 24" fill="'.esc_attr($color).'"><path d="M19.59 6.69a4.83 4.83 0 0 1-3.77-4.25V2h-3.45v13.67a2.89 2.89 0 0 1-5.2 1.74 2.89 2.89 0 0 1 2.31-4.64 2.93 2.93 0 0 1 .88.13V9.4a6.84 6.84 0 0 0-1-.05A6.33 6.33 0 0 0 5.8 20.1a6.34 6.34 0 0 0 10.86-4.43v-7a8.16 8.16 0 0 0 4.77 1.52v-3.4a4.85 4.85 0 0 1-1-.1z"/></svg>'
        ],
        'twitter_x' => [
            'href'  => gn_twitter_x(),
            'label' => 'X (Twitter)',
            'svg'   => '<svg width="'.$size.'" height="'.$size.'" viewBox="0 0 24 24" fill="'.esc_attr($color).'"><path d="M18.244 2.25h3.308l-7.227 8.26 8.502 11.24H16.17l-5.214-6.817L4.99 21.75H1.68l7.73-8.835L1.254 2.25H8.08l4.713 6.231zm-1.161 17.52h1.833L7.084 4.126H5.117z"/></svg>'
        ],
    ];
}

function gn_render_social_row($with_label = true, $size = 22) {
    $socials = gn_social_icons($size);
    echo '<div class="gn-social-row">';
    foreach ($socials as $key => $s) {
        if (empty($s['href'])) continue; // bỏ qua kênh chưa tạo (href rỗng)
        $target = (in_array($key, ['facebook','instagram','telegram','tiktok','youtube'])) ? ' target="_blank" rel="noopener"' : '';
        $extra = ($key === 'wechat') ? ' data-wechat-id="' . esc_attr(gn_wechat_id()) . '" onclick="gnWechatPopup(event)"' : '';
        echo '<a href="' . esc_url($s['href']) . '" class="gn-social-icon gn-social-' . $key . '" aria-label="' . esc_attr($s['label']) . '" title="' . esc_attr($s['label']) . '"' . $target . $extra . '>';
        echo $s['svg'];
        if ($with_label) echo '<span class="gn-social-label">' . esc_html($s['label']) . '</span>';
        echo '</a>';
    }
    echo '</div>';
}

function gn_sticky_bar() {
    if (is_admin()) return;
    ?>
    <div class="gn-sticky-mobile">
      <a href="tel:<?php echo esc_attr(gn_phone_raw()); ?>" class="gn-sticky-item" aria-label="<?php echo esc_attr(gn_t('sticky_call')); ?>"><svg width="22" height="22" viewBox="0 0 24 24" fill="currentColor" aria-hidden="true" focusable="false"><path d="M6.62 10.79a15.05 15.05 0 0 0 6.59 6.59l2.2-2.2a1 1 0 0 1 1.01-.24c1.12.37 2.33.57 3.57.57a1 1 0 0 1 1 1V20a1 1 0 0 1-1 1A17 17 0 0 1 3 4a1 1 0 0 1 1-1h3.5a1 1 0 0 1 1 1c0 1.25.2 2.45.57 3.57a1 1 0 0 1-.25 1.02l-2.2 2.2z"/></svg><span><?php echo esc_html(gn_t('sticky_call')); ?></span></a>
      <a href="https://zalo.me/<?php echo esc_attr(gn_zalo_raw()); ?>" class="gn-sticky-item" aria-label="Zalo"><svg width="22" height="22" viewBox="0 0 24 24" fill="currentColor" aria-hidden="true" focusable="false"><path d="M20 2H4a2 2 0 0 0-2 2v18l4-4h14a2 2 0 0 0 2-2V4a2 2 0 0 0-2-2z"/></svg><span>Zalo</span></a>
      <a href="https://wa.me/<?php echo esc_attr(gn_whatsapp_raw()); ?>" class="gn-sticky-item" aria-label="WhatsApp"><svg width="22" height="22" viewBox="0 0 24 24" fill="currentColor" aria-hidden="true" focusable="false"><path d="M17.472 14.382c-.297-.149-1.758-.867-2.03-.967-.273-.099-.471-.148-.67.15-.197.297-.767.966-.94 1.164-.173.199-.347.223-.644.075-.297-.15-1.255-.463-2.39-1.475-.883-.788-1.48-1.761-1.653-2.059-.173-.297-.018-.458.13-.606.134-.133.298-.347.446-.52.149-.174.198-.298.298-.497.099-.198.05-.371-.025-.52-.075-.149-.669-1.612-.916-2.207-.242-.579-.487-.5-.669-.51l-.57-.01c-.198 0-.52.074-.792.372-.272.297-1.04 1.016-1.04 2.479 0 1.462 1.065 2.875 1.213 3.074.149.198 2.096 3.2 5.077 4.487.709.306 1.262.489 1.694.625.712.227 1.36.195 1.871.118.571-.085 1.758-.719 2.006-1.413.248-.694.248-1.289.173-1.413-.074-.124-.272-.198-.57-.347m-5.421 7.403h-.004a9.87 9.87 0 01-5.031-1.378l-.361-.214-3.741.982.998-3.648-.235-.374a9.86 9.86 0 01-1.51-5.26c.001-5.45 4.436-9.884 9.888-9.884 2.64 0 5.122 1.03 6.988 2.898a9.825 9.825 0 012.893 6.994c-.003 5.45-4.437 9.884-9.885 9.884m8.413-18.297A11.815 11.815 0 0012.05 0C5.495 0 .16 5.335.157 11.892c0 2.096.547 4.142 1.588 5.945L.057 24l6.305-1.654a11.882 11.882 0 005.683 1.448h.005c6.554 0 11.89-5.335 11.893-11.893a11.821 11.821 0 00-3.48-8.413"/></svg><span>WhatsApp</span></a>
      <a href="<?php echo esc_url((is_front_page() || is_home()) ? home_url('/#gn-book-today') : gn_page_url('dat-ban')); ?>" class="gn-sticky-item gn-sticky-cta" aria-label="<?php echo esc_attr(gn_t('sticky_book')); ?>"><svg width="22" height="22" viewBox="0 0 24 24" fill="currentColor" aria-hidden="true" focusable="false"><path d="M19 4h-1V2h-2v2H8V2H6v2H5a2 2 0 0 0-2 2v14a2 2 0 0 0 2 2h14a2 2 0 0 0 2-2V6a2 2 0 0 0-2-2zm0 16H5V9h14v11z"/></svg><span><?php echo esc_html(gn_t('sticky_book')); ?></span></a>
      <a href="<?php echo esc_url(gn_maps_url()); ?>" class="gn-sticky-item" target="_blank" aria-label="<?php echo esc_attr(gn_t('sticky_dir')); ?>"><svg width="22" height="22" viewBox="0 0 24 24" fill="currentColor" aria-hidden="true" focusable="false"><path d="M12 2a7 7 0 0 0-7 7c0 5.25 7 13 7 13s7-7.75 7-13a7 7 0 0 0-7-7zm0 9.5a2.5 2.5 0 1 1 0-5 2.5 2.5 0 0 1 0 5z"/></svg><span><?php echo esc_html(gn_t('sticky_dir')); ?></span></a>
    </div>
    <div id="gn-wechat-modal" class="gn-wechat-modal" hidden>
      <div class="gn-wechat-content">
        <button class="gn-wechat-close" onclick="document.getElementById('gn-wechat-modal').hidden=true">×</button>
        <h3>WeChat — Gánh Ngon</h3>
        <p>Quét QR hoặc tìm ID: <strong><?php echo esc_html(gn_wechat_id()); ?></strong></p>
        <div style="background:#fff;padding:18px;border-radius:8px;display:inline-block">
          <img src="https://api.qrserver.com/v1/create-qr-code/?size=200x200&data=weixin://contacts/profile/<?php echo esc_attr(gn_wechat_id()); ?>" alt="WeChat QR" width="200" height="200">
        </div>
        <p style="margin-top:14px;color:#5A5A5A;font-size:.85rem">Hoặc liên hệ qua WhatsApp / Zalo</p>
      </div>
    </div>
    <script>
    function gnWechatPopup(e){ e.preventDefault(); document.getElementById('gn-wechat-modal').hidden=false; }
    </script>
    <?php
}
add_action('wp_footer', 'gn_sticky_bar', 5);

// ============================================================
// AI Chatbot backend — Ollama (MiniMax M3) primary, DeepSeek fallback
// Config stored in wp_options: gn_ai_ollama_url / gn_ai_ollama_model
//   / gn_ai_deepseek_key / gn_ai_deepseek_model
// ============================================================
function gn_ai_system_prompt() {
    return "Bạn là trợ lý ảo của nhà hàng GÁNH NGON — nhà hàng đặc sản Việt Nam tại 113 Trần Hưng Đạo, Dương Đông, Phú Quốc, Kiên Giang. "
      . "Nhiệm vụ: tư vấn món ăn đặc sản, không gian (bàn thường, phòng VIP, khu gia đình, khu đoàn, tiệc riêng), hỗ trợ đặt bàn, giải đáp giờ mở cửa & dịch vụ. "
      . "QUY TẮC BẮT BUỘC: TUYỆT ĐỐI KHÔNG báo giá món/set menu/phí phòng VIP. Nếu khách hỏi giá, lịch sự mời khách để lại SĐT/Zalo hoặc đặt bàn để tư vấn viên báo giá riêng. "
      . "Hướng khách đặt bàn tại trang /dat-ban/, hoặc Zalo/WhatsApp 0979 232 233, hotline 0979 232 233. "
      . "THÔNG TIN THẬT (chỉ dùng các dữ kiện này, KHÔNG bịa thêm): Giờ mở cửa 6h30 sáng đến 2h sáng hôm sau, tất cả các ngày trong tuần. Có chỗ đậu xe. "
      . "Nếu khách hỏi thông tin chưa được cung cấp (sức chứa cụ thể, món/giá, sự kiện...), KHÔNG tự bịa — lịch sự mời khách liên hệ Zalo/hotline để được tư vấn chính xác. "
      . "Trả lời NGẮN GỌN, thân thiện, đúng ngôn ngữ khách đang dùng (Việt/Anh/Trung/Hàn/Nga/Ả Rập). Nếu không chắc, mời khách liên hệ trực tiếp.";
}
function gn_ai_call_ollama($messages) {
    $url   = trim(get_option('gn_ai_ollama_url', ''));
    $model = trim(get_option('gn_ai_ollama_model', '')) ?: 'minimax-m3';
    if ($url === '') return null;
    $res = wp_remote_post(rtrim($url, '/') . '/api/chat', [
        'timeout' => 25,
        'headers' => ['Content-Type' => 'application/json'],
        'body'    => wp_json_encode(['model' => $model, 'messages' => $messages, 'stream' => false]),
    ]);
    if (is_wp_error($res) || wp_remote_retrieve_response_code($res) !== 200) return null;
    $j = json_decode(wp_remote_retrieve_body($res), true);
    $txt = $j['message']['content'] ?? '';
    return ($txt !== '') ? $txt : null;
}
function gn_ai_call_deepseek($messages) {
    $key   = trim(get_option('gn_ai_deepseek_key', ''));
    $model = trim(get_option('gn_ai_deepseek_model', '')) ?: 'deepseek-chat';
    if ($key === '') return null;
    $res = wp_remote_post('https://api.deepseek.com/chat/completions', [
        'timeout' => 30,
        'headers' => ['Content-Type' => 'application/json', 'Authorization' => 'Bearer ' . $key],
        'body'    => wp_json_encode(['model' => $model, 'messages' => $messages, 'stream' => false, 'temperature' => 0.6]),
    ]);
    if (is_wp_error($res) || wp_remote_retrieve_response_code($res) !== 200) return null;
    $j = json_decode(wp_remote_retrieve_body($res), true);
    return $j['choices'][0]['message']['content'] ?? null;
}
function gn_ai_chat_handler() {
    check_ajax_referer('gn_ai', 'nonce');
    $msg = isset($_POST['message']) ? sanitize_textarea_field(wp_unslash($_POST['message'])) : '';
    if ($msg === '') wp_send_json_error(['reply' => 'Anh/chị vui lòng nhập câu hỏi.']);

    $rk  = 'gn_ai_rl_' . md5($_SERVER['REMOTE_ADDR'] ?? 'x');
    $cnt = (int) get_transient($rk);
    if ($cnt > 30) {
        wp_send_json_success(['reply' => gn_advisor_reply('phone zalo whatsapp', gn_cur_lang()), 'source' => 'rl']);
    }
    set_transient($rk, $cnt + 1, 300);

    $lang = isset($_POST['lang']) ? sanitize_key(wp_unslash($_POST['lang'])) : gn_cur_lang();
    wp_send_json_success(['reply' => gn_advisor_reply($msg, $lang), 'source' => 'advisor']);
}
add_action('wp_ajax_gn_ai_chat', 'gn_ai_chat_handler');
add_action('wp_ajax_nopriv_gn_ai_chat', 'gn_ai_chat_handler');

// ============================================================
// Floating chat launcher — AI concierge + multi-channel
// ============================================================
function gn_chat_widget() {
    if (is_admin()) return;
    $zalo = 'https://zalo.me/' . esc_attr(gn_zalo_raw());
    $wa   = 'https://wa.me/' . esc_attr(gn_whatsapp_raw());
    $mes  = esc_url(gn_facebook());
    $tg   = esc_url(gn_telegram());
    $tel  = 'tel:' . esc_attr(gn_phone_raw());
    $ajax = esc_url(admin_url('admin-ajax.php'));
    $nonce = wp_create_nonce('gn_ai');
    ?>
    <button class="gn-chat-fab" id="gnChatFab" aria-label="Chat với Gánh Ngon" aria-expanded="false" onclick="gnChatToggle()">
      <span class="gn-chat-badge"></span>
      <svg viewBox="0 0 24 24" fill="currentColor"><path d="M12 3C6.5 3 2 6.6 2 11c0 2.4 1.3 4.5 3.4 6-.1 1-.6 2.4-1.2 3.4-.2.3.1.7.5.6 1.9-.5 3.5-1.3 4.5-2 .9.2 1.8.3 2.8.3 5.5 0 10-3.6 10-8.3S17.5 3 12 3zm-4 9a1.2 1.2 0 1 1 0-2.4A1.2 1.2 0 0 1 8 12zm4 0a1.2 1.2 0 1 1 0-2.4A1.2 1.2 0 0 1 12 12zm4 0a1.2 1.2 0 1 1 0-2.4A1.2 1.2 0 0 1 16 12z"/></svg>
    </button>
    <div class="gn-chat-panel" id="gnChatPanel" role="dialog" aria-label="Chat">
      <div class="gn-chat-head">
        <strong><?php echo esc_html(gn_t('adv_title')); ?></strong>
        <span><?php echo esc_html(gn_t('hours_clock')); ?> · <?php echo esc_html(gn_phone_display()); ?></span>
      </div>
      <div class="gn-chat-log" id="gnChatLog">
        <div class="gn-msg gn-msg-bot"><?php echo esc_html(gn_advisor_reply('xin chao', gn_cur_lang())); ?></div>
      </div>
      <form class="gn-chat-input" id="gnChatForm" onsubmit="return gnAiSend(event)">
        <input type="text" id="gnChatText" autocomplete="off" placeholder="Nhập câu hỏi của anh/chị…" aria-label="Nhập tin nhắn">
        <button type="submit" aria-label="Gửi"><svg viewBox="0 0 24 24" fill="currentColor"><path d="M3.4 20.4 21 12 3.4 3.6 3 10l12 2-12 2z"/></svg></button>
      </form>
      <div class="gn-chat-channels">
        <span class="gn-chat-ch-label">Hoặc chat qua:</span>
        <a href="<?php echo $zalo; ?>" target="_blank" rel="noopener" title="Zalo" style="background:#0068FF"><svg viewBox="0 0 24 24" fill="#fff"><path d="M12 2C6.5 2 2 5.9 2 10.7c0 2.7 1.5 5.2 3.7 6.8-.1 1-.5 2.3-1 3.1-.1.2 0 .5.3.4 1.8-.4 3.2-1.1 4.1-1.7.9.2 1.9.3 2.9.3 5.5 0 10-3.9 10-8.7S17.5 2 12 2z"/></svg></a>
        <a href="<?php echo $wa; ?>" target="_blank" rel="noopener" title="WhatsApp" style="background:#25D366"><svg viewBox="0 0 24 24" fill="#fff"><path d="M12 2a10 10 0 0 0-8.5 15.3L2 22l4.8-1.5A10 10 0 1 0 12 2zm0 2a8 8 0 1 1-4.2 14.8l-.3-.2-2.8.9.9-2.7-.2-.3A8 8 0 0 1 12 4z"/></svg></a>
        <a href="<?php echo $mes; ?>" target="_blank" rel="noopener" title="Messenger" style="background:#0084FF"><svg viewBox="0 0 24 24" fill="#fff"><path d="M12 2C6.3 2 2 6.2 2 11.6c0 2.9 1.3 5.4 3.4 7.1V22l3.1-1.7c.8.2 1.6.3 2.5.3 5.7 0 10-4.2 10-9.6S17.7 2 12 2zm1 12.4-2.6-2.7-4.9 2.7 5.4-5.7 2.6 2.7 4.8-2.7-5.3 5.7z"/></svg></a>
        <a href="<?php echo $tg; ?>" target="_blank" rel="noopener" title="Telegram" style="background:#0088CC"><svg viewBox="0 0 24 24" fill="#fff"><path d="M12 2a10 10 0 1 0 0 20 10 10 0 0 0 0-20zm4.9 6.9-1.6 7.7c-.1.5-.4.7-.9.4l-2.5-1.8-1.2 1.2c-.1.1-.3.2-.5.2l.2-2.5 4.6-4.2c.2-.2 0-.3-.3-.1L9 13.2l-2.5-.8c-.5-.2-.5-.5.1-.8l9.6-3.7c.4-.2.8.1.7.8z"/></svg></a>
        <a href="<?php echo $tel; ?>" title="Gọi điện" style="background:#2C1810"><svg viewBox="0 0 24 24" fill="#fff"><path d="M6.6 10.8a15 15 0 0 0 6.6 6.6l2.2-2.2a1 1 0 0 1 1-.24 11 11 0 0 0 3.5.56 1 1 0 0 1 1 1V20a1 1 0 0 1-1 1A17 17 0 0 1 3 4a1 1 0 0 1 1-1h3.5a1 1 0 0 1 1 1c0 1.2.2 2.4.56 3.5a1 1 0 0 1-.25 1l-2.2 2.3z"/></svg></a>
      </div>
    </div>
    <script>
    (function(){
      window.gnAiCfg = {url:"<?php echo $ajax; ?>", nonce:"<?php echo $nonce; ?>", lang:"<?php echo esc_js(gn_cur_lang()); ?>", hist:[]};
    })();
    function gnChatToggle(){var p=document.getElementById('gnChatPanel');var f=document.getElementById('gnChatFab');var o=p.classList.toggle('open');f.setAttribute('aria-expanded',o);if(o){setTimeout(function(){var t=document.getElementById('gnChatText');if(t)t.focus();},120);}}
    document.addEventListener('click',function(e){if(!e.target.closest('#gnChatPanel')&&!e.target.closest('#gnChatFab')){var p=document.getElementById('gnChatPanel');if(p)p.classList.remove('open');}});
    function gnAddMsg(text,who){var log=document.getElementById('gnChatLog');var d=document.createElement('div');d.className='gn-msg gn-msg-'+who;d.textContent=text;log.appendChild(d);log.scrollTop=log.scrollHeight;return d;}
    function gnAiSend(e){
      e.preventDefault();
      var inp=document.getElementById('gnChatText');var msg=(inp.value||'').trim();if(!msg)return false;
      gnAddMsg(msg,'user');gnAiCfg.hist.push({role:'user',content:msg});inp.value='';
      var typing=gnAddMsg('Đang soạn…','bot');typing.classList.add('gn-typing');
      var fd=new FormData();fd.append('action','gn_ai_chat');fd.append('nonce',gnAiCfg.nonce);fd.append('lang',gnAiCfg.lang||'vi');fd.append('message',msg);fd.append('history',JSON.stringify(gnAiCfg.hist.slice(-8)));
      fetch(gnAiCfg.url,{method:'POST',body:fd,credentials:'same-origin'})
        .then(function(r){return r.json();})
        .then(function(j){typing.remove();var rep=(j&&j.data&&j.data.reply)?j.data.reply:'Xin lỗi, em chưa trả lời được. Anh/chị chat Zalo/WhatsApp giúp em nhé.';gnAddMsg(rep,'bot');gnAiCfg.hist.push({role:'assistant',content:rep});})
        .catch(function(){typing.remove();gnAddMsg('Kết nối gián đoạn. Anh/chị vui lòng chat Zalo/WhatsApp 0979 232 233 ạ.','bot');});
      return false;
    }
    </script>
    <?php
}
add_action('wp_footer', 'gn_chat_widget', 6);

// ============================================================
// Schema injection — per master brief §21
// ============================================================
function gn_schema_all() {
    $schemas = [];
    $org_base = [
        '@type'     => 'Restaurant',
        '@id'       => home_url('/') . '#restaurant',
        'name'      => 'Gánh Ngon',
        'alternateName' => 'Gánh Ngon Phú Quốc',
        'url'       => home_url('/'),
        'telephone' => gn_phone_raw(),
        'email'     => 'contact@ganhngon.com',
        'image'     => home_url('/wp-content/uploads/2026/09/ganhngon-khong-gian-quan.webp'),
        'priceRange' => 'Liên hệ tư vấn',
        'servesCuisine' => ['Vietnamese', 'Asian'],
        'openingHours' => 'Mo-Su 06:30-02:00',
        'openingHoursSpecification' => [[
            '@type'     => 'OpeningHoursSpecification',
            'dayOfWeek' => ['Monday','Tuesday','Wednesday','Thursday','Friday','Saturday','Sunday'],
            'opens'     => '06:30',
            'closes'    => '02:00',
        ]],
        'address'   => [
            '@type'           => 'PostalAddress',
            'streetAddress'   => '113 Trần Hưng Đạo',
            'addressLocality' => 'Dương Đông',
            'addressRegion'   => 'Phú Quốc, Kiên Giang',
            'addressCountry'  => 'VN',
        ],
        'geo' => [
            '@type'     => 'GeoCoordinates',
            'latitude'  => 10.2167,
            'longitude' => 103.9667,
        ],
        'description' => 'Lẩu gà sầu riêng tại Gánh Ngon, 113 Trần Hưng Đạo, Dương Đông, Phú Quốc. Bàn thường trong ngày. Mở cửa 6:30–2:00. Giá báo tại nhà hàng.',
        'sameAs' => [gn_facebook(), gn_instagram(), gn_telegram(), 'https://saophuquoc.com/'],
    ];

    if (is_front_page()) {
        $schemas[] = $org_base + ['@context' => 'https://schema.org'];
        $schemas[] = [
            '@context' => 'https://schema.org',
            '@type'    => 'LocalBusiness',
            '@id'      => home_url('/') . '#localbusiness',
            'name'     => 'Gánh Ngon',
            'image'    => home_url('/wp-content/uploads/2026/09/ganhngon-khong-gian-quan.webp'),
            'telephone' => gn_phone_raw(),
            'address'  => $org_base['address'],
            'url'      => home_url('/'),
        ];
        $schemas[] = [
            '@context' => 'https://schema.org',
            '@type'    => 'Organization',
            '@id'      => home_url('/') . '#organization',
            'name'     => 'Gánh Ngon',
            'logo'     => home_url('/wp-content/themes/ganhngon-restaurant/screenshot.png'),
            'url'      => home_url('/'),
            'sameAs'   => array_values(array_filter([gn_facebook(), gn_instagram(), gn_telegram(), gn_tiktok(), gn_youtube()])),
            'parentOrganization' => ['@type'=>'Organization','name'=>'SAO PHU QUOC','url'=>'https://saophuquoc.com/'],
        ];
        $faqs = gn_faqs_i18n();
        if ($faqs) {
            $schemas[] = [
                '@context' => 'https://schema.org',
                '@type'    => 'FAQPage',
                'mainEntity' => array_map(function($f){
                    return ['@type' => 'Question','name'  => $f['q'],'acceptedAnswer' => ['@type'=>'Answer','text'=>$f['a']]];
                }, $faqs),
            ];
        }
    }
    if (is_page('thuc-don')) {
        $schemas[] = [
            '@context' => 'https://schema.org',
            '@type'    => 'Menu',
            'name'     => 'Thực đơn Gánh Ngon',
            'description' => '220+ món đặc sản Việt Nam ba miền tại Phú Quốc',
            'inLanguage' => ['vi','en','zh','ru'],
        ];
    }
    if (is_page('khach-doan-tiec-rieng')) {
        $schemas[] = [
            '@context' => 'https://schema.org',
            '@type'    => 'Event',
            'name'     => 'Sự kiện & Tiệc riêng tại Gánh Ngon',
            'description' => 'Đặt tiệc sinh nhật, tiệc công ty, gala dinner, họp mặt gia đình, khách đoàn du lịch và phòng VIP riêng tư',
            'location' => $org_base,
            'eventStatus' => 'https://schema.org/EventScheduled',
            'eventAttendanceMode' => 'https://schema.org/OfflineEventAttendanceMode',
        ];
    }
    foreach ($schemas as $s) {
        echo '<script type="application/ld+json">' . wp_json_encode($s, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES) . "</script>\n";
    }
}
add_action('wp_head', 'gn_schema_all', 30);

/**
 * Open Graph dự phòng — CHỈ chạy khi không có plugin SEO nào lo phần này.
 *
 * Bản cũ in og:title và og:description vô điều kiện, trong khi Yoast cũng in,
 * nên mỗi trang có HAI thẻ og:title với nội dung khác nhau. Đa số trình đọc lấy
 * thẻ sau, nên khi chia sẻ link ra Facebook/Zalo hiện mô tả sai — trang đối tác
 * lại hiện mô tả nhà hàng chung.
 *
 * og:image cũ trỏ vào ảnh stock Unsplash của người khác. Ảnh chia sẻ của thương
 * hiệu mà mượn ảnh bên thứ ba là hỏng cả nhận diện lẫn quyền dùng, nên bỏ. Khi
 * có ảnh thật, đặt Logo trong Tuỳ biến giao diện là hàm này tự lấy.
 */
function gn_og_image() {
    if (defined('WPSEO_VERSION') || defined('RANK_MATH_VERSION')) return;   // plugin SEO đã lo

    if (function_exists('gn_t')) {
        echo '<meta property="og:title" content="' . esc_attr(wp_get_document_title()) . '" />' . "\n";
        echo '<meta property="og:description" content="' . esc_attr(gn_t('hero_lead')) . '" />' . "\n";
    }

    // ưu tiên ảnh đại diện bài viết, rồi logo, rồi icon site — không dùng ảnh stock
    $img = '';
    if (is_singular() && has_post_thumbnail()) {
        $img = get_the_post_thumbnail_url(get_queried_object_id(), 'full');
    }
    if (!$img) {
        $logo_id = (int) get_theme_mod('custom_logo');
        if ($logo_id) $img = wp_get_attachment_image_url($logo_id, 'full');
    }
    if (!$img && function_exists('get_site_icon_url')) $img = get_site_icon_url(512);
    if (!$img) return;

    echo '<meta property="og:image" content="' . esc_url($img) . '" />' . "\n";
    echo '<meta name="twitter:image" content="' . esc_url($img) . '" />' . "\n";
}
add_action('wp_head', 'gn_og_image', 6);

/**
 * Số điện thoại lọt vào tiêu đề/mô tả SEO không khớp số công bố.
 * Đo được: meta description ghi 0932154266 trong khi toàn site dùng 0979 232 233.
 */
function gn_fix_seo_phone($text) {
    if (!is_string($text) || $text === '') return $text;
    return preg_replace('/0\d{2}[\s.\-]?\d{3}[\s.\-]?\d{3,4}/', '0979 232 233', $text);
}
add_filter('wpseo_metadesc', 'gn_fix_seo_phone', 30);
add_filter('wpseo_title', 'gn_fix_seo_phone', 30);
add_filter('wpseo_opengraph_desc', 'gn_fix_seo_phone', 30);
add_filter('wpseo_twitter_description', 'gn_fix_seo_phone', 30);

function gn_get_faqs() {
    return [
        ['q'=>'Gánh Ngon là nhà hàng gì?', 'a'=>'Gánh Ngon là nhà hàng đặc sản Việt Nam sang trọng tại Phú Quốc, phục vụ 220+ món Việt ba miền trong không gian rộng rãi, có 10 phòng VIP riêng tư. Phù hợp gia đình, nhóm bạn, khách đoàn, doanh nghiệp, khách VIP và khách quốc tế.'],
        ['q'=>'Gánh Ngon có phòng VIP không?', 'a'=>'Có. Gánh Ngon sở hữu 10 phòng VIP từ 4–40 khách (Sen, Trúc, Đào, Mai, Cúc, Lan, Hồng, Nguyệt, Phượng, Signature). Mỗi phòng có concierge riêng, cách âm tốt, phù hợp tiếp khách, gia đình, doanh nghiệp, sinh nhật, họp mặt. Xem chi tiết tại trang Khách đoàn & Tiệc.'],
        ['q'=>'Có cần đặt bàn trước không?', 'a'=>'Bàn thường nhận trong ngày, kể cả khi vừa đến Phú Quốc. Mở cửa hằng ngày 6:30–2:00. Lẩu gà sầu riêng nên báo trước khoảng 1 tiếng để nồi nóng lúc ngồi. Phòng VIP: khoảng 24 giờ. Đoàn từ 20 khách: 48–72 giờ. Gọi hoặc Zalo 0979 232 233.'],
        ['q'=>'Có nhận khách đoàn không?', 'a'=>'Có. Gánh Ngon nhận khách đoàn 10–80 người. Có set menu đoàn, phục vụ nhanh 60–90 phút, hóa đơn VAT 8% cho công ty du lịch, có người phụ trách đoàn riêng, có chỗ đậu xe 16/29/45 chỗ. Hướng dẫn viên đi cùng đoàn ăn miễn phí.'],
        ['q'=>'Có menu cho khách quốc tế không?', 'a'=>'Có. Menu Gánh Ngon hỗ trợ 4 ngôn ngữ: Tiếng Việt · English · 中文 · Русский. Có món Việt dễ ăn cho khách lần đầu thử. Hỗ trợ WhatsApp, WeChat, Telegram đặt bàn cho khách quốc tế.'],
        ['q'=>'Có thể đặt tiệc sinh nhật hoặc tiệc riêng không?', 'a'=>'Có. Gánh Ngon nhận tiệc sinh nhật, họp mặt gia đình, tiệc công ty, gala dinner nhỏ và tiệc riêng. Có bánh, hoa, backdrop, MC, DJ tùy gói. Vui lòng gửi form yêu cầu để nhận tư vấn set menu phù hợp.'],
        ['q'=>'Có thể đặt phòng VIP online không?', 'a'=>'Có. Vui lòng dùng form tại /dat-ban/ chọn nhu cầu "Phòng VIP", hoặc gọi hotline / Zalo / WhatsApp để tư vấn viên gợi ý phòng phù hợp với số khách, ngân sách và mục đích.'],
        ['q'=>'Nếu chưa biết chọn món thì sao?', 'a'=>'Bắt đầu với lẩu gà sầu riêng, món đặc trưng. Phần còn lại là 220+ món Việt ba miền. Giá không niêm yết trên web. Trang /ai-tu-van/ trả lời giờ mở cửa, đường đi và bàn thường trong ngày, hoặc gọi 0979 232 233.'],
    ];
}

function gn_quick_booking_strip() {
    $ppl = gn_t('people');
    $today = gn_today_ymd();
    ?>
    <section class="gn-quick-booking" id="gn-book-today">
      <div class="gn-container">
        <form method="post" action="<?php echo esc_url(admin_url('admin-ajax.php')); ?>?action=sao_create_booking" class="gn-quick-form" data-gn-book>
          <input type="hidden" name="source" value="homepage_same_day">
          <input type="hidden" name="space_type" value="individual">
          <div class="gn-quick-grid">
            <label><?php echo esc_html(gn_t('qb_name')); ?><input type="text" name="customer_name" required autocomplete="name" placeholder="<?php echo esc_attr(gn_t('qb_name')); ?>"></label>
            <label><?php echo esc_html(gn_t('qb_phone')); ?><input type="tel" name="customer_phone" required autocomplete="tel" inputmode="tel" placeholder="<?php echo esc_attr(gn_t('qb_phone')); ?>"></label>
            <label><?php echo esc_html(gn_t('qb_date')); ?><input type="date" name="booking_date" required min="<?php echo esc_attr($today); ?>" value="<?php echo esc_attr($today); ?>"></label>
            <label><?php echo esc_html(gn_t('qb_time')); ?><select name="booking_time"><?php foreach (['06:30','07:30','11:30','12:00','12:30','18:00','18:30','19:00','19:30','20:00','21:00'] as $hm) echo '<option>' . esc_html($hm) . '</option>'; ?></select></label>
            <label><?php echo esc_html(gn_t('qb_guests')); ?><select name="guests"><?php for ($i = 1; $i <= 12; $i++) echo '<option value="' . $i . '">' . $i . ' ' . esc_html($ppl) . '</option>'; ?></select></label>
          </div>
          <label class="gn-check" style="color:#fff;margin:8px 0"><input type="checkbox" name="signature_dish" value="1"> <?php echo esc_html(gn_t('qb_dish')); ?></label>
          <button type="submit" class="gn-cta-btn"><?php echo esc_html(gn_t('qb_same')); ?></button>
          <p class="gn-book-out" role="status" hidden></p>
          <p style="width:100%;margin:8px 0 0"><a href="<?php echo esc_url(gn_page_url('khach-doan-tiec-rieng')); ?>" style="color:#fff"><?php echo esc_html(gn_t('qb_vip_link')); ?> →</a></p>
        </form>
      </div>
    </section>
    <?php
}

// Redirects
add_action('template_redirect', function() {
    $req = trim($_SERVER['REQUEST_URI'] ?? '', '/');
    if ($req === 'phong-vip') { wp_redirect(home_url('/khach-doan-tiec-rieng/#phong-vip'), 301); exit; }
    if ($req === 'partner')   { wp_redirect(home_url('/doi-tac/'), 301); exit; }
});

// === Hotline fix (2026-06-20): vá số placeholder hardcode trong post_content (DB) → hotline thật, không cần migrate DB ===
function gn_fix_legacy_phone($html) {
    if (strpos($html, '842971234567') !== false || strpos($html, '297 123 4567') !== false) {
        $html = strtr($html, array(
            '842971234567'     => '84979232233',
            '+84 297 123 4567' => '0979 232 233',
            '0297 123 4567'    => '0979 232 233',
        ));
    }
    // VNPay đang ở chế độ sandbox (chưa thanh toán thật) → bỏ lời hứa "qua VNPay" để không sai với khách
    if (stripos($html, 'qua VNPay') !== false) {
        $html = str_ireplace(' qua VNPay', '', $html);
    }
    return $html;
}
add_filter('the_content', 'gn_fix_legacy_phone', 99);
add_filter('widget_text', 'gn_fix_legacy_phone', 99);
add_filter('render_block', 'gn_fix_legacy_phone', 99);

/* ==========================================================================
   GANH NGON REDESIGN 2026 — BEGIN
   Ba việc sửa ở tầng theme, không đụng nội dung lưu trong database:
     1. Bỏ nhãn quy trình nội bộ trên trang Đặt bàn
     2. Hạ <h1> trong nội dung xuống <h2> — page.php đã in <h1> tiêu đề rồi
     3. Meta description dự phòng cho trang chưa đặt
   HOÀN TÁC: xoá khối giữa BEGIN và END, hoặc tải lại
   ganhngon/backup-theme-2026-08-08/functions.php
   ========================================================================== */

/**
 * Trang /dat-ban/ đang phơi quy trình nội bộ ra cho khách: "Form đặt bàn — 9 bước",
 * "Bước 1–3:", và cả khối "Trạng thái đặt bàn (11 trạng thái)". Khách chỉ cần
 * điền form, không cần biết pipeline vận hành của nhà hàng.
 */
function gn_strip_internal_steps($content) {
    if (is_admin() || !in_the_loop() || !is_main_query()) return $content;

    // "Form đặt bàn — 9 bước" -> "Form đặt bàn"
    $content = preg_replace('/(Form đặt bàn)\s*[—–-]\s*\d+\s*bước/u', '$1', $content);

    // "Bước 1–3: Ngày, giờ..." -> "Ngày, giờ..."  (áp cho cả nhãn lẫn nút submit)
    $content = preg_replace('/Bước\s*\d+(?:\s*[–—-]\s*\d+)?\s*:\s*/u', '', $content);

    // Bỏ trọn khối "Trạng thái đặt bàn (N trạng thái)" và đoạn liệt kê ngay sau nó
    $content = preg_replace('/<h3[^>]*>\s*Trạng thái đặt bàn.*?<\/h3>\s*<p[^>]*>.*?<\/p>/us', '', $content);

    return $content;
}
add_filter('the_content', 'gn_strip_internal_steps', 20);

/**
 * page.php và single.php đã in <h1> tiêu đề. Nội dung trang lưu trong database
 * in thêm <h1> nữa -> hai thẻ h1 trên cùng một trang, sai cấu trúc heading.
 */
function gn_demote_content_h1($content) {
    if (is_admin() || !in_the_loop() || !is_main_query()) return $content;
    if (function_exists('gn_is_advisor_page') && gn_is_advisor_page()) return $content;
    $content = preg_replace('/<h1(\s[^>]*)?>/i', '<h2$1>', $content);
    $content = preg_replace('/<\/h1>/i', '</h2>', $content);
    return $content;
}
add_filter('the_content', 'gn_demote_content_h1', 21);

/**
 * Meta description dự phòng. Nếu Yoast hoặc Rank Math đang chạy thì đưa qua
 * filter của plugin để không in trùng thẻ; không có plugin thì tự in ở wp_head.
 */
function gn_fallback_metadesc_text() {
    if (is_front_page()) {
        return 'Lẩu gà sầu riêng — món đặc trưng của Gánh Ngon, 113 Trần Hưng Đạo, Dương Đông, Phú Quốc. Bàn thường nhận trong ngày, mở cửa 6:30–2:00. Zalo 0979 232 233. Giá báo tại nhà hàng.';
    }
    if (!is_singular()) return '';
    $post = get_queried_object();
    if (!$post || empty($post->post_content)) return '';
    $txt = wp_strip_all_tags(strip_shortcodes($post->post_content));
    $txt = trim(preg_replace('/\s+/u', ' ', $txt));
    if ($txt === '') return '';
    if (function_exists('mb_strlen') && mb_strlen($txt, 'UTF-8') > 155) {
        $txt = mb_substr($txt, 0, 152, 'UTF-8');
        $cut = mb_strrpos($txt, ' ', 0, 'UTF-8');
        if ($cut !== false && $cut > 90) $txt = mb_substr($txt, 0, $cut, 'UTF-8');
        $txt .= '…';
    }
    return $txt;
}

add_filter('wpseo_metadesc', 'gn_fallback_metadesc_filter', 20);
function gn_fallback_metadesc_filter($desc) {
    return ($desc === '' || $desc === null) ? gn_fallback_metadesc_text() : $desc;
}

function gn_print_fallback_metadesc() {
    if (defined('WPSEO_VERSION')) return;                    // Yoast lo phần này
    if (defined('RANK_MATH_VERSION')) return;                // Rank Math lo phần này
    $d = gn_fallback_metadesc_text();
    if ($d !== '') echo '<meta name="description" content="' . esc_attr($d) . '">' . "\n";
}
add_action('wp_head', 'gn_print_fallback_metadesc', 2);

/* GANH NGON REDESIGN 2026 — END */

/* ==========================================================================
   TRANG ĐỐI TÁC — dựng lại toàn bộ, thay nội dung lưu trong database
   Giữ nguyên endpoint đặt bàn và một hàm lưu hồ sơ cho cả hai tên ajax:
     - POST admin-ajax.php?action=gn_partner_register (form đang render)
     - POST admin-ajax.php?action=sao_partner_login   (tên cũ, cùng hàm lưu)
     - POST admin-ajax.php?action=sao_create_booking  (đặt chỗ thay khách)
   Hoa hồng: luỹ tiến theo NGÀY 10% / 12% / 15% + thưởng 2% khi tháng đạt 100tr
   HOÀN TÁC: xoá khối này, nội dung cũ trong database hiện lại nguyên vẹn.
   ========================================================================== */

function gn_partner_page_html() {
    $ajax = esc_url(admin_url('admin-ajax.php'));
    ob_start(); ?>

<div class="gnp">

  <!-- ============ 1. HERO ============ -->
  <section class="gnp-hero">
    <span class="gnp-rule"></span>
    <p class="gnp-eyebrow">Chương trình đối tác</p>
    <h2>Một mã QR của riêng bạn.<br>Bán càng nhiều trong ngày, tỷ lệ càng cao.</h2>
    <p class="gnp-lead">Hai cách làm việc với một nhà hàng tại 113 Trần Hưng Đạo, Dương Đông. Giới thiệu khách bằng link hoặc mã QR, hoặc đưa đoàn và hợp tác tại chỗ. Hoa hồng luỹ tiến 10% · 12% · 15% theo doanh số mỗi ngày, thêm 2% khi tháng đạt 100 triệu. Chuyển khoản ngày 5 hàng tháng. Gọi hoặc Zalo 0979 232 233.</p>
    <div class="gnp-cta">
      <a class="gnp-btn gnp-btn--gold" href="#dang-ky">Đăng ký làm đối tác</a>
      <a class="gnp-btn gnp-btn--ghost" href="#hoa-hong">Xem cách tính hoa hồng</a>
    </div>
  </section>

  <!-- ============ 2. BỐN BƯỚC ============ -->
  <section class="gnp-sec">
    <header class="gnp-head">
      <span class="gnp-rule"></span>
      <p class="gnp-eyebrow">Bốn bước</p>
      <h3>Từ lúc quét đến lúc nhận tiền</h3>
    </header>
    <div class="gnp-grid gnp-grid--4">
      <article class="gnp-card">
        <span class="gnp-num">01</span>
        <h4>Nhà hàng gọi lại</h4>
        <p>Để lại tên và số. Gánh Ngon gọi đúng số đó. Khi hồ sơ được duyệt, bạn nhận link và mã QR để khách tự đặt. Mã mới gán đơn sau khi duyệt.</p>
      </article>
      <article class="gnp-card">
        <span class="gnp-num">02</span>
        <h4>Khách quét mã</h4>
        <p>QR mở thẳng trang đặt bàn hoặc mua voucher, đã gắn sẵn mã của bạn. Khách không phải nhập gì thêm, không phải nhớ mã.</p>
      </article>
      <article class="gnp-card">
        <span class="gnp-num">03</span>
        <h4>Theo dõi từng ngày</h4>
        <p>Cổng đối tác hiện lượt quét, đơn đặt bàn, voucher bán ra và hoa hồng tạm tính — cập nhật ngay khi khách đến.</p>
      </article>
      <article class="gnp-card">
        <span class="gnp-num">04</span>
        <h4>Nhận tiền ngày 5</h4>
        <p>Chốt sổ ngày 1 hàng tháng, đối soát 3 ngày, chuyển khoản ngày 5 kèm bảng kê từng đơn và hoá đơn VAT.</p>
      </article>
    </div>
  </section>

  <!-- ============ 3. HOA HỒNG ============ -->
  <section class="gnp-sec gnp-sec--sand" id="hoa-hong">
    <header class="gnp-head">
      <span class="gnp-rule"></span>
      <p class="gnp-eyebrow">Cách tính hoa hồng</p>
      <h3>Luỹ tiến theo doanh số từng ngày</h3>
      <p class="gnp-sub">Mỗi ngày tính riêng, sáng hôm sau bắt đầu lại từ bậc 1. Phần doanh số rơi vào bậc nào ăn tỷ lệ bậc đó — không phải cả ngày ăn chung một tỷ lệ.</p>
    </header>

    <div class="gnp-grid gnp-grid--3">
      <article class="gnp-tier">
        <p class="gnp-eyebrow">Bậc 1</p>
        <strong class="gnp-pct">10%</strong>
        <p class="gnp-range">0 – 5 triệu</p>
        <p>Phần doanh số đầu tiên trong ngày, tính đến mốc 5 triệu đồng.</p>
      </article>
      <article class="gnp-tier">
        <p class="gnp-eyebrow">Bậc 2</p>
        <strong class="gnp-pct">12%</strong>
        <p class="gnp-range">5 – 10 triệu</p>
        <p>Chỉ phần vượt quá 5 triệu mới ăn 12%. Phần dưới vẫn giữ nguyên 10%.</p>
      </article>
      <article class="gnp-tier gnp-tier--hot">
        <p class="gnp-eyebrow">Bậc 3</p>
        <strong class="gnp-pct">15%</strong>
        <p class="gnp-range">Trên 10 triệu</p>
        <p>Toàn bộ phần vượt 10 triệu trong ngày ăn 15%, không có trần.</p>
      </article>
    </div>

    <div class="gnp-example">
      <h4>Ví dụ một ngày bán được 12.850.000đ</h4>
      <p class="gnp-sub">Chia làm ba khúc, mỗi khúc nhân tỷ lệ của bậc đó rồi cộng lại.</p>
      <div class="gnp-ladder">
        <div style="flex:5000 1 0"><span>5.000.000đ × 10%</span><b>500.000đ</b></div>
        <div style="flex:5000 1 0"><span>5.000.000đ × 12%</span><b>600.000đ</b></div>
        <div style="flex:2850 1 0"><span>2.850.000đ × 15%</span><b>427.500đ</b></div>
      </div>
      <div class="gnp-total">
        <span>Hoa hồng ngày hôm đó</span>
        <b>1.527.500đ · bằng 11,9% doanh số</b>
      </div>
    </div>

    <div class="gnp-bonus">
      <div>
        <p class="gnp-eyebrow gnp-eyebrow--gold">Thưởng tháng</p>
        <h4>Đạt 100 triệu trong tháng, nhận thêm 2% doanh số</h4>
        <p>Tính trên tổng doanh số hợp lệ cả tháng, cộng thẳng vào kỳ chi trả — độc lập với hoa hồng luỹ tiến từng ngày ở trên. Tháng đạt 120 triệu thì được thưởng thêm 2.400.000đ.</p>
      </div>
      <span class="gnp-bonusbadge"><b>+2%</b><small>Từ 100 triệu/tháng</small></span>
    </div>

    <p class="gnp-note">Doanh số hợp lệ là tiền thực thu: khách đã đến và đã thanh toán, cộng voucher khách đã trả tiền và tiền nạp thêm vào voucher. Voucher giữ chỗ chưa thanh toán chưa tính — tính vào ngày khách trả. Đơn hủy, khách không đến, voucher hoàn tiền trong 7 ngày đều không tính.</p>
  </section>

  <!-- ============ 4. HAI CÁCH, MỖI CÁCH MỘT BỘ CÔNG CỤ ============ -->
  <section class="gnp-sec" id="hai-cach">
    <header class="gnp-head">
      <span class="gnp-rule"></span>
      <p class="gnp-eyebrow">Hai cách hợp tác</p>
      <h3>Chọn một cách, nhận một bộ công cụ</h3>
      <p class="gnp-sub">Một nhà hàng, một địa chỉ: 113 Trần Hưng Đạo, Dương Đông, Phú Quốc. Khách ăn tại đây, không có điểm bán thứ hai.</p>
    </header>
    <div class="gnp-grid gnp-grid--2">
      <article class="gnp-card">
        <p class="gnp-eyebrow">Cách 1</p>
        <h4>Giới thiệu bằng link/mã</h4>
        <p>Dành cho hướng dẫn viên, tài xế, khách sạn, KOC, KOL và affiliate. Khách tự mở link hoặc quét mã.</p>
        <p><b>Bộ công cụ:</b> một link và một mã QR cho bàn thường, thêm một link cho món lẩu gà sầu riêng. Đơn gắn về mã của bạn. Khách không phải nhớ mã.</p>
      </article>
      <article class="gnp-card">
        <p class="gnp-eyebrow">Cách 2</p>
        <h4>Đưa đoàn / hợp tác địa phương</h4>
        <p>Dành cho công ty lữ hành, quầy khách sạn và hiệp hội. Đoàn đến đúng nhà hàng này.</p>
        <p><b>Bộ công cụ:</b> một đầu mối đặt đoàn. Điền hộ khách ở form bên dưới, hoặc gọi / Zalo 0979 232 233 để giữ bàn đoàn và phòng riêng.</p>
      </article>
    </div>
    <p class="gnp-note">Chưa chắc cách nào phù hợp? Trên form có thêm lựa chọn “Cần tư vấn thêm”. Nhà hàng gọi lại số bạn để lại.</p>
  </section>

  <!-- ============ 6. CỔNG ĐỐI TÁC ============ -->
  <section class="gnp-sec">
    <header class="gnp-head">
      <span class="gnp-rule"></span>
      <p class="gnp-eyebrow">Cổng đối tác</p>
      <h3>Doanh số của bạn, cập nhật từng ngày</h3>
      <p class="gnp-sub">Không phải gọi điện hỏi tháng này được bao nhiêu. Mở cổng ra là thấy từng đơn, từng khách, từng đồng hoa hồng.</p>
    </header>
    <div class="gnp-portal">
      <p class="gnp-demo">Số liệu minh hoạ để bạn hình dung giao diện — không phải dữ liệu thật của ai.</p>
      <div class="gnp-kpis">
        <div><span>Lượt quét QR hôm nay</span><b>128</b><small>+18 so với hôm qua</small></div>
        <div><span>Đặt bàn từ mã</span><b>9</b><small>7 đã đến · 2 chờ đến</small></div>
        <div><span>Doanh số hợp lệ</span><b>12.850.000đ</b><small>chỉ tính khách đã đến</small></div>
        <div class="is-gold"><span>Hoa hồng hôm nay</span><b>1.527.500đ</b><small>luỹ tiến 10 · 12 · 15%</small></div>
      </div>
      <div class="gnp-tablewrap">
        <table>
          <thead><tr><th>Giờ</th><th>Mã đơn</th><th>Khách</th><th>Số khách</th><th>Giá trị</th><th>Cộng dồn ngày</th><th>Trạng thái</th></tr></thead>
          <tbody>
            <tr><td>11:20</td><td>GN-B-24815</td><td>Trần Thị Bình</td><td>4</td><td><b>1.640.000đ</b></td><td>1.640.000đ</td><td><span class="gnp-tag is-ok">Đã đến</span></td></tr>
            <tr><td>12:05</td><td>GN-V-00932</td><td>Lê Minh Cường</td><td>—</td><td><b>500.000đ</b></td><td>2.140.000đ</td><td><span class="gnp-tag is-ok">Voucher đã trả</span></td></tr>
            <tr><td>12:48</td><td>GN-B-24821</td><td>Đoàn Sunrise Tour</td><td>18</td><td><b>8.880.000đ</b></td><td>11.020.000đ</td><td><span class="gnp-tag is-ok">Đã đến</span></td></tr>
            <tr><td>14:11</td><td>GN-V-00934</td><td>Nguyễn Thu Hà</td><td>—</td><td><b>1.000.000đ</b></td><td>12.020.000đ</td><td><span class="gnp-tag is-ok">Voucher đã trả</span></td></tr>
            <tr><td>15:30</td><td>GN-B-24829</td><td>Ivan Petrov</td><td>2</td><td><b>830.000đ</b></td><td>12.850.000đ</td><td><span class="gnp-tag is-ok">Đã đến</span></td></tr>
            <tr><td>17:02</td><td>GN-B-24836</td><td>Phạm Văn Đức</td><td>6</td><td>—</td><td>—</td><td><span class="gnp-tag is-warn">Chờ đến 19:00</span></td></tr>
          </tbody>
          <tfoot><tr><td colspan="4">Tổng hợp lệ hôm nay</td><td colspan="3"><b>12.850.000đ · hoa hồng 1.527.500đ</b></td></tr></tfoot>
        </table>
      </div>
      <p class="gnp-note gnp-note--left">Hoa hồng đặt bàn chốt khi khách <b>đã đến và đã thanh toán</b>. Voucher chốt khi khách <b>trả tiền</b>, kể cả trả sau tại quầy. Voucher giữ chỗ chưa trả thì chưa tính.</p>
    </div>
  </section>

  <!-- ============ 7. ĐĂNG KÝ ============ -->
  <section class="gnp-sec gnp-sec--sand" id="dang-ky">
    <div class="gnp-split">
      <div>
        <span class="gnp-rule"></span>
        <p class="gnp-eyebrow">Đăng ký</p>
        <h3>Để lại số, nhà hàng gọi lại</h3>
        <p class="gnp-sub">Chỉ cần tên, số điện thoại hoặc Zalo, và cách bạn muốn hợp tác. Email, khu vực và link kênh là tuỳ chọn.</p>
        <dl class="gnp-facts">
          <dt>Không phí tham gia</dt><dd>Không thu phí đăng ký, không đặt cọc, không ràng buộc doanh số tối thiểu.</dd>
          <dt>Một số hỗ trợ</dt><dd>0979 232 233 hoặc Zalo — cùng số với đặt bàn.</dd>
          <dt>Rút lui bất cứ lúc nào</dt><dd>Hoa hồng đã phát sinh vẫn được thanh toán đủ ở kỳ gần nhất.</dd>
        </dl>
      </div>

      <form class="gnp-form" id="gn-pr-form" method="post" action="<?php echo $ajax; ?>?action=gn_partner_register" novalidate>
        <h4>Đăng ký hợp tác</h4>
        <input type="text" name="website_hp" value="" tabindex="-1" autocomplete="off" aria-hidden="true" style="position:absolute;left:-9999px;width:1px;height:1px;opacity:0">
        <label><?php echo esc_html(gn_partner_signup_field('partner_type')['label']); ?> *
          <select name="partner_type" required>
            <option value="">Chọn một cách</option>
            <?php foreach (gn_partner_signup_field('partner_type')['options'] as $gn_way => $gn_way_label): ?>
              <option value="<?php echo esc_attr($gn_way); ?>"><?php echo esc_html($gn_way_label); ?></option>
            <?php endforeach; ?>
          </select>
        </label>
        <div class="gnp-row">
          <label><?php echo esc_html(gn_partner_signup_field('full_name')['label']); ?> *<input type="text" name="full_name" required autocomplete="name" placeholder="Nguyễn Văn A"></label>
          <label><?php echo esc_html(gn_partner_signup_field('phone')['label']); ?> *<input type="tel" name="phone" required autocomplete="tel" inputmode="tel" pattern="[0-9+ .()-]{9,15}" placeholder="09xx xxx xxx"></label>
        </div>
        <div class="gnp-row">
          <label><?php echo esc_html(gn_partner_signup_field('email')['label']); ?><input type="email" name="email" autocomplete="email" placeholder="Không bắt buộc"></label>
          <label><?php echo esc_html(gn_partner_signup_field('area')['label']); ?><input type="text" name="area" placeholder="Không bắt buộc"></label>
        </div>
        <label><?php echo esc_html(gn_partner_signup_field('social_link')['label']); ?><input type="text" name="social_link" placeholder="Không bắt buộc"></label>
        <button type="submit" class="gnp-btn gnp-btn--gold gnp-btn--block">Gửi đăng ký</button>
        <p class="gnp-fine">Gánh Ngon gọi lại đúng số bạn để lại. Cần nói ngay, gọi hoặc Zalo 0979 232 233.</p>
        <div id="gn-pr-out" role="status" aria-live="polite"></div>
      </form>
      <script>
      (function () {
        var f = document.getElementById('gn-pr-form');
        if (!f) return;
        var out = document.getElementById('gn-pr-out');
        f.addEventListener('submit', function (e) {
          e.preventDefault();
          var req = f.querySelectorAll('[required]');
          for (var i = 0; i < req.length; i++) {
            if (!String(req[i].value || '').trim()) {
              show('err', 'Vui lòng điền tên, số điện thoại và cách hợp tác.');
              req[i].focus();
              return;
            }
          }
          f.classList.add('is-busy');
          show('ok', 'Đang gửi…');
          fetch(f.action, { method: 'POST', body: new FormData(f), credentials: 'same-origin' })
            .then(function (r) { return r.json(); })
            .then(function (j) {
              f.classList.remove('is-busy');
              if (j && j.success && j.data && j.data.message) {
                show('ok', j.data.message);
                f.reset();
              } else {
                show('err', (j && j.data && j.data.message) ? j.data.message : 'Chưa gửi được. Gọi hoặc Zalo 0979 232 233.');
              }
            })
            .catch(function () {
              f.classList.remove('is-busy');
              show('err', 'Mất kết nối. Gọi hoặc Zalo 0979 232 233.');
            });
        });
        function show(kind, text) {
          out.className = kind === 'ok' ? 'is-ok' : 'is-err';
          out.textContent = text;
          out.style.display = 'block';
        }
      })();
      </script>
    </div>
  </section>

  <!-- ============ 8. ĐẶT CHỖ THAY KHÁCH ============ -->
  <section class="gnp-sec" id="dat-ho">
    <div class="gnp-split gnp-split--rev">
      <form class="gnp-form" method="post" action="<?php echo $ajax; ?>?action=sao_create_booking" data-gn-book>
        <h4>Đặt bàn thay khách</h4>
        <input type="hidden" name="source" value="partner_form">
        <div class="gnp-row">
          <label>Mã đối tác của bạn *<input type="text" name="ref_code" required placeholder="GN-P042"></label>
          <label>Tên bạn *<input type="text" name="partner_name" required placeholder="Nguyễn Văn A"></label>
        </div>
        <div class="gnp-row">
          <label>Tên khách *<input type="text" name="customer_name" required placeholder="Trần Thị Bình"></label>
          <label>SĐT khách *<input type="tel" name="customer_phone" required inputmode="tel" pattern="[0-9+ .()-]{9,15}" placeholder="09xx xxx xxx"></label>
        </div>
        <label>Email khách<input type="email" name="customer_email" placeholder="Không bắt buộc — dùng để gửi mã QR đặt bàn"></label>
        <div class="gnp-row">
          <label>Ngày đến *<input type="date" name="booking_date" required></label>
          <label>Giờ vào bàn *
            <select name="booking_time" required>
              <option value="">Chọn giờ</option>
              <option>11:30</option><option>12:00</option><option>12:30</option>
              <option>14:00</option><option>14:30</option><option>15:00</option>
              <option>17:30</option><option>18:00</option><option>18:30</option>
              <option>19:00</option><option>19:30</option><option>20:00</option><option>20:30</option>
            </select>
          </label>
          <label>Số khách *<input type="number" name="guests" min="1" max="200" required value="4"></label>
        </div>
        <div class="gnp-row">
          <label>Chỗ ngồi
            <select name="space_type">
              <option value="">Bàn thường</option>
              <option value="vip">Phòng VIP riêng</option>
              <option value="doan">Khu khách đoàn</option>
              <option value="tiec">Tiệc riêng</option>
            </select>
          </label>
          <label>Loại khách
            <select name="customer_type">
              <option value="">Chọn</option>
              <option value="gia-dinh">Gia đình</option>
              <option value="doan">Khách đoàn</option>
              <option value="doanh-nghiep">Doanh nghiệp</option>
              <option value="quoc-te">Khách quốc tế</option>
              <option value="vip">Khách VIP</option>
            </select>
          </label>
        </div>
        <label class="gn-check"><input type="checkbox" name="signature_dish" value="1"> Khách muốn lẩu gà sầu riêng</label>
        <label>Ghi chú<textarea name="note" rows="2" placeholder="Dị ứng hải sản, có người ăn chay, cần ghế cao cho trẻ, khách cần menu tiếng Anh…"></textarea></label>
        <button type="submit" class="gnp-btn gnp-btn--gold gnp-btn--block">Gửi yêu cầu đặt bàn</button>
        <p class="gn-book-out" role="status" hidden></p>
        <p class="gnp-fine">Nhà hàng xác nhận trong 2 phút qua Zalo hoặc điện thoại. Đơn bàn thường trong ngày vẫn nhận. Phòng VIP và đoàn từ 20 khách cần thời gian báo trước. Đơn gán vào mã đối tác bạn nhập ở trên.</p>
      </form>

      <div>
        <span class="gnp-rule"></span>
        <p class="gnp-eyebrow">Đặt hộ khách</p>
        <h3>Khách không muốn tự đặt? Bạn đặt hộ</h3>
        <p class="gnp-sub">Khách lớn tuổi, khách nước ngoài, khách đang trên xe — nhiều người ngại điền form. Bạn điền hộ ở đây, hoa hồng vẫn tính đủ về mã của bạn.</p>
        <dl class="gnp-facts">
          <dt>Vẫn tính hoa hồng đầy đủ</dt><dd>Đơn đặt hộ và đơn khách tự quét được tính như nhau, cùng bậc luỹ tiến trong ngày.</dd>
          <dt>Không cần khách xác nhận lại</dt><dd>Nhà hàng gọi thẳng số khách bạn điền để chốt giờ.</dd>
          <dt>Đoàn trên 10 khách</dt><dd>Gọi thẳng sales đoàn 0979 232 233 để được báo giá set menu và giữ phòng riêng.</dd>
        </dl>
      </div>
    </div>
  </section>

  <!-- ============ 9. FAQ ============ -->
  <section class="gnp-sec gnp-sec--sand">
    <header class="gnp-head">
      <span class="gnp-rule"></span>
      <p class="gnp-eyebrow">Câu hỏi thường gặp</p>
      <h3>Sáu câu đối tác hỏi nhiều nhất</h3>
    </header>
    <div class="gnp-faq">
      <details><summary>Hoa hồng tính trên giá niêm yết hay giá khách thực trả?</summary><p>Trên số tiền khách <b>thực trả</b> sau khi đã trừ khuyến mãi và voucher. Ví dụ hoá đơn 2.000.000đ, khách dùng voucher 500.000đ và giảm giờ vắng 20%, thực trả 1.100.000đ thì hoa hồng tính trên 1.100.000đ.</p></details>
      <details><summary>Khách đặt qua mã của tôi nhưng không đến thì sao?</summary><p>Không tính. Hoa hồng đặt bàn chỉ chốt khi khách đã đến và đã thanh toán. Đơn hủy và khách không đến đều bị loại khi chốt sổ, và bạn thấy rõ trạng thái đó ngay trong cổng đối tác.</p></details>
      <details><summary>Mã của tôi có hiệu lực bao lâu với một khách?</summary><p>30 ngày kể từ lượt quét đầu tiên của khách đó. Trong 30 ngày, khách quay lại đặt bàn bằng bất kỳ cách nào cũng vẫn tính về mã của bạn.</p></details>
      <details><summary>Hai đối tác cùng giới thiệu một khách thì ai được tính?</summary><p>Mã được quét gần nhất trước thời điểm đặt bàn. Không chia đôi và không cộng dồn hai mã trên cùng một đơn.</p></details>
      <details><summary>Bao giờ nhận được tiền, trả bằng cách nào?</summary><p>Chốt sổ ngày 1 hàng tháng, đối soát 3 ngày, chuyển khoản ngày 5 vào tài khoản bạn đăng ký. Phí chuyển khoản do Gánh Ngon chịu. Cá nhân nhận trên 2 triệu một kỳ bị khấu trừ 10% thuế thu nhập, có chứng từ khấu trừ.</p></details>
      <details><summary>Thấy số liệu sai thì báo thế nào?</summary><p>Từ lúc chốt sổ ngày 1 đến hết ngày 4, bạn đối chiếu và bấm báo sai lệch ngay trong cổng đối tác. Quá hạn thì kỳ đó coi như đã thống nhất và tiền chuyển đi luôn.</p></details>
    </div>
  </section>

  <!-- ============ 10. CHỐT ============ -->
  <section class="gnp-final">
    <span class="gnp-rule"></span>
    <h3>Để lại số, nhà hàng gọi lại</h3>
    <p>Không phí tham gia. Cần nói ngay thì gọi hoặc nhắn Zalo 0979 232 233.</p>
    <div class="gnp-cta">
      <a class="gnp-btn gnp-btn--gold" href="#dang-ky">Đăng ký làm đối tác</a>
      <a class="gnp-btn gnp-btn--ghost" href="tel:+84979232233">Gọi 0979 232 233</a>
    </div>
  </section>

</div>
<?php
    return ob_get_clean();
}

/**
 * Thay toàn bộ nội dung trang /doi-tac/ bằng bản dựng lại ở trên.
 * Nội dung cũ vẫn nằm nguyên trong database — xoá filter này là nó hiện lại.
 */
function gn_replace_partner_page($content) {
    if (is_admin() || !in_the_loop() || !is_main_query()) return $content;
    if (!is_page()) return $content;
    $slug = get_post_field('post_name', get_queried_object_id());
    if ($slug !== 'doi-tac') return $content;
    return gn_partner_page_html();
}
add_filter('the_content', 'gn_replace_partner_page', 5);

/* --------------------------------------------------------------------------
   Tiêu đề SEO và meta description của /doi-tac/ đang ghi "Hoa Hồng 10–25%",
   lấy từ Yoast trong wp-admin. Con số đó thuộc hệ 4 hạng cũ, giờ sai.
   Công thức hiện tại: luỹ tiến theo ngày 10 / 12 / 15% + thưởng 2% theo tháng.
   Sửa qua filter để không phải vào wp-admin. Muốn đổi lại: xoá khối này rồi
   sửa thẳng trong Yoast.
   -------------------------------------------------------------------------- */

function gn_is_partner_page() {
    if (is_admin() || !is_page()) return false;
    return get_post_field('post_name', get_queried_object_id()) === 'doi-tac';
}

function gn_partner_seo_title($title) {
    return gn_is_partner_page()
        ? 'Đối tác Gánh Ngon — hoa hồng luỹ tiến 10 · 12 · 15% mỗi ngày'
        : $title;
}
function gn_partner_seo_desc($desc) {
    return gn_is_partner_page()
        ? 'Nhận mã QR riêng, khách quét là hoa hồng về bạn. Luỹ tiến theo doanh số từng ngày: 10% · 12% · 15%, thêm 2% khi tháng đạt 100 triệu. Chuyển khoản ngày 5, có bảng kê từng đơn.'
        : $desc;
}

add_filter('wpseo_title',            'gn_partner_seo_title', 20);
add_filter('wpseo_opengraph_title',  'gn_partner_seo_title', 20);
add_filter('wpseo_twitter_title',    'gn_partner_seo_title', 20);
add_filter('pre_get_document_title', 'gn_partner_seo_title', 20);
add_filter('wpseo_metadesc',           'gn_partner_seo_desc', 25);
add_filter('wpseo_opengraph_desc',     'gn_partner_seo_desc', 20);
add_filter('wpseo_twitter_description','gn_partner_seo_desc', 20);

/**
 * page.php in sẵn một khối hero có <h1> tiêu đề. Trang đối tác đã có hero riêng
 * nên hai tiêu đề lớn chồng nhau. Gắn class để CSS ẩn hero mặc định đi.
 */
function gn_partner_body_class($classes) {
    if (gn_is_partner_page()) $classes[] = 'gn-partner-page';
    return $classes;
}
add_filter('body_class', 'gn_partner_body_class');

// JSON-LD của Yoast đi đường riêng, không qua wpseo_title — phải sửa thêm ở đây
function gn_partner_schema_webpage($data) {
    if (!gn_is_partner_page()) return $data;
    if (isset($data['name']))        $data['name']        = gn_partner_seo_title('');
    if (isset($data['description'])) $data['description'] = gn_partner_seo_desc('');
    return $data;
}
add_filter('wpseo_schema_webpage', 'gn_partner_schema_webpage', 20);

/**
 * Gánh Ngon — lớp thương mại: gán mã đối tác, hoa hồng luỹ tiến, voucher.
 *
 * Bổ sung cho sao-booking-engine, không thay thế. Ba lỗ hổng của bản gốc:
 *   1. partner_login() chỉ trả lỗi -> hồ sơ đăng ký đối tác bị vứt đi
 *   2. create_booking() không đọc ref_code -> không có dữ liệu tính hoa hồng
 *   3. sao_bookings không có cột đối tác lẫn doanh số thực thu
 *
 * Hoa hồng: luỹ tiến theo DOANH SỐ TỪNG NGÀY của mỗi đối tác
 *   0 – 5.000.000đ    : 10%
 *   5.000.000 – 10tr  : 12%
 *   trên 10.000.000đ  : 15%
 * Cộng 2% tổng doanh số tháng nếu luỹ kế tháng đạt từ 100.000.000đ.
 *
 * @package ganhngon
 */



define('GN_COMMERCE_VERSION', '1.2.0');
define('GN_REF_COOKIE', 'gn_ref');
define('GN_REF_DAYS', 30);

function gn_tbl($name) { global $wpdb; return $wpdb->prefix . 'sao_' . $name; }

/* ==========================================================================
   1. LƯỢC ĐỒ
   ========================================================================== */

function gn_sql_ident($name) {
    return preg_replace('/[^A-Za-z0-9_]/', '', (string) $name);
}

/** SHOW COLUMNS uses the table privilege. The schema catalog is often blocked on shared hosts. */
function gn_table_columns($table, $refresh = false) {
    static $cache = [];
    $table = gn_sql_ident($table);
    if ($table === '') return [];
    if ($refresh) unset($cache[$table]);
    if (isset($cache[$table])) return $cache[$table];
    global $wpdb;
    $rows = $wpdb->get_results("SHOW COLUMNS FROM `{$table}`");
    $names = [];
    if (is_array($rows)) {
        foreach ($rows as $row) {
            if (!empty($row->Field)) $names[] = (string) $row->Field;
        }
    }
    if ($names) $cache[$table] = $names;
    return $names;
}

function gn_column_exists($table, $column) {
    return in_array((string) $column, gn_table_columns($table), true);
}

function gn_index_exists($table, $index) {
    global $wpdb;
    $table = gn_sql_ident($table);
    $index = gn_sql_ident($index);
    if ($table === '' || $index === '') return false;
    $rows = $wpdb->get_results("SHOW INDEX FROM `{$table}` WHERE Key_name = '{$index}'");
    return is_array($rows) && $rows !== [];
}

/**
 * Add missing columns, then re-read the table. Returns names still absent
 * so the caller can refuse a row that would drop those fields into notes.
 *
 * @param array<string,string> $defs column => SQL type clause
 * @return array<int,string>
 */
function gn_ensure_columns($table, array $defs) {
    $safe = gn_sql_ident($table);
    if ($safe === '' || !$defs) return array_keys($defs);
    $have = gn_table_columns($safe, true);
    global $wpdb;
    foreach ($defs as $col => $ddl) {
        $col = gn_sql_ident($col);
        if ($col === '' || in_array($col, $have, true)) continue;
        $wpdb->query("ALTER TABLE `{$safe}` ADD COLUMN {$col} {$ddl}");
    }
    $have = gn_table_columns($safe, true);
    $still = [];
    foreach ($defs as $col => $ddl) {
        $col = gn_sql_ident($col);
        if ($col !== '' && !in_array($col, $have, true)) $still[] = $col;
    }
    return $still;
}

function gn_ensure_index($table, $index, $sql) {
    if (gn_index_exists($table, $index)) return;
    global $wpdb;
    $wpdb->query($sql);
}

function gn_commerce_migrate() {
    global $wpdb;
    $charset = $wpdb->get_charset_collate();
    $bookings = gn_tbl('bookings');
    $partners = gn_tbl('partners');

    // --- cột gán đối tác cho từng đơn: bản gốc hoàn toàn không có ---
    $add = [
        'partner_id' => "ALTER TABLE {$bookings} ADD COLUMN partner_id INT NULL DEFAULT NULL",
        'ref_code'   => "ALTER TABLE {$bookings} ADD COLUMN ref_code VARCHAR(50) NULL DEFAULT NULL",
        'revenue'    => "ALTER TABLE {$bookings} ADD COLUMN revenue DECIMAL(12,2) NOT NULL DEFAULT 0",
        'served_on'  => "ALTER TABLE {$bookings} ADD COLUMN served_on DATE NULL DEFAULT NULL",
    ];
    foreach ($add as $col => $sql) {
        if (!gn_column_exists($bookings, $col)) $wpdb->query($sql);
    }
    if (!gn_column_exists($bookings, 'qr_scanned_at')) {
        $wpdb->query("ALTER TABLE {$bookings} ADD COLUMN qr_scanned_at DATETIME NULL DEFAULT NULL");
    }
    $facts_missing = gn_ensure_columns($bookings, gn_booking_fact_column_sql());
    gn_ensure_index($bookings, 'gn_partner_day', "ALTER TABLE `{$bookings}` ADD INDEX gn_partner_day (partner_id, served_on)");
    if (!$facts_missing) {
        gn_ensure_index($bookings, 'gn_same_day', "ALTER TABLE `{$bookings}` ADD INDEX gn_same_day (booking_date, same_day)");
    }

    // --- đối tác: token cổng riêng + thông tin trả tiền ---
    foreach ([
        'portal_token' => "ALTER TABLE {$partners} ADD COLUMN portal_token VARCHAR(64) NULL DEFAULT NULL",
        'area'         => "ALTER TABLE {$partners} ADD COLUMN area VARCHAR(255) NULL DEFAULT NULL",
        'social_link'  => "ALTER TABLE {$partners} ADD COLUMN social_link VARCHAR(255) NULL DEFAULT NULL",
        'intro'        => "ALTER TABLE {$partners} ADD COLUMN intro TEXT NULL",
        'bank_info'    => "ALTER TABLE {$partners} ADD COLUMN bank_info VARCHAR(255) NULL DEFAULT NULL",
    ] as $col => $sql) {
        if (!gn_column_exists($partners, $col)) $wpdb->query($sql);
    }
    $role_missing = gn_ensure_columns($partners, gn_partner_role_column_sql());
    if (!$role_missing) {
        gn_ensure_index($partners, 'gn_role_status', "ALTER TABLE `{$partners}` ADD INDEX gn_role_status (role, status)");
    }
    if (gn_column_exists($partners, 'role')) {
        $wpdb->query("UPDATE {$partners} SET role='kol' WHERE type IN ('kol','blogger') AND role IN ('','partner')");
        $wpdb->query("UPDATE {$partners} SET role='koc' WHERE type='koc' AND role IN ('','partner')");
        $wpdb->query("UPDATE {$partners} SET role='affiliate' WHERE type IN ('affiliate','ctv','cong-tac-vien') AND role IN ('','partner')");
    }

    require_once ABSPATH . 'wp-admin/includes/upgrade.php';

    dbDelta("CREATE TABLE " . gn_tbl('scans') . " (
        id INT AUTO_INCREMENT PRIMARY KEY,
        partner_id INT NOT NULL,
        medium VARCHAR(30) NOT NULL DEFAULT 'digital',
        target VARCHAR(30) NOT NULL DEFAULT 'dat-ban',
        ua_hash CHAR(32) NULL,
        scanned_on DATE NOT NULL,
        created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
        KEY partner_day (partner_id, scanned_on)
    ) $charset");

    dbDelta("CREATE TABLE " . gn_tbl('vouchers') . " (
        id INT AUTO_INCREMENT PRIMARY KEY,
        code VARCHAR(24) NOT NULL,
        partner_id INT NULL DEFAULT NULL,
        ref_code VARCHAR(50) NULL DEFAULT NULL,
        face_value DECIMAL(12,2) NOT NULL DEFAULT 0,
        price DECIMAL(12,2) NOT NULL DEFAULT 0,
        balance DECIMAL(12,2) NOT NULL DEFAULT 0,
        status VARCHAR(20) NOT NULL DEFAULT 'unpaid',
        buyer_name VARCHAR(255) NULL,
        buyer_phone VARCHAR(50) NULL,
        buyer_email VARCHAR(255) NULL,
        hold_until DATE NULL,
        expires_on DATE NULL,
        paid_on DATE NULL,
        created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
        UNIQUE KEY code (code),
        KEY partner_paid (partner_id, paid_on),
        KEY status_idx (status)
    ) $charset");

    dbDelta("CREATE TABLE " . gn_tbl('voucher_txn') . " (
        id INT AUTO_INCREMENT PRIMARY KEY,
        voucher_id INT NOT NULL,
        kind VARCHAR(20) NOT NULL,
        amount DECIMAL(12,2) NOT NULL DEFAULT 0,
        partner_id INT NULL DEFAULT NULL,
        note VARCHAR(255) NULL,
        happened_on DATE NOT NULL,
        created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
        KEY voucher (voucher_id),
        KEY partner_day (partner_id, happened_on)
    ) $charset");

    if ($facts_missing || $role_missing) return false;
    update_option('gn_commerce_version', GN_COMMERCE_VERSION);
    return true;
}

add_action('init', function () {
    if (get_option('gn_commerce_version') !== GN_COMMERCE_VERSION) {
        if (gn_commerce_migrate()) flush_rewrite_rules();
    }
}, 5);

/* ==========================================================================
   2. MÁY TÍNH HOA HỒNG
   ========================================================================== */

/**
 * Hoa hồng của MỘT ngày, luỹ tiến theo bậc.
 * Ví dụ 12.850.000đ = 5tr×10% + 5tr×12% + 2,85tr×15% = 1.527.500đ
 */
function gn_commission_for_day($revenue) {
    $revenue = max(0, (float) $revenue);
    $b1 = min($revenue, 5000000);
    $b2 = min(max($revenue - 5000000, 0), 5000000);
    $b3 = max($revenue - 10000000, 0);
    return round($b1 * 0.10 + $b2 * 0.12 + $b3 * 0.15);
}

function gn_commission_breakdown($revenue) {
    $revenue = max(0, (float) $revenue);
    $b1 = min($revenue, 5000000);
    $b2 = min(max($revenue - 5000000, 0), 5000000);
    $b3 = max($revenue - 10000000, 0);
    return [
        ['tu' => 0,        'den' => 5000000,  'ty_le' => 10, 'doanh_so' => $b1, 'hoa_hong' => round($b1 * 0.10)],
        ['tu' => 5000000,  'den' => 10000000, 'ty_le' => 12, 'doanh_so' => $b2, 'hoa_hong' => round($b2 * 0.12)],
        ['tu' => 10000000, 'den' => null,     'ty_le' => 15, 'doanh_so' => $b3, 'hoa_hong' => round($b3 * 0.15)],
    ];
}

define('GN_BONUS_THRESHOLD', 100000000);
define('GN_BONUS_RATE', 0.02);

/** Doanh số hợp lệ theo từng ngày của một đối tác trong tháng YYYY-MM. */
function gn_partner_daily_revenue($partner_id, $ym) {
    global $wpdb;
    $from = $ym . '-01';
    $to   = date('Y-m-t', strtotime($from));
    $days = [];

    // đặt bàn: chỉ tính khi khách ĐÃ ĐẾN và đã thanh toán
    $rows = $wpdb->get_results($wpdb->prepare(
        "SELECT served_on AS d, SUM(revenue) AS amt FROM " . gn_tbl('bookings') . "
         WHERE partner_id = %d AND served_on BETWEEN %s AND %s
           AND booking_status IN ('served','checked_in','completed')
         GROUP BY served_on", $partner_id, $from, $to));
    foreach ($rows as $r) $days[$r->d] = ($days[$r->d] ?? 0) + (float) $r->amt;

    // voucher: tính vào ngày khách TRẢ TIỀN, gồm cả tiền nạp thêm
    $rows = $wpdb->get_results($wpdb->prepare(
        "SELECT happened_on AS d, SUM(amount) AS amt FROM " . gn_tbl('voucher_txn') . "
         WHERE partner_id = %d AND happened_on BETWEEN %s AND %s
           AND kind IN ('pay','topup')
         GROUP BY happened_on", $partner_id, $from, $to));
    foreach ($rows as $r) $days[$r->d] = ($days[$r->d] ?? 0) + (float) $r->amt;

    // voucher hoàn tiền trong 7 ngày: trừ lại đúng ngày hoàn
    $rows = $wpdb->get_results($wpdb->prepare(
        "SELECT happened_on AS d, SUM(amount) AS amt FROM " . gn_tbl('voucher_txn') . "
         WHERE partner_id = %d AND happened_on BETWEEN %s AND %s AND kind = 'refund'
         GROUP BY happened_on", $partner_id, $from, $to));
    foreach ($rows as $r) $days[$r->d] = ($days[$r->d] ?? 0) - (float) $r->amt;

    ksort($days);
    return $days;
}

/** Tổng kết một kỳ: hoa hồng cộng từ từng ngày + thưởng 2% nếu tháng đạt mốc. */
function gn_partner_period($partner_id, $ym) {
    $days = gn_partner_daily_revenue($partner_id, $ym);
    $revenue = 0; $commission = 0; $detail = [];
    foreach ($days as $d => $amt) {
        $amt = max(0, $amt);
        $c = gn_commission_for_day($amt);
        $revenue += $amt; $commission += $c;
        $detail[] = ['ngay' => $d, 'doanh_so' => $amt, 'hoa_hong' => $c];
    }
    $bonus = $revenue >= GN_BONUS_THRESHOLD ? round($revenue * GN_BONUS_RATE) : 0;
    // Hoa hồng phẳng từ voucher lô (bán sỉ) — sổ riêng, cộng vào phải trả.
    $phang = function_exists('gn_batch_commission_period') ? gn_batch_commission_period($partner_id, $ym) : ['tong' => 0, 'lo' => 0, 'topup' => 0];
    $phai_tra = round($commission + $bonus + $phang['tong']);
    return [
        'ky'             => $ym,
        'doanh_so'       => round($revenue),
        'hoa_hong'       => round($commission),
        'thuong_2pt'     => $bonus,
        'hoa_hong_lo'    => round($phang['lo']),
        'hoa_hong_topup_lo' => round($phang['topup']),
        'hoa_hong_phang' => round($phang['tong']),
        'dat_moc_thuong' => $revenue >= GN_BONUS_THRESHOLD,
        'con_thieu'      => max(0, GN_BONUS_THRESHOLD - $revenue),
        'phai_tra'       => $phai_tra,
        'ty_le_thuc'     => $revenue > 0 ? round(($commission + $bonus) / $revenue * 100, 2) : 0,
        'so_ngay'        => count($detail),
        'theo_ngay'      => $detail,
    ];
}

/* ==========================================================================
   3. GÁN MÃ ĐỐI TÁC
   ========================================================================== */

function gn_partner_by_code($code) {
    global $wpdb;
    if (!$code) return null;
    return $wpdb->get_row($wpdb->prepare(
        "SELECT * FROM " . gn_tbl('partners') . " WHERE ref_code = %s AND status = 'active'",
        strtoupper(trim($code))));
}

/** Mã đối tác đang gán cho phiên này: ưu tiên tham số trên URL, sau đó cookie. */
function gn_current_ref() {
    if (!empty($_REQUEST['ref'])) return sanitize_text_field(wp_unslash($_REQUEST['ref']));
    if (!empty($_COOKIE[GN_REF_COOKIE])) return sanitize_text_field(wp_unslash($_COOKIE[GN_REF_COOKIE]));
    return '';
}

function gn_set_ref_cookie($code) {
    if (headers_sent()) return;
    setcookie(GN_REF_COOKIE, $code, [
        'expires'  => time() + GN_REF_DAYS * DAY_IN_SECONDS,
        'path'     => '/',
        'secure'   => is_ssl(),
        'httponly' => false,
        'samesite' => 'Lax',
    ]);
}

function gn_set_dish_cookie() {
    if (headers_sent()) return;
    setcookie('gn_mon', 'lau-ga-sau-rieng', [
        'expires'  => time() + GN_REF_DAYS * DAY_IN_SECONDS,
        'path'     => '/',
        'secure'   => is_ssl(),
        'httponly' => false,
        'samesite' => 'Lax',
    ]);
}

/** ?ref= on any URL, not only /p/CODE, so an agent link to the dish page still attributes. */
add_action('init', function () {
    if (is_admin()) return;
    if (!empty($_GET['ref'])) {
        $partner = gn_partner_by_code(sanitize_text_field(wp_unslash($_GET['ref'])));
        if ($partner) gn_set_ref_cookie($partner->ref_code);
    }
    $mon = isset($_GET['mon']) ? sanitize_text_field(wp_unslash($_GET['mon'])) : '';
    if ($mon === 'lau-ga' || $mon === 'lau-ga-sau-rieng') gn_set_dish_cookie();
}, 20);

/** /p/GN-P042 hoặc /p/GN-P042/voucher — ghi lượt quét rồi chuyển hướng. */
add_action('init', function () {
    add_rewrite_rule('^p/([A-Za-z0-9\-]+)/?([a-z\-]*)/?$', 'index.php?gn_ref_code=$matches[1]&gn_ref_target=$matches[2]', 'top');
}, 6);

add_filter('query_vars', function ($v) { $v[] = 'gn_ref_code'; $v[] = 'gn_ref_target'; return $v; });

add_action('template_redirect', function () {
    $code = get_query_var('gn_ref_code');
    if (!$code) return;
    $target = get_query_var('gn_ref_target') ?: 'dat-ban';
    $partner = gn_partner_by_code($code);

    if ($partner) {
        global $wpdb;
        gn_set_ref_cookie($partner->ref_code);
        if (in_array($target, ['lau-ga', 'mon'], true)) gn_set_dish_cookie();
        $wpdb->insert(gn_tbl('scans'), [
            'partner_id' => $partner->id,
            'medium'     => sanitize_text_field($_GET['m'] ?? 'digital'),
            'target'     => $target,
            'ua_hash'    => md5(($_SERVER['HTTP_USER_AGENT'] ?? '') . date('Y-m-d')),
            'scanned_on' => current_time('Y-m-d'),
        ]);
    }

    $map = [
        'dat-ban'  => '/dat-ban/',
        'voucher'  => '/voucher/',
        'thuc-don' => '/thuc-don/',
        'lau-ga'   => '/lau-ga-sau-rieng/',
        'mon'      => '/lau-ga-sau-rieng/',
        ''         => '/dat-ban/',
    ];
    wp_safe_redirect(home_url($map[$target] ?? '/dat-ban/'));
    exit;
});

/* ==========================================================================
   4. VOUCHER
   ========================================================================== */

function gn_voucher_code() {
    // bỏ O, 0, I, 1 để khách đọc qua điện thoại không nhầm
    $abc = 'ABCDEFGHJKLMNPQRSTUVWXYZ23456789';
    $out = '';
    for ($i = 0; $i < 8; $i++) $out .= $abc[random_int(0, strlen($abc) - 1)];
    return 'GN-V-' . substr($out, 0, 4) . '-' . substr($out, 4, 4);
}

function gn_voucher_txn($voucher_id, $kind, $amount, $partner_id = null, $note = '') {
    global $wpdb;
    $wpdb->insert(gn_tbl('voucher_txn'), [
        'voucher_id'  => (int) $voucher_id,
        'kind'        => $kind,
        'amount'      => (float) $amount,
        'partner_id'  => $partner_id ? (int) $partner_id : null,
        'note'        => $note,
        'happened_on' => current_time('Y-m-d'),
    ]);
}

/** Phát hành voucher ở trạng thái CHƯA THANH TOÁN, giữ chỗ 7 ngày. */
function gn_voucher_issue($args) {
    global $wpdb;
    $partner = gn_partner_by_code(gn_current_ref());
    $code = gn_voucher_code();
    $face = (float) $args['face_value'];
    $price = (float) $args['price'];

    $wpdb->insert(gn_tbl('vouchers'), [
        'code'        => $code,
        'partner_id'  => $partner ? $partner->id : null,
        'ref_code'    => $partner ? $partner->ref_code : null,
        'face_value'  => $face,
        'price'       => $price,
        'balance'     => 0,                       // chưa trả tiền thì chưa có số dư
        'status'      => 'unpaid',
        'buyer_name'  => sanitize_text_field($args['buyer_name'] ?? ''),
        'buyer_phone' => sanitize_text_field($args['buyer_phone'] ?? ''),
        'buyer_email' => sanitize_email($args['buyer_email'] ?? ''),
        'hold_until'  => date('Y-m-d', strtotime('+7 days')),
        'expires_on'  => date('Y-m-d', strtotime('+12 months')),
    ]);
    $id = $wpdb->insert_id;
    gn_voucher_txn($id, 'issue', 0, $partner ? $partner->id : null, 'Giữ chỗ, chưa thanh toán');
    gn_voucher_send_email($id);
    do_action('gn_voucher_issued', $id);   // đẩy sang WCC
    return $id;
}

/** Khách trả tiền — tại quầy hoặc chuyển khoản. Đây mới là lúc tính doanh số. */
function gn_voucher_mark_paid($voucher_id, $amount = null) {
    global $wpdb;
    $v = $wpdb->get_row($wpdb->prepare("SELECT * FROM " . gn_tbl('vouchers') . " WHERE id = %d", $voucher_id));
    if (!$v || $v->status !== 'unpaid') return false;
    $paid = $amount === null ? (float) $v->price : (float) $amount;

    $wpdb->update(gn_tbl('vouchers'), [
        'status'  => 'paid',
        'balance' => (float) $v->face_value,
        'paid_on' => current_time('Y-m-d'),
    ], ['id' => $voucher_id]);

    gn_voucher_txn($voucher_id, 'pay', $paid, $v->partner_id, 'Khách thanh toán');
    gn_voucher_send_email($voucher_id);
    do_action('gn_voucher_paid', $voucher_id, $paid);        // hoá đơn cho khách + báo hoa hồng đối tác
    return true;
}

/** Nạp thêm vào voucher đã trả tiền. Tiền nạp cũng tính doanh số cho đối tác. */
function gn_voucher_topup($voucher_id, $add_face, $paid_amount) {
    global $wpdb;
    $v = $wpdb->get_row($wpdb->prepare("SELECT * FROM " . gn_tbl('vouchers') . " WHERE id = %d", $voucher_id));
    if (!$v || !in_array($v->status, ['paid'], true)) return false;
    $wpdb->update(gn_tbl('vouchers'), [
        'balance'    => (float) $v->balance + (float) $add_face,
        'face_value' => (float) $v->face_value + (float) $add_face,
        'expires_on' => date('Y-m-d', strtotime('+12 months')),
    ], ['id' => $voucher_id]);
    gn_voucher_txn($voucher_id, 'topup', $paid_amount, $v->partner_id, 'Nạp thêm');
    do_action('gn_voucher_topped_up', $voucher_id, $add_face, $paid_amount);
    return true;
}

/**
 * Nhân viên quét mã tại quầy, trừ vào hoá đơn.
 *
 * Hai chỗ bản trước sai, đều dẫn tới mất tiền:
 *   1. min($amount, $balance) không chặn dưới -> POST amount=-5000000 làm phép trừ
 *      thành phép cộng, voucher tự nạp thêm 5 triệu.
 *   2. Đọc rồi ghi giá trị tuyệt đối, không khoá -> hai máy quầy quét cùng lúc
 *      cùng đọc số dư cũ, cùng ghi 0, một voucher 2 triệu cấn được hai hoá đơn.
 * Giờ trừ bằng một câu UPDATE nguyên tử có điều kiện số dư trong WHERE.
 */
function gn_voucher_redeem($code, $amount) {
    global $wpdb;
    $amount = (float) $amount;
    if ($amount <= 0) return ['ok' => false, 'msg' => 'Số tiền trừ phải lớn hơn 0'];

    $t = gn_tbl('vouchers');
    $v = $wpdb->get_row($wpdb->prepare("SELECT * FROM {$t} WHERE code = %s", $code));
    if (!$v) return ['ok' => false, 'msg' => 'Không tìm thấy voucher'];
    if ($v->status === 'unpaid') return ['ok' => false, 'msg' => 'Voucher CHƯA THANH TOÁN — thu ' . number_format($v->price) . 'đ trước khi dùng'];
    if ($v->status === 'used') return ['ok' => false, 'msg' => 'Voucher đã dùng hết'];
    if ($v->status === 'refunded') return ['ok' => false, 'msg' => 'Voucher đã hoàn tiền'];
    if ($v->expires_on && $v->expires_on < current_time('Y-m-d')) return ['ok' => false, 'msg' => 'Voucher hết hạn ' . $v->expires_on];

    $use = min($amount, (float) $v->balance);
    if ($use <= 0) return ['ok' => false, 'msg' => 'Voucher không còn số dư'];

    // Trừ nguyên tử: chỉ thành công khi số dư vẫn còn đủ tại đúng thời điểm ghi.
    $ok = $wpdb->query($wpdb->prepare(
        "UPDATE {$t}
            SET balance = balance - %f,
                status  = CASE WHEN balance - %f <= 0 THEN 'used' ELSE 'paid' END
          WHERE id = %d AND status = 'paid' AND balance >= %f",
        $use, $use, $v->id, $use));

    if ($ok !== 1) {
        return ['ok' => false, 'msg' => 'Số dư vừa thay đổi ở máy khác. Quét lại để lấy số mới.'];
    }

    $left = (float) $wpdb->get_var($wpdb->prepare("SELECT balance FROM {$t} WHERE id = %d", $v->id));
    gn_voucher_txn($v->id, 'redeem', $use, $v->partner_id, 'Trừ vào hoá đơn');
    do_action('gn_voucher_redeemed', $v->id, $use, $left);   // biên nhận cảm ơn cho khách
    return ['ok' => true, 'da_dung' => $use, 'con_lai' => $left];
}

function gn_qr_url($data, $size = 240) {
    return 'https://api.qrserver.com/v1/create-qr-code/?size=' . (int) $size . 'x' . (int) $size
         . '&margin=8&data=' . rawurlencode($data);
}

function gn_voucher_send_email($voucher_id) {
    global $wpdb;
    $v = $wpdb->get_row($wpdb->prepare("SELECT * FROM " . gn_tbl('vouchers') . " WHERE id = %d", $voucher_id));
    if (!$v || empty($v->buyer_email)) return;

    $unpaid = ($v->status === 'unpaid');
    $qr = gn_qr_url(home_url('/voucher/?c=' . $v->code), 220);
    $money = fn($n) => number_format((float) $n, 0, ',', '.') . 'đ';

    // Thông tin theo dõi đầy đủ ngay trong email, để khách và nhân viên đối chiếu
    // không phải hỏi ai. Mã QR vẫn chỉ chứa link — số dư đổi theo thời gian.
    $partner = $v->partner_id
        ? $wpdb->get_row($wpdb->prepare("SELECT ref_code, contact, company FROM " . gn_tbl('partners') . " WHERE id = %d", $v->partner_id))
        : null;
    $topup = (float) $wpdb->get_var($wpdb->prepare(
        "SELECT COALESCE(SUM(amount),0) FROM " . gn_tbl('voucher_txn') . " WHERE voucher_id = %d AND kind = 'topup'", $voucher_id));
    $meta = [
        'Mã voucher'     => $v->code,
        'Người mua'      => $v->buyer_name ?: '—',
        'Ngày mua'       => date('d/m/Y H:i', strtotime($v->created_at)),
        'Mệnh giá'       => $money($v->face_value),
        'Giá đã trả'     => $money($v->price),
        'Số dư hiện tại' => $money($v->balance),
        'Hạn dùng'       => date('d/m/Y', strtotime($v->expires_on)),
    ];
    if ($topup > 0) $meta['Đã nạp thêm'] = $money($topup);
    if ($partner)   $meta['Đối tác giới thiệu'] = $partner->ref_code . ' · ' . ($partner->contact ?: $partner->company);
    if ($unpaid && $v->hold_until) $meta['Giữ chỗ đến'] = date('d/m/Y', strtotime($v->hold_until));

    $meta_rows = '';
    foreach ($meta as $mk => $mv) {
        $meta_rows .= '<tr><td style="padding:7px 0;border-bottom:1px solid #F0E7D8;font:400 13px/1.5 Arial,sans-serif;color:#6E5D4E;width:46%">'
                    . esc_html($mk) . '</td><td style="padding:7px 0;border-bottom:1px solid #F0E7D8;'
                    . 'font:600 13px/1.5 Arial,sans-serif;color:#1F1710">' . esc_html($mv) . '</td></tr>';
    }

    $vietqr_block = '';
    if ($unpaid && function_exists('gn_vietqr_url')) {
        $vietqr_block =
          '<div style="text-align:center;margin:22px 0 0;padding:20px;background:#FAF7F0;border-radius:10px">'
        . '<div style="font:600 10px/1.5 Arial,sans-serif;letter-spacing:.05em;color:#7A5A12;margin-bottom:10px">TRẢ TRƯỚC BẰNG VIETQR</div>'
        . '<img src="' . esc_url(gn_vietqr_url($v->price, 'GNV ' . $v->code)) . '" width="220" alt="VietQR"'
        . ' style="max-width:220px;background:#fff;border-radius:10px;padding:8px">'
        . '<div style="margin-top:10px;font:400 13px/1.8 Arial,sans-serif;color:#5A4B3E">'
        . '<b>' . esc_html(GN_BANK_NAME) . '</b> — ' . esc_html(GN_BANK_ACC) . '<br>'
        . esc_html(GN_BANK_OWNER) . '<br>Số tiền <b>' . $money($v->price) . '</b><br>'
        . 'Nội dung <b>GNV ' . esc_html($v->code) . '</b></div>'
        . '<div style="margin-top:8px;font:400 12px/1.6 Arial,sans-serif;color:#6E5D4E">'
        . 'Chuyển xong nhắn Zalo 0979 232 233 kèm mã voucher.</div></div>';
    }

    $subject = $unpaid
        ? 'Voucher Gánh Ngon đang giữ chỗ — trả ' . $money($v->price) . ' khi đến là dùng được'
        : 'Voucher Gánh Ngon của bạn đã sẵn sàng · ' . $v->code;

    $band = $unpaid
        ? '<tr><td style="background:#B45309;color:#fff;padding:12px 24px;font:700 13px/1.5 Arial,sans-serif;letter-spacing:.04em">CHƯA THANH TOÁN · TRẢ TẠI NHÀ HÀNG</td></tr>'
        : '<tr><td style="background:#1E7A4C;color:#fff;padding:12px 24px;font:700 13px/1.5 Arial,sans-serif;letter-spacing:.04em">ĐÃ THANH TOÁN ' . $money($v->price) . '</td></tr>';

    $intro = $unpaid
        ? 'Voucher đang được giữ chỗ đến hết ngày ' . date('d/m/Y', strtotime($v->hold_until)) . '. Chưa trả tiền thì chưa dùng được. Anh/chị có thể trả trước bằng VietQR, hoặc cứ đến nhà hàng rồi trả ' . $money($v->price) . ' tại quầy — nhân viên quét mã là voucher có hiệu lực ngay.'
        : 'Voucher dùng được ngay. Không cần in, chỉ cần đưa mã QR dưới đây cho nhân viên quét khi thanh toán.';

    $body = '<div style="background:#F0E9DC;padding:24px 12px">
      <table role="presentation" cellpadding="0" cellspacing="0" style="max-width:600px;margin:0 auto;width:100%;background:#fff;border-radius:12px;overflow:hidden">
        <tr><td style="background:#2C1810;padding:28px 24px;text-align:center">
          <div style="font:600 26px/1.2 Georgia,serif;letter-spacing:.05em;color:#D4AF37">GÁNH NGON</div>
          <div style="font:600 9px/1.4 Arial,sans-serif;letter-spacing:.08em;color:#C9B79E;margin-top:4px">ĐẶC SẢN VIỆT NAM · PHÚ QUỐC</div>
        </td></tr>
        ' . $band . '
        <tr><td style="padding:28px 24px;font:400 15px/1.7 Arial,sans-serif;color:#5A4B3E">
          <p style="margin:0 0 14px">Chào ' . esc_html($v->buyer_name ?: 'quý khách') . ',</p>
          <p style="margin:0 0 20px">' . esc_html($intro) . '</p>
          <table role="presentation" cellpadding="0" cellspacing="0" style="width:100%;border:2px ' . ($unpaid ? 'dashed #B45309' : 'solid #D4AF37') . ';border-radius:12px;background:' . ($unpaid ? '#fff' : '#2C1810') . '">
            <tr>
              <td style="padding:20px">
                <div style="font:600 10px/1.5 Arial,sans-serif;letter-spacing:.05em;color:' . ($unpaid ? '#7A5A12' : '#C9B79E') . '">VOUCHER TIỀN MẶT</div>
                <div style="font:600 34px/1.15 Georgia,serif;color:' . ($unpaid ? '#1F1710' : '#fff') . ';margin:6px 0">' . $money($v->face_value) . '</div>
                ' . ($unpaid ? '<div style="font:700 15px/1.4 Arial,sans-serif;color:#B45309;margin-bottom:6px">Cần trả ' . $money($v->price) . '</div>' : '') . '
                <div style="font:600 12px/1.5 Arial,sans-serif;letter-spacing:.03em;color:' . ($unpaid ? '#7A5A12' : '#D4AF37') . '">' . esc_html($v->code) . '</div>
                <div style="font:400 12px/1.5 Arial,sans-serif;color:' . ($unpaid ? '#6E5D4E' : '#C9B79E') . ';margin-top:4px">Hạn dùng ' . date('d/m/Y', strtotime($v->expires_on)) . '</div>
              </td>
              <td style="padding:20px;text-align:right;width:130px">
                <img src="' . esc_url($qr) . '" width="110" height="110" alt="Mã QR voucher ' . esc_attr($v->code) . '" style="display:block;background:#fff;border-radius:8px;padding:6px">
              </td>
            </tr>
          </table>
          <table role="presentation" cellpadding="0" cellspacing="0" style="width:100%;margin-top:22px">
            <tr><td colspan="2" style="font:600 10px/1.5 Arial,sans-serif;letter-spacing:.05em;color:#7A5A12;padding-bottom:6px">THÔNG TIN VOUCHER</td></tr>
            ' . $meta_rows . '
          </table>
          ' . $vietqr_block . '
          <p style="margin:22px 0 0;font-size:14px">
            ' . ($unpaid
                ? 'Quá hạn giữ chỗ mà chưa trả thì voucher tự huỷ, không mất phí gì. Muốn giá trị lớn hơn thì nạp thêm trước khi trả — mức nạp càng cao càng lợi.'
                : 'Voucher dùng dần nhiều lần, còn dư thì giữ lại. Chưa dùng thì hoàn tiền 100% trong 7 ngày.') . '
          </p>
        </td></tr>
        <tr><td style="background:#1A0E07;padding:22px 24px;text-align:center;font:400 12px/1.7 Arial,sans-serif;color:#C9B79E">
          Gánh Ngon · 113 Trần Hưng Đạo, Dương Đông, Phú Quốc<br>
          0979 232 233 · Zalo · WhatsApp · contact@ganhngon.com
        </td></tr>
      </table></div>';

    @wp_mail($v->buyer_email, $subject, $body, ['Content-Type: text/html; charset=UTF-8']);
}

/* ==========================================================================
   5. ĐIỂM CUỐI AJAX
   ========================================================================== */

/**
 * Quyền cho mọi thao tác dính tiền.
 *
 * Bản trước neo vào 'edit_posts' — đó là quyền mặc định của vai Cộng tác viên,
 * thường cấp cho người viết blog hay agency SEO. Nghĩa là một cộng tác viên đọc
 * được toàn bộ doanh thu, xoá được đối tác, chốt được doanh số khống, đốt được
 * số dư voucher của khách. Giờ dùng quyền riêng gn_manage_commerce.
 */
define('GN_CAP', 'gn_manage_commerce');

function gn_require_staff() {
    if (!current_user_can(GN_CAP)) wp_send_json_error(['message' => 'Không có quyền'], 403);
}

/** Cấp quyền cho quản trị viên và tạo vai thu ngân dùng riêng ở quầy. */
function gn_setup_roles() {
    if (get_option('gn_roles_version') === '1') return;
    foreach (['administrator', 'editor'] as $r) {
        $role = get_role($r);
        if ($role && !$role->has_cap(GN_CAP)) $role->add_cap(GN_CAP);
    }
    if (!get_role('gn_thu_ngan')) {
        add_role('gn_thu_ngan', 'Thu ngân Gánh Ngon', [
            'read'  => true,
            GN_CAP  => true,
        ]);
    }
    update_option('gn_roles_version', '1');
}
add_action('init', 'gn_setup_roles', 4);

/** Kiểm chứng máy tính hoa hồng — công khai, chỉ đọc, không chạm dữ liệu. */
add_action('wp_ajax_nopriv_gn_commission_check', 'gn_ajax_commission_check');
add_action('wp_ajax_gn_commission_check', 'gn_ajax_commission_check');
function gn_ajax_commission_check() {
    $r = isset($_GET['revenue']) ? (float) $_GET['revenue'] : 12850000;
    wp_send_json_success([
        'doanh_so'  => $r,
        'cac_bac'   => gn_commission_breakdown($r),
        'hoa_hong'  => gn_commission_for_day($r),
        'ty_le_thuc'=> $r > 0 ? round(gn_commission_for_day($r) / $r * 100, 2) : 0,
        'phien_ban' => GN_COMMERCE_VERSION,
    ]);
}

/** Bảng điều khiển đối tác — mở bằng token trong link riêng, không cần mật khẩu. */
add_action('wp_ajax_nopriv_gn_partner_dash', 'gn_ajax_partner_dash');
add_action('wp_ajax_gn_partner_dash', 'gn_ajax_partner_dash');
function gn_ajax_partner_dash() {
    global $wpdb;
    $p = gn_partner_by_token($_GET['t'] ?? '');   // thoát ngay với 401 nếu token sai

    $ym = sanitize_text_field($_GET['ky'] ?? current_time('Y-m'));
    if (!preg_match('/^\d{4}-\d{2}$/', $ym)) $ym = current_time('Y-m');
    $today = current_time('Y-m-d');

    $scans = (int) $wpdb->get_var($wpdb->prepare(
        "SELECT COUNT(*) FROM " . gn_tbl('scans') . " WHERE partner_id = %d AND scanned_on = %s", $p->id, $today));
    $today_rev = (float) $wpdb->get_var($wpdb->prepare(
        "SELECT COALESCE(SUM(revenue),0) FROM " . gn_tbl('bookings') . "
         WHERE partner_id = %d AND served_on = %s AND booking_status IN ('served','checked_in','completed')",
        $p->id, $today));
    $today_book = (int) $wpdb->get_var($wpdb->prepare(
        "SELECT COUNT(*) FROM " . gn_tbl('bookings') . " WHERE partner_id = %d AND served_on = %s", $p->id, $today));
    $today_vou = (int) $wpdb->get_var($wpdb->prepare(
        "SELECT COUNT(*) FROM " . gn_tbl('voucher_txn') . "
         WHERE partner_id = %d AND happened_on = %s AND kind IN ('pay','topup')", $p->id, $today));
    // doanh số voucher hôm nay cộng vào cùng bậc luỹ tiến với đặt bàn
    $today_rev += (float) $wpdb->get_var($wpdb->prepare(
        "SELECT COALESCE(SUM(amount),0) FROM " . gn_tbl('voucher_txn') . "
         WHERE partner_id = %d AND happened_on = %s AND kind IN ('pay','topup')", $p->id, $today));

    wp_send_json_success([
        'doi_tac'   => [
            'ma'         => $p->ref_code,
            'ten'        => $p->contact ?: $p->company,
            'loai'       => $p->type,
            'khu_vuc'    => $p->area,
            'trang_thai' => $p->status,
            'ngan_hang'  => $p->bank_info,
            'link_qr'    => home_url(gn_partner_share_paths($p->ref_code)['table']),
            'link_qr_mon'=> home_url(gn_partner_share_paths($p->ref_code)['signature']),
            'anh_qr'     => gn_qr_url(home_url(gn_partner_share_paths($p->ref_code)['table']), 320),
            'anh_qr_mon' => gn_qr_url(home_url(gn_partner_share_paths($p->ref_code)['signature']), 320),
        ],
        'hom_nay'   => [
            'luot_quet' => $scans,
            'dat_ban'   => $today_book,
            'voucher'   => $today_vou,
            'doanh_so'  => round($today_rev),
            'hoa_hong'  => gn_commission_for_day($today_rev),
            'cac_bac'   => gn_commission_breakdown($today_rev),
        ],
        'ky_hien_tai'    => gn_partner_period($p->id, $ym),
        'bieu_do'        => gn_partner_chart($p->id, 30),
        'giao_dich'      => gn_partner_ledger($p->id, $ym),
        'ky_thanh_toan'  => gn_payout_status($p->id, $ym),
        'doi_soat'       => gn_partner_periods($p->id, 6),
        'moc_thuong'     => [
            'nguong'  => GN_BONUS_THRESHOLD,
            'ty_le'   => GN_BONUS_RATE * 100,
        ],
    ]);
}

/** Tra đối tác theo token cổng riêng. Token sai -> 401 và thoát, không lộ dữ liệu ai. */
function gn_partner_by_token($token) {
    global $wpdb;
    $token = sanitize_text_field($token);
    if (strlen($token) < 20) wp_send_json_error(['message' => 'Thiếu token'], 401);
    $p = $wpdb->get_row($wpdb->prepare(
        "SELECT * FROM " . gn_tbl('partners') . " WHERE portal_token = %s", $token));
    if (!$p) wp_send_json_error(['message' => 'Token không đúng'], 401);
    return $p;
}

/** Doanh số $days ngày gần nhất, đủ mọi ngày kể cả ngày không có đơn. */
function gn_partner_chart($partner_id, $days = 30) {
    $out = [];
    $seen = [];
    $ym_list = array_unique([date('Y-m', strtotime('-' . ($days - 1) . ' days', strtotime(current_time('Y-m-d')))), current_time('Y-m')]);
    foreach ($ym_list as $ym) {
        foreach (gn_partner_daily_revenue($partner_id, $ym) as $d => $amt) $seen[$d] = (float) $amt;
    }
    for ($i = $days - 1; $i >= 0; $i--) {
        $d = date('Y-m-d', strtotime("-$i days", strtotime(current_time('Y-m-d'))));
        $amt = max(0, $seen[$d] ?? 0);
        $out[] = ['ngay' => $d, 'doanh_so' => round($amt), 'hoa_hong' => gn_commission_for_day($amt)];
    }
    return $out;
}

/**
 * Sổ giao dịch của một kỳ: đặt bàn + voucher, kèm cột CỘNG DỒN TRONG NGÀY.
 * Cột cộng dồn cho đối tác thấy vì sao đơn sau lại được tỷ lệ cao hơn đơn trước.
 */
function gn_partner_ledger($partner_id, $ym) {
    global $wpdb;
    $from = $ym . '-01';
    $to   = date('Y-m-t', strtotime($from));
    $rows = [];

    $bk = $wpdb->get_results($wpdb->prepare(
        "SELECT booking_code AS ma, served_on AS ngay, revenue AS tien, customer_name AS ten, created_at
         FROM " . gn_tbl('bookings') . "
         WHERE partner_id = %d AND served_on BETWEEN %s AND %s
           AND booking_status IN ('served','checked_in','completed')",
        $partner_id, $from, $to));
    foreach ($bk as $r) {
        $rows[] = ['ngay' => $r->ngay, 'loai' => 'dat-ban', 'ma' => $r->ma,
                   'mo_ta' => 'Đặt bàn · ' . ($r->ten ?: 'khách lẻ'), 'tien' => (float) $r->tien];
    }

    $vt = $wpdb->get_results($wpdb->prepare(
        "SELECT t.kind, t.amount, t.happened_on, v.code
         FROM " . gn_tbl('voucher_txn') . " t
         LEFT JOIN " . gn_tbl('vouchers') . " v ON v.id = t.voucher_id
         WHERE t.partner_id = %d AND t.happened_on BETWEEN %s AND %s
           AND t.kind IN ('pay','topup','refund')",
        $partner_id, $from, $to));
    foreach ($vt as $r) {
        $sign = $r->kind === 'refund' ? -1 : 1;
        $label = ['pay' => 'Voucher · khách trả tiền', 'topup' => 'Voucher · nạp thêm', 'refund' => 'Voucher · hoàn tiền'];
        $rows[] = ['ngay' => $r->happened_on, 'loai' => 'voucher', 'ma' => $r->code,
                   'mo_ta' => $label[$r->kind], 'tien' => $sign * (float) $r->amount];
    }

    usort($rows, function ($a, $b) {
        return $a['ngay'] === $b['ngay'] ? 0 : ($a['ngay'] < $b['ngay'] ? -1 : 1);
    });

    // cộng dồn trong ngày + hoa hồng biên của chính giao dịch đó
    $run = []; $out = [];
    foreach ($rows as $r) {
        $truoc = $run[$r['ngay']] ?? 0;
        $sau   = max(0, $truoc + $r['tien']);
        $run[$r['ngay']] = $sau;
        $out[] = $r + [
            'cong_don_ngay' => round($sau),
            'hoa_hong'      => gn_commission_for_day($sau) - gn_commission_for_day($truoc),
        ];
    }
    return array_reverse($out);   // mới nhất lên đầu
}

/**
 * Lịch trả tiền của một kỳ. Chốt sổ ngày 1 tháng sau, đối soát 3 ngày,
 * chuyển khoản ngày 5. Trạng thái suy ra từ ngày, trừ khi chủ nhà hàng đã bấm
 * xác nhận đã chuyển — lúc đó lấy theo mốc đã lưu.
 */
function gn_payout_status($partner_id, $ym) {
    $paid_on = get_option('gn_payout_' . (int) $partner_id . '_' . $ym, '');
    $next    = date('Y-m-d', strtotime($ym . '-01 +1 month'));
    $chot    = $next;
    $het_ds  = date('Y-m-d', strtotime($next . ' +3 days'));
    $chuyen  = date('Y-m-d', strtotime($next . ' +4 days'));
    $today   = current_time('Y-m-d');

    if ($paid_on)               $tt = 'da_chuyen';
    elseif ($ym === current_time('Y-m')) $tt = 'dang_chay';
    elseif ($today < $het_ds)   $tt = 'dang_doi_soat';
    elseif ($today < $chuyen)   $tt = 'cho_chuyen';
    else                        $tt = 'qua_han';

    $nhan = [
        'dang_chay'     => 'Kỳ đang chạy',
        'dang_doi_soat' => 'Đang đối soát',
        'cho_chuyen'    => 'Chờ chuyển khoản',
        'da_chuyen'     => 'Đã chuyển khoản',
        'qua_han'       => 'Quá hạn chuyển — báo nhà hàng',
    ];
    return [
        'ky' => $ym, 'chot_so' => $chot, 'doi_soat_den' => $het_ds, 'chuyen_khoan' => $chuyen,
        'trang_thai' => $tt, 'nhan' => $nhan[$tt], 'da_chuyen_ngay' => $paid_on ?: null,
    ];
}

/** Danh sách $n kỳ gần nhất để đối chiếu. */
function gn_partner_periods($partner_id, $n = 6) {
    $out = [];
    for ($i = 0; $i < $n; $i++) {
        $ym = date('Y-m', strtotime(current_time('Y-m') . '-01 -' . $i . ' month'));
        $k = gn_partner_period($partner_id, $ym);
        unset($k['theo_ngay']);                       // bảng kỳ không cần chi tiết ngày
        $out[] = $k + ['thanh_toan' => gn_payout_status($partner_id, $ym)];
    }
    return $out;
}

/** Chi tiết một kỳ — bấm vào một dòng đối soát thì gọi cái này. */
add_action('wp_ajax_nopriv_gn_partner_period', 'gn_ajax_partner_period');
add_action('wp_ajax_gn_partner_period', 'gn_ajax_partner_period');
function gn_ajax_partner_period() {
    $p = gn_partner_by_token($_GET['t'] ?? '');
    $ym = sanitize_text_field($_GET['ky'] ?? current_time('Y-m'));
    if (!preg_match('/^\d{4}-\d{2}$/', $ym)) wp_send_json_error(['message' => 'Kỳ không hợp lệ']);
    wp_send_json_success([
        'ky_hien_tai'   => gn_partner_period($p->id, $ym),
        'giao_dich'     => gn_partner_ledger($p->id, $ym),
        'ky_thanh_toan' => gn_payout_status($p->id, $ym),
    ]);
}

/** Đối tác báo sai lệch số liệu — gửi mail cho nhà hàng, không sửa gì trong sổ. */
add_action('wp_ajax_nopriv_gn_partner_dispute', 'gn_ajax_partner_dispute');
add_action('wp_ajax_gn_partner_dispute', 'gn_ajax_partner_dispute');
function gn_ajax_partner_dispute() {
    $p = gn_partner_by_token($_POST['t'] ?? $_GET['t'] ?? '');
    $ym  = sanitize_text_field($_POST['ky'] ?? current_time('Y-m'));
    $msg = sanitize_textarea_field($_POST['noi_dung'] ?? '');
    if (mb_strlen($msg) < 10) wp_send_json_error(['message' => 'Mô tả sai lệch giúp rõ hơn — tối thiểu 10 ký tự']);
    $k = gn_partner_period($p->id, $ym);
    $to = get_option('admin_email');
    $body = "Đối tác {$p->ref_code} ({$p->contact}) báo sai lệch kỳ {$ym}.\n\n"
          . "Số hệ thống đang tính: doanh số " . number_format($k['doanh_so']) . "đ, "
          . "phải trả " . number_format($k['phai_tra']) . "đ.\n\n"
          . "Nội dung báo:\n{$msg}\n\n"
          . "Điện thoại: " . ($p->phone ?? '') . "\n";
    @wp_mail($to, "[Gánh Ngon] Đối tác {$p->ref_code} báo sai lệch kỳ {$ym}", $body);
    wp_send_json_success(['message' => 'Đã gửi. Nhà hàng liên hệ lại trong 24 giờ.']);
}

/** Bảng điều khiển chủ nhà hàng — gộp đơn trực tiếp và mọi đối tác. */
add_action('wp_ajax_gn_owner_dash', 'gn_ajax_owner_dash');
function gn_ajax_owner_dash() {
    gn_require_staff();
    global $wpdb;
    $ym = sanitize_text_field($_GET['ky'] ?? current_time('Y-m'));
    $from = $ym . '-01';
    $to   = date('Y-m-t', strtotime($from));
    $today = current_time('Y-m-d');

    $today_all = (float) $wpdb->get_var($wpdb->prepare(
        "SELECT COALESCE(SUM(revenue),0) FROM " . gn_tbl('bookings') . " WHERE served_on = %s", $today));
    $today_partner = (float) $wpdb->get_var($wpdb->prepare(
        "SELECT COALESCE(SUM(revenue),0) FROM " . gn_tbl('bookings') . " WHERE served_on = %s AND partner_id IS NOT NULL", $today));

    $partners = $wpdb->get_results("SELECT * FROM " . gn_tbl('partners') . " WHERE status = 'active'");
    $rows = []; $tong_ds = 0; $tong_tra = 0; $tong_thuong = 0; $so_dat_thuong = 0;
    foreach ($partners as $p) {
        $k = gn_partner_period($p->id, $ym);
        if ($k['doanh_so'] <= 0) continue;
        $tong_ds += $k['doanh_so']; $tong_tra += $k['phai_tra']; $tong_thuong += $k['thuong_2pt'];
        if ($k['dat_moc_thuong']) $so_dat_thuong++;
        $rows[] = [
            'ma' => $p->ref_code, 'ten' => $p->contact ?: $p->company, 'loai' => $p->type,
            'doanh_so' => $k['doanh_so'], 'hoa_hong' => $k['hoa_hong'],
            'thuong_2pt' => $k['thuong_2pt'], 'phai_tra' => $k['phai_tra'],
        ];
    }
    usort($rows, fn($a, $b) => $b['doanh_so'] <=> $a['doanh_so']);

    $vou = $wpdb->get_row($wpdb->prepare(
        "SELECT COALESCE(SUM(CASE WHEN kind='pay' THEN amount END),0) AS da_ban,
                COALESCE(SUM(CASE WHEN kind='topup' THEN amount END),0) AS nap_them,
                COALESCE(SUM(CASE WHEN kind='redeem' THEN amount END),0) AS da_dung
         FROM " . gn_tbl('voucher_txn') . " WHERE happened_on BETWEEN %s AND %s", $from, $to));
    $luu_hanh = (float) $wpdb->get_var("SELECT COALESCE(SUM(balance),0) FROM " . gn_tbl('vouchers') . " WHERE status = 'paid'");
    $giu_cho  = (float) $wpdb->get_var("SELECT COALESCE(SUM(price),0) FROM " . gn_tbl('vouchers') . " WHERE status = 'unpaid'");

    wp_send_json_success([
        'ky' => $ym,
        'hom_nay' => [
            'doanh_thu'   => round($today_all),
            'tu_doi_tac'  => round($today_partner),
            'khach_tu_dat'=> round($today_all - $today_partner),
        ],
        'doi_tac' => [
            'so_dang_hoat_dong' => count($rows),
            'doanh_so'   => $tong_ds,
            'phai_tra'   => $tong_tra,
            'thuong_2pt' => $tong_thuong,
            'so_dat_thuong' => $so_dat_thuong,
            'bang'       => $rows,
        ],
        'voucher' => [
            'da_ban'   => round((float) $vou->da_ban + (float) $vou->nap_them),
            'da_dung'  => round((float) $vou->da_dung),
            'luu_hanh' => round($luu_hanh),   // nợ phải trả, KHÔNG phải doanh thu
            'giu_cho_chua_tra' => round($giu_cho),
        ],
    ]);
}

/** Nhân viên quét mã voucher tại quầy. */
add_action('wp_ajax_gn_voucher_redeem', function () {
    gn_require_staff();
    check_ajax_referer('gn_counter', '_wpnonce');   // chặn CSRF: nhân viên mở link lạ là mất voucher khách
    $code = sanitize_text_field($_POST['code'] ?? '');
    $amount = (float) ($_POST['amount'] ?? 0);
    $r = gn_voucher_redeem($code, $amount);
    $r['ok'] ? wp_send_json_success($r) : wp_send_json_error(['message' => $r['msg']]);
});

/** Nhân viên thu tiền voucher giữ chỗ tại quầy. */
add_action('wp_ajax_gn_voucher_pay', function () {
    gn_require_staff();
    check_ajax_referer('gn_counter', '_wpnonce');
    global $wpdb;
    $code = sanitize_text_field($_POST['code'] ?? '');
    $v = $wpdb->get_row($wpdb->prepare("SELECT id FROM " . gn_tbl('vouchers') . " WHERE code = %s", $code));
    if (!$v) wp_send_json_error(['message' => 'Không tìm thấy voucher']);
    gn_voucher_mark_paid($v->id)
        ? wp_send_json_success(['message' => 'Đã ghi nhận thanh toán'])
        : wp_send_json_error(['message' => 'Voucher không ở trạng thái chờ thanh toán']);
});

/**
 * Bảng giá voucher — NGUỒN SỰ THẬT DUY NHẤT, đặt ở máy chủ.
 *
 * Bản trước nhận thẳng face_value và price từ POST nên ai cũng đúc được voucher
 * mệnh giá tuỳ ý với giá tuỳ ý:
 *   curl -d 'face_value=50000000&price=1000&buyer_email=...' .../admin-ajax.php?action=gn_voucher_buy
 * Nhân viên bấm "đã thu tiền" là nạp đủ 50 triệu vào số dư, vì màn quầy chỉ hiện
 * price. Giờ khách chỉ được chọn mệnh giá có trong bảng, giá do máy chủ quyết.
 */
function gn_voucher_tiers() {
    return apply_filters('gn_voucher_tiers', [
        500000  => 450000,
        1000000 => 880000,
        2000000 => 1700000,
        5000000 => 4200000,
    ]);
}

/** Khách mua voucher — phát hành ở trạng thái giữ chỗ, gửi email ngay. */
add_action('wp_ajax_nopriv_gn_voucher_buy', 'gn_ajax_voucher_buy');
add_action('wp_ajax_gn_voucher_buy', 'gn_ajax_voucher_buy');
function gn_ajax_voucher_buy() {
    $tiers = gn_voucher_tiers();
    $face  = (int) ($_POST['face_value'] ?? 0);
    $email = sanitize_email($_POST['buyer_email'] ?? '');
    if (!isset($tiers[$face])) wp_send_json_error(['message' => 'Mệnh giá không hợp lệ']);
    $price = (float) $tiers[$face];                 // KHÔNG lấy giá từ POST
    if (!is_email($email)) wp_send_json_error(['message' => 'Email không hợp lệ — voucher gửi về email này']);

    // chặn đúc hàng loạt: mỗi IP tối đa 5 voucher giữ chỗ trong 10 phút
    $key = 'gn_vbuy_' . md5(($_SERVER['REMOTE_ADDR'] ?? '') . date('YmdHi', floor(time() / 600) * 600));
    $hits = (int) get_transient($key);
    if ($hits >= 5) wp_send_json_error(['message' => 'Bạn vừa tạo nhiều voucher. Chờ ít phút hoặc gọi 0979 232 233.']);
    set_transient($key, $hits + 1, 10 * MINUTE_IN_SECONDS);

    $id = gn_voucher_issue([
        'face_value'  => $face,
        'price'       => $price,
        'buyer_name'  => $_POST['buyer_name'] ?? '',
        'buyer_phone' => $_POST['buyer_phone'] ?? '',
        'buyer_email' => $email,
    ]);
    global $wpdb;
    $v = $wpdb->get_row($wpdb->prepare("SELECT code, hold_until FROM " . gn_tbl('vouchers') . " WHERE id = %d", $id));
    wp_send_json_success([
        'ma'         => $v->code,
        'trang_thai' => 'unpaid',
        'giu_den'    => $v->hold_until,
        'message'    => 'Đã gửi voucher về email. Trả ' . number_format($price) . 'đ khi đến nhà hàng là dùng được.',
    ]);
}

/* ==========================================================================
   GN COMMERCE — THAY CALLBACK CỦA PLUGIN, KHÔNG SỬA FILE PLUGIN
   --------------------------------------------------------------------------
   Plugin sao-booking-engine đăng ký hai endpoint bằng phương thức của một
   đối tượng tạo trong hàm init(), không giữ tham chiếu ra ngoài. Ở đây quét
   $wp_filter để gỡ đúng hai callback đó rồi đăng ký bản của mình.

   Vì sao phải thay, chứ không bọc thêm:
     - partner_login() bản gốc chỉ chạy wp_send_json_error('Use WordPress login')
       nên MỌI hồ sơ đối tác gửi lên đều bị vứt đi, không lưu, không báo ai.
     - create_booking() bản gốc không đọc ref_code, và bảng sao_bookings không
       có cột nào gán đối tác -> không có dữ liệu nguồn để tính hoa hồng.
     - Cả hai đều kết thúc bằng wp_send_json rồi thoát, nên không thể chạy
       thêm code sau chúng. Buộc phải thay hẳn.

   Bản thay giữ nguyên mọi việc phụ của bản gốc: gửi mail cho sale và cskh,
   gửi Telegram nếu có, gửi xác nhận cho khách, tạo lead trong Zero BS CRM.

   HOÀN TÁC: xoá khối giữa BEGIN và END trong functions.php. Plugin trở lại
   nguyên trạng vì file plugin chưa hề bị sửa.
   ========================================================================== */

/** Gỡ callback của plugin theo tên phương thức, trả lại đối tượng gốc nếu cần. */
function gn_unhook_plugin_ajax($action, $method) {
    global $wp_filter;
    $obj = null;
    foreach (["wp_ajax_{$action}", "wp_ajax_nopriv_{$action}"] as $hook) {
        if (empty($wp_filter[$hook])) continue;
        foreach ($wp_filter[$hook]->callbacks as $prio => $cbs) {
            foreach ($cbs as $id => $cb) {
                $fn = $cb['function'];
                if (is_array($fn) && is_object($fn[0]) && isset($fn[1]) && $fn[1] === $method) {
                    $obj = $fn[0];
                    unset($wp_filter[$hook]->callbacks[$prio][$id]);
                }
            }
        }
    }
    return $obj;
}

add_action('init', function () {
    gn_unhook_plugin_ajax('sao_partner_login', 'partner_login');
    foreach (gn_partner_register_actions() as $gn_action => $gn_handler) {
        add_action('wp_ajax_' . $gn_action, $gn_handler);
        add_action('wp_ajax_nopriv_' . $gn_action, $gn_handler);
    }

    gn_unhook_plugin_ajax('sao_create_booking', 'create_booking');
    add_action('wp_ajax_sao_create_booking',        'gn_ajax_create_booking');
    add_action('wp_ajax_nopriv_sao_create_booking', 'gn_ajax_create_booking');
}, 30);

/* --------------------------------------------------------------------------
   Đăng ký đối tác — bản gốc vứt hồ sơ đi
   -------------------------------------------------------------------------- */
function gn_ajax_partner_register() {
    global $wpdb;
    $t = gn_tbl('partners');

    $name  = sanitize_text_field($_POST['full_name'] ?? '');
    $phone = sanitize_text_field($_POST['phone'] ?? '');
    $email = sanitize_email($_POST['email'] ?? '');
    if ($name === '' || $phone === '') wp_send_json_error(['message' => 'Thiếu họ tên hoặc số điện thoại']);
    if ($email !== '' && !is_email($email)) wp_send_json_error(['message' => 'Email không hợp lệ']);

    $ways = gn_partner_signup_field('partner_type');
    $type = sanitize_text_field($_POST['partner_type'] ?? '');
    if ($type === '' || !isset($ways['options'][$type])) {
        wp_send_json_error(['message' => 'Chọn cách bạn muốn hợp tác.']);
    }
    $area   = sanitize_text_field($_POST['area'] ?? '');
    $volume = sanitize_text_field($_POST['estimated_volume'] ?? '');
    $social = esc_url_raw($_POST['social_link'] ?? '');
    $intro  = sanitize_textarea_field($_POST['introduction'] ?? '');

    $existing_id = (int) $wpdb->get_var($wpdb->prepare("SELECT id FROM {$t} WHERE phone = %s", $phone));
    if ($existing_id) {
        wp_send_json_error(gn_partner_duplicate_phone_reply());
    }

    $token = wp_generate_password(32, false, false);
    $role  = gn_normalize_partner_role($type);
    gn_ensure_columns($t, gn_partner_role_column_sql());
    $ref   = '';
    $inserted = false;
    for ($try = 0; $try < 5 && !$inserted; $try++) {
        $max = (int) $wpdb->get_var("SELECT COALESCE(MAX(CAST(SUBSTRING(ref_code, 5) AS UNSIGNED)), 0)
                                     FROM {$t} WHERE ref_code REGEXP '^GN-P[0-9]+$'");
        $ref = gn_format_ref_code($max + 1);
        $row = [
            'company' => $name, 'contact' => $name, 'email' => $email, 'phone' => $phone,
            'type' => $type, 'ref_code' => $ref, 'status' => 'pending', 'portal_token' => $token,
            'area' => $area, 'social_link' => $social,
            'intro' => trim($intro . ($volume ? ' | Khách dự kiến: ' . $volume : '')),
        ];
        if (gn_column_exists($t, 'role')) $row['role'] = $role;
        $inserted = (bool) $wpdb->insert($t, $row);
        if (!$inserted && stripos((string) $wpdb->last_error, 'Duplicate') === false) break;
    }
    if (!$inserted || !$wpdb->insert_id) wp_send_json_error(['message' => 'Không lưu được hồ sơ, gọi 0979 232 233 giúp']);
    do_action('gn_partner_registered', $ref, $name, $phone, $type);   // đẩy sang WCC

    $way_label = $ways['options'][$type];
    @wp_mail(['sale@ganhngon.com', 'partner@ganhngon.com'],
        "Hồ sơ đối tác mới: $name ($ref)",
        "ĐỐI TÁC ĐĂNG KÝ MỚI\n\nMã: $ref\nTên: $name\nCách hợp tác: $way_label\nVai trò: $role\nSĐT/Zalo: $phone\nEmail: $email\n"
      . "Khu vực: $area\nLink: $social\n\nGhi chú: $intro" . ($volume !== '' ? "\nKhách dự kiến: $volume" : '') . "\n\n"
      . "→ Vào wp-admin, đổi status sang active sau khi đã gọi lại số này.\n"
      . "Cổng nội bộ: " . home_url('/cong-doi-tac/?t=' . $token),
        ['Content-Type: text/plain; charset=UTF-8']);

    if ($email !== '') {
        @wp_mail($email, 'Gánh Ngon đã nhận đăng ký hợp tác',
            "Chào $name,\n\n" . gn_partner_signup_success_message() . "\n\n"
          . "Hotline/Zalo: 0979 232 233\n— Gánh Ngon, 113 Trần Hưng Đạo, Dương Đông, Phú Quốc",
            ['Content-Type: text/plain; charset=UTF-8']);
    }
    if (function_exists('gn_send_telegram')) {
        gn_send_telegram("🤝 <b>ĐỐI TÁC MỚI</b> $ref\n👤 $name ($role / $type)\n📞 $phone\n📍 $area");
    }
    wp_send_json_success([
        'message' => gn_partner_signup_success_message(),
    ]);
}

/* --------------------------------------------------------------------------
   Tạo đơn đặt bàn — thêm gán đối tác và doanh số, giữ nguyên phần báo tin
   -------------------------------------------------------------------------- */
function gn_ajax_create_booking() {
    global $wpdb;
    $t = gn_tbl('bookings');

    $g = function ($keys, $default = '') {
        foreach ((array) $keys as $k) if (isset($_POST[$k]) && $_POST[$k] !== '') return $_POST[$k];
        return $default;
    };
    $code   = 'GN' . date('Ymd') . strtoupper(substr(md5(uniqid('', true)), 0, 4));
    $name   = sanitize_text_field($g(['customer_name', 'name']));
    $email  = sanitize_email($g(['customer_email', 'email']));
    $phone  = sanitize_text_field($g(['customer_phone', 'phone']));
    $date   = sanitize_text_field($g(['booking_date', 'date'], current_time('Y-m-d')));
    $time   = sanitize_text_field($g(['booking_time', 'time'], ''));
    $guests = (int) $g(['guests'], 1);
    $type   = sanitize_text_field($g(['space_type', 'type'], 'individual'));
    $need   = sanitize_text_field($g(['need'], ''));
    $note   = sanitize_textarea_field($g(['note', 'notes'], ''));
    $tags   = (isset($_POST['note_tags']) && is_array($_POST['note_tags']))
              ? implode(', ', array_map('sanitize_text_field', $_POST['note_tags'])) : '';

    if ($name === '' || $phone === '') wp_send_json_error(['message' => 'Thiếu tên hoặc số điện thoại']);

    // Chặn ngày ở SERVER, không tin ràng buộc min/max của trình duyệt. Ngày lấy
    // theo giờ Việt Nam. Đơn quá khứ hoặc quá xa lọt xuống database sẽ biến mất
    // khỏi màn quản trị (chỉ truy vấn hôm nay) dù khách vẫn nhận email xác nhận.
    if (!preg_match('/^\d{4}-\d{2}-\d{2}$/', $date)) wp_send_json_error(['message' => 'Ngày không hợp lệ']);
    $hom_nay = (new DateTime('now', new DateTimeZone('Asia/Ho_Chi_Minh')))->format('Y-m-d');
    $toi_da  = (new DateTime('now', new DateTimeZone('Asia/Ho_Chi_Minh')))->modify('+1 year')->format('Y-m-d');
    if ($date < $hom_nay) wp_send_json_error(['message' => 'Không đặt bàn cho ngày đã qua']);
    if ($date > $toi_da)  wp_send_json_error(['message' => 'Chỉ đặt bàn trong vòng 12 tháng tới']);

    $notes_full = trim(($need ? "Nhu cầu: $need. " : '') . ($tags ? "Lưu ý: $tags. " : '') . $note);
    if ($time !== '') $notes_full = trim("Giờ: $time. " . $notes_full);
    $src = isset($_COOKIE['gn_src']) ? sanitize_text_field(wp_unslash($_COOKIE['gn_src'])) : '';
    if ($src !== '') $notes_full = trim($notes_full . ' [Nguồn: ' . $src . ']');
    $posted_src = sanitize_text_field($g(['source'], ''));
    if ($posted_src !== '') $notes_full = trim($notes_full . ' [Nguồn: ' . $posted_src . ']');

    $signature = !empty($_POST['signature_dish']) && (string) $_POST['signature_dish'] !== '0';
    if (!$signature && !empty($_COOKIE['gn_mon']) && $_COOKIE['gn_mon'] === 'lau-ga-sau-rieng') $signature = true;
    $facts = gn_booking_facts([
        'date'      => $date,
        'today'     => $hom_nay,
        'guests'    => $guests,
        'space'     => $type,
        'signature' => $signature,
    ]);
    if ($facts['staff_note'] !== '') $notes_full = trim($notes_full . ' [' . $facts['staff_note'] . ']');
    if ($facts['signature_dish']) $notes_full = trim($notes_full . ' [Món: lẩu gà sầu riêng]');

    // [GN] Gán đơn về đối tác: ưu tiên ô nhập trên form, sau đó cookie gn_ref
    $ref = sanitize_text_field($g(['ref_code'], ''));
    if ($ref === '') $ref = gn_current_ref();
    $partner_id = null;
    if ($ref !== '') {
        $pt = gn_partner_by_code($ref);
        if ($pt) { $partner_id = (int) $pt->id; $ref = $pt->ref_code; } else { $ref = ''; }
    }

    $row = [
        'booking_code' => $code, 'customer_name' => $name, 'customer_email' => $email,
        'customer_phone' => $phone, 'booking_date' => $date, 'guests' => $guests,
        'guest_type' => $type, 'notes' => $notes_full,
        'booking_status' => 'pending', 'payment_status' => 'pending',
        'partner_id' => $partner_id, 'ref_code' => ($ref !== '' ? $ref : null),
        'revenue' => 0,   // doanh số thật do nhân viên chốt khi khách ăn xong
    ];
    $missing_facts = gn_ensure_columns($t, gn_booking_fact_column_sql());
    if ($missing_facts) {
        wp_send_json_error(['message' => 'Chưa lưu được yêu cầu đặt bàn. Gọi 0979 232 233.']);
    }
    $row = array_merge($row, gn_booking_persist_fields($facts));
    $wpdb->insert($t, $row);
    if (!$wpdb->insert_id) wp_send_json_error(['message' => 'Không lưu được đơn, gọi 0979 232 233 giúp']);
    do_action('gn_booking_created', $wpdb->insert_id, $code, $ref);   // đẩy sang WCC

    $partner_line = $ref !== '' ? "Đối tác giới thiệu: $ref\n" : '';
    @wp_mail(['sale@ganhngon.com', 'cskh@ganhngon.com'],
        "🍤 Đặt bàn mới #$code — $name ($guests khách)",
        "ĐẶT BÀN MỚI — Gánh Ngon Phú Quốc\n\nMã booking: $code\nKhách: $name\nSĐT/Zalo: $phone\n"
      . "Email: $email\nNgày: $date" . ($time ? " lúc $time" : '') . "\nSố khách: $guests\n"
      . "Không gian: $type\n$partner_line" . "Ghi chú: $notes_full\n\n"
      . "→ Vào wp-admin → Đặt bàn để xử lý. Liên hệ khách trong 2 phút.\n"
      . "→ Khách ăn xong nhớ chốt doanh số để tính hoa hồng cho đối tác.",
        ['Content-Type: text/plain; charset=UTF-8']);

    if (function_exists('gn_send_telegram')) {
        gn_send_telegram("🍤 <b>ĐẶT BÀN MỚI</b> #$code\n👤 $name\n📞 $phone\n"
            . "📅 $date " . ($time ?: '') . " · $guests khách\n🏠 $type · " . $facts['lead_class'] . "\n"
            . ($facts['signature_dish'] ? "🍲 Lẩu gà sầu riêng\n" : '')
            . ($ref !== '' ? "🤝 Đối tác $ref\n" : '')
            . ($notes_full ? "📝 $notes_full\n" : ''));
    }
    if ($email !== '') {
        @wp_mail($email, "Gánh Ngon đã nhận yêu cầu đặt bàn #$code",
            "Chào $name,\n\nGánh Ngon đã nhận yêu cầu đặt bàn (mã $code, ngày $date"
          . ($time ? " lúc $time" : '') . ", $guests khách). Nhân viên sẽ liên hệ xác nhận trong ít phút.\n\n"
          . "Hotline/Zalo: 0979 232 233\n— Gánh Ngon Phú Quốc",
            ['Content-Type: text/plain; charset=UTF-8']);
    }

    // lead sang Zero BS CRM, y như bản gốc, không bao giờ làm hỏng đơn
    if ($email || $phone) {
        global $zbs;
        if (isset($zbs) && is_object($zbs) && isset($zbs->DAL) && is_object($zbs->DAL)
            && method_exists($zbs->DAL->contacts, 'addUpdateContact')) {
            $parts = explode(' ', trim($name), 2);
            try {
                $zbs->DAL->contacts->addUpdateContact(['data' => [
                    'fname'   => $parts[0] !== '' ? $parts[0] : 'Khách',
                    'lname'   => $parts[1] ?? '',
                    'email'   => $email,
                    'maintel' => $phone,
                    'status'  => 'Lead',
                    'notes'   => "Đặt bàn $code. " . ($ref ? "Đối tác $ref. " : '') . $notes_full,
                ]]);
            } catch (\Throwable $e) { /* không bao giờ chặn đơn */ }
        }
    }

    $message = gn_booking_guest_message($facts);
    wp_send_json_success([
        'booking_id' => $wpdb->insert_id,
        'code'       => $code,
        'doi_tac'    => $ref ?: null,
        'same_day'   => (int) $facts['same_day'],
        'lead_class' => $facts['lead_class'],
        'signature'  => (int) $facts['signature_dish'],
        'message'    => $message,
    ]);
}

/* --------------------------------------------------------------------------
   Nhân viên chốt doanh số sau khi khách ăn xong — đây là lúc hoa hồng thành thật
   -------------------------------------------------------------------------- */
add_action('wp_ajax_gn_booking_settle', function () {
    gn_require_staff();
    check_ajax_referer('gn_counter', '_wpnonce');   // chặn CSRF: bịa doanh số cho đối tác bất kỳ
    global $wpdb;
    $code = sanitize_text_field($_POST['code'] ?? '');
    $rev  = (float) ($_POST['revenue'] ?? 0);
    if ($code === '' || $rev < 0) wp_send_json_error(['message' => 'Thiếu mã đơn hoặc doanh số']);
    $b = $wpdb->get_row($wpdb->prepare("SELECT * FROM " . gn_tbl('bookings') . " WHERE booking_code = %s", $code));
    if (!$b) wp_send_json_error(['message' => 'Không tìm thấy đơn']);
    $wpdb->update(gn_tbl('bookings'), [
        'revenue'        => $rev,
        'served_on'      => current_time('Y-m-d'),
        'booking_status' => 'served',
        'payment_status' => 'paid',
    ], ['id' => $b->id]);
    do_action('gn_booking_settled', $b->id, $rev);   // hoá đơn cảm ơn + báo hoa hồng đối tác
    $day = 0;
    if ($b->partner_id) {
        $day = (float) $wpdb->get_var($wpdb->prepare(
            "SELECT COALESCE(SUM(revenue),0) FROM " . gn_tbl('bookings') . "
             WHERE partner_id = %d AND served_on = %s AND booking_status IN ('served','checked_in','completed')",
            $b->partner_id, current_time('Y-m-d')));
    }
    wp_send_json_success([
        'ma'              => $code,
        'doanh_so_don'    => $rev,
        'doi_tac'         => $b->ref_code,
        'doanh_so_ngay'   => $day,
        'hoa_hong_ngay'   => $b->partner_id ? gn_commission_for_day($day) : 0,
    ]);
});

/* GN COMMERCE — END */

/* ==========================================================================
   GN — MÀN QUẢN TRỊ + CỔNG ĐỐI TÁC + TRANG MUA VOUCHER
   --------------------------------------------------------------------------
   Bổ sung phần giao diện cho backend đã có. Ba mảnh:
     1. wp-admin → "Gánh Ngon": tổng quan doanh thu, quản lý đối tác, công cụ quầy
     2. /cong-doi-tac/?t=TOKEN — đối tác tự xem doanh số, không cần mật khẩu
     3. /voucher/ — khách mua voucher, ưu tiên màn hình điện thoại
   HOÀN TÁC: xoá khối giữa BEGIN và END trong functions.php.
   ========================================================================== */

function gn_money($n) { return number_format((float) $n, 0, ',', '.') . 'đ'; }

/* --------------------------------------------------------------------------
   1. wp-admin
   -------------------------------------------------------------------------- */
add_action('admin_menu', function () {
    add_menu_page('Gánh Ngon', 'Gánh Ngon', GN_CAP, 'gn-home', 'gn_admin_overview', 'dashicons-chart-area', 3);
    add_submenu_page('gn-home', 'Tổng quan doanh thu', 'Tổng quan', GN_CAP, 'gn-home', 'gn_admin_overview');
    add_submenu_page('gn-home', 'Đối tác & hoa hồng', 'Đối tác', GN_CAP, 'gn-partners', 'gn_admin_partners');
    add_submenu_page('gn-home', 'Công cụ tại quầy', 'Tại quầy', GN_CAP, 'gn-counter', 'gn_admin_counter');
});

function gn_admin_css() { ?>
<style>
.gnw{max-width:1200px}
.gnw h1{font-size:23px;margin:0 0 4px}
.gnw .sub{color:#646970;margin:0 0 18px}
.gnw .kpis{display:grid;grid-template-columns:repeat(auto-fit,minmax(190px,1fr));gap:12px;margin-bottom:18px}
.gnw .kpi{background:#fff;border:1px solid #dcdcde;border-radius:8px;padding:14px 16px}
.gnw .kpi.gold{background:#FBF6E7;border-color:#D4AF37}
.gnw .kpi b{display:block;font-size:24px;line-height:1.2;margin:4px 0 2px;color:#1F1710}
.gnw .kpi span{font-size:11px;letter-spacing:.04em;text-transform:uppercase;color:#7A5A12;font-weight:600}
.gnw .kpi small{color:#646970}
.gnw table.wp-list-table td,.gnw table.wp-list-table th{vertical-align:middle}
.gnw .tag{display:inline-block;padding:2px 9px;border-radius:99px;font-size:11px;font-weight:600}
.gnw .ok{background:#E4F2EA;color:#1E7A4C}.gnw .wait{background:#FCEEDC;color:#B45309}
.gnw .off{background:#F0F0F1;color:#646970}.gnw .err{background:#FBE9E7;color:#B42318}
.gnw .card{background:#fff;border:1px solid #dcdcde;border-radius:8px;padding:18px 20px;margin-bottom:16px}
.gnw .card h2{margin-top:0;font-size:15px}
.gnw .grid3{display:grid;grid-template-columns:repeat(auto-fit,minmax(280px,1fr));gap:16px}
.gnw .note{background:#FBF6E7;border-left:4px solid #D4AF37;padding:10px 14px;margin:14px 0;font-size:13px}
.gnw form.inline{display:flex;gap:8px;flex-wrap:wrap;align-items:end}
.gnw label{display:block;font-size:12px;font-weight:600;margin-bottom:3px}
</style><?php }

/** Tổng quan — gộp đơn khách tự đặt và mọi đối tác. */
function gn_admin_overview() {
    if (!current_user_can(GN_CAP)) wp_die('Không có quyền');
    global $wpdb;
    gn_admin_css();
    $ym = isset($_GET['ky']) ? sanitize_text_field($_GET['ky']) : current_time('Y-m');
    $from = $ym . '-01'; $to = date('Y-m-t', strtotime($from)); $today = current_time('Y-m-d');

    $hn_all = (float) $wpdb->get_var($wpdb->prepare("SELECT COALESCE(SUM(revenue),0) FROM " . gn_tbl('bookings') . " WHERE served_on=%s", $today));
    $hn_dt  = (float) $wpdb->get_var($wpdb->prepare("SELECT COALESCE(SUM(revenue),0) FROM " . gn_tbl('bookings') . " WHERE served_on=%s AND partner_id IS NOT NULL", $today));
    $hn_don = (int) $wpdb->get_var($wpdb->prepare("SELECT COUNT(*) FROM " . gn_tbl('bookings') . " WHERE booking_date=%s", $today));
    $cho    = (int) $wpdb->get_var($wpdb->prepare("SELECT COUNT(*) FROM " . gn_tbl('bookings') . " WHERE booking_date=%s AND booking_status='pending'", $today));

    $act_ids = $wpdb->get_col($wpdb->prepare(
        "SELECT DISTINCT partner_id FROM " . gn_tbl('bookings') . "
         WHERE partner_id IS NOT NULL AND served_on BETWEEN %s AND %s
           AND booking_status IN ('served','checked_in','completed')", $from, $to));
    $vou_ids = $wpdb->get_col($wpdb->prepare(
        "SELECT DISTINCT partner_id FROM " . gn_tbl('voucher_txn') . "
         WHERE partner_id IS NOT NULL AND happened_on BETWEEN %s AND %s
           AND kind IN ('pay','topup','refund')", $from, $to));
    $act_ids = array_values(array_unique(array_filter(array_map('intval', array_merge((array) $act_ids, (array) $vou_ids)))));
    $ps = $act_ids
        ? $wpdb->get_results("SELECT * FROM " . gn_tbl('partners') . " WHERE status='active' AND id IN (" . implode(',', $act_ids) . ")")
        : [];
    $rows = []; $ds = 0; $tra = 0; $thuong = 0; $dat = 0;
    foreach ($ps as $p) {
        $k = gn_partner_period($p->id, $ym);
        if ($k['doanh_so'] <= 0) continue;
        $ds += $k['doanh_so']; $tra += $k['phai_tra']; $thuong += $k['thuong_2pt'];
        if ($k['dat_moc_thuong']) $dat++;
        $rows[] = ['p' => $p, 'k' => $k];
    }
    usort($rows, fn($a, $b) => $b['k']['doanh_so'] <=> $a['k']['doanh_so']);

    $v = $wpdb->get_row($wpdb->prepare(
        "SELECT COALESCE(SUM(CASE WHEN kind IN ('pay','topup') THEN amount END),0) ban,
                COALESCE(SUM(CASE WHEN kind='redeem' THEN amount END),0) dung
         FROM " . gn_tbl('voucher_txn') . " WHERE happened_on BETWEEN %s AND %s", $from, $to));
    $luu  = (float) $wpdb->get_var("SELECT COALESCE(SUM(balance),0) FROM " . gn_tbl('vouchers') . " WHERE status='paid'");
    $giu  = (float) $wpdb->get_var("SELECT COALESCE(SUM(price),0) FROM " . gn_tbl('vouchers') . " WHERE status='unpaid'");
    ?>
    <div class="wrap gnw">
      <h1>Tổng quan doanh thu</h1>
      <p class="sub">Kỳ <?php echo esc_html($ym); ?> · gộp đơn khách tự đặt và mọi đối tác ·
        <a href="?page=gn-home&ky=<?php echo esc_attr(date('Y-m', strtotime($from . ' -1 month'))); ?>">← kỳ trước</a></p>

      <div class="kpis">
        <div class="kpi gold"><span>Doanh thu hôm nay</span><b><?php echo gn_money($hn_all); ?></b>
          <small><?php echo $hn_don; ?> đơn · <?php echo $cho; ?> chờ đến</small></div>
        <div class="kpi"><span>Khách tự đặt</span><b><?php echo gn_money($hn_all - $hn_dt); ?></b>
          <small><?php echo $hn_all > 0 ? round(($hn_all - $hn_dt) / $hn_all * 100) : 0; ?>% hôm nay</small></div>
        <div class="kpi"><span>Qua đối tác</span><b><?php echo gn_money($hn_dt); ?></b>
          <small><?php echo $hn_all > 0 ? round($hn_dt / $hn_all * 100) : 0; ?>% hôm nay</small></div>
        <div class="kpi"><span>Doanh số đối tác kỳ này</span><b><?php echo gn_money($ds); ?></b>
          <small><?php echo count($rows); ?> đối tác có phát sinh</small></div>
        <div class="kpi gold"><span>Hoa hồng phải trả</span><b><?php echo gn_money($tra); ?></b>
          <small>gồm thưởng 2%: <?php echo gn_money($thuong); ?> · <?php echo $dat; ?> đối tác đạt mốc</small></div>
        <div class="kpi"><span>Voucher lưu hành</span><b><?php echo gn_money($luu); ?></b>
          <small>nợ phải trả, KHÔNG phải doanh thu</small></div>
      </div>

      <div class="note"><b>Ba con số phải tách bạch.</b>
        Doanh thu là tiền khách trả cho bữa ăn — voucher bán ra chưa dùng không phải doanh thu.
        Hoa hồng phải trả là chi phí bán hàng, ghi ngay trong kỳ phát sinh dù ngày 5 tháng sau mới chuyển.
        Voucher lưu hành <?php echo gn_money($luu); ?> là nợ phải trả; ghi thành doanh thu vào ngày khách dùng.
        Ngoài ra còn <?php echo gn_money($giu); ?> voucher giữ chỗ khách chưa trả tiền — chưa tính vào đâu cả.</div>

      <div class="card">
        <h2>Hoa hồng từng đối tác — kỳ <?php echo esc_html($ym); ?></h2>
        <table class="wp-list-table widefat striped">
          <thead><tr><th>Mã</th><th>Đối tác</th><th>Doanh số</th><th>Hoa hồng luỹ tiến</th>
            <th>Thưởng 2%</th><th>Phải trả</th><th>Tỷ lệ thực</th></tr></thead>
          <tbody>
          <?php if (!$rows): ?><tr><td colspan="7">Chưa có đối tác nào phát sinh doanh số trong kỳ.</td></tr><?php endif; ?>
          <?php foreach ($rows as $r): $k = $r['k']; ?>
            <tr>
              <td><code><?php echo esc_html($r['p']->ref_code); ?></code></td>
              <td><?php echo esc_html($r['p']->contact ?: $r['p']->company); ?></td>
              <td><?php echo gn_money($k['doanh_so']); ?></td>
              <td><?php echo gn_money($k['hoa_hong']); ?></td>
              <td><?php echo $k['thuong_2pt'] ? '<span class="tag ok">' . gn_money($k['thuong_2pt']) . '</span>'
                    : '<span class="tag off">còn ' . gn_money($k['con_thieu']) . '</span>'; ?></td>
              <td><b><?php echo gn_money($k['phai_tra']); ?></b></td>
              <td><?php echo $k['ty_le_thuc']; ?>%</td>
            </tr>
          <?php endforeach; ?>
          </tbody>
          <?php if ($rows): ?><tfoot><tr><th colspan="2">Tổng</th><th><?php echo gn_money($ds); ?></th>
            <th colspan="2"></th><th><?php echo gn_money($tra); ?></th><th><?php echo $ds > 0 ? round($tra / $ds * 100, 2) : 0; ?>%</th></tr></tfoot><?php endif; ?>
        </table>
      </div>

      <div class="card">
        <h2>Đơn hôm nay</h2>
        <table class="wp-list-table widefat striped">
          <thead><tr><th>Mã</th><th>Khách</th><th>SĐT</th><th>Khách</th><th>Nguồn</th><th>Doanh số</th><th>Trạng thái</th></tr></thead>
          <tbody>
          <?php
          $bs = $wpdb->get_results($wpdb->prepare("SELECT * FROM " . gn_tbl('bookings') . " WHERE booking_date=%s ORDER BY id DESC LIMIT 50", $today));
          if (!$bs) echo '<tr><td colspan="7">Chưa có đơn nào hôm nay.</td></tr>';
          foreach ($bs as $b):
            $cls = $b->booking_status === 'served' ? 'ok' : ($b->booking_status === 'pending' ? 'wait' : 'off'); ?>
            <tr><td><code><?php echo esc_html($b->booking_code); ?></code></td>
              <td><?php echo esc_html($b->customer_name); ?></td>
              <td><?php echo esc_html($b->customer_phone); ?></td>
              <td><?php echo (int) $b->guests; ?></td>
              <td><?php echo $b->ref_code ? '<code>' . esc_html($b->ref_code) . '</code>' : 'Trực tiếp'; ?></td>
              <td><?php echo $b->revenue > 0 ? gn_money($b->revenue) : '<span style="color:#B45309">chưa chốt</span>'; ?></td>
              <td><span class="tag <?php echo $cls; ?>"><?php echo esc_html($b->booking_status); ?></span></td></tr>
          <?php endforeach; ?>
          </tbody>
        </table>
        <p class="sub">Đơn chưa chốt doanh số thì hoa hồng đối tác vẫn bằng 0. Chốt ở tab <b>Tại quầy</b>.</p>
      </div>
    </div><?php
}

/** Quản lý đối tác: duyệt, tạm dừng, lấy link cổng và mã QR. */
function gn_admin_partners() {
    if (!current_user_can(GN_CAP)) wp_die('Không có quyền');
    global $wpdb; gn_admin_css();
    $T = gn_tbl('partners');

    if (isset($_POST['gn_action']) && check_admin_referer('gn_partner_act')) {
        $id = (int) $_POST['pid'];
        $act = sanitize_text_field($_POST['gn_action']);
        if ($act === 'active' || $act === 'paused') {
            $wpdb->update($T, ['status' => $act], ['id' => $id]);
            echo '<div class="notice notice-success"><p>Đã đổi trạng thái đối tác #' . $id . ' sang <b>' . esc_html($act) . '</b>.</p></div>';
        } elseif ($act === 'delete') {
            $wpdb->delete($T, ['id' => $id]);
            echo '<div class="notice notice-success"><p>Đã xoá đối tác #' . $id . '.</p></div>';
        } elseif ($act === 'token') {
            $wpdb->update($T, ['portal_token' => wp_generate_password(32, false, false)], ['id' => $id]);
            echo '<div class="notice notice-success"><p>Đã cấp token mới cho đối tác #' . $id . '. Link cũ hết hiệu lực.</p></div>';
        }
    }

    // Thêm đối tác tay — phần lớn đối tác ký trực tiếp tại quán, không điền form web.
    if (isset($_POST['gn_them_doi_tac']) && check_admin_referer('gn_partner_new')) {
        $ten   = sanitize_text_field($_POST['ten'] ?? '');
        $phone = sanitize_text_field($_POST['phone'] ?? '');
        $email = sanitize_email($_POST['email'] ?? '');
        $type  = sanitize_text_field($_POST['type'] ?? 'khac');
        $area  = sanitize_text_field($_POST['area'] ?? '');
        $bank  = sanitize_text_field($_POST['bank_info'] ?? '');

        if ($ten === '' || $phone === '') {
            echo '<div class="notice notice-error"><p>Thiếu tên hoặc số điện thoại.</p></div>';
        } elseif ($wpdb->get_var($wpdb->prepare("SELECT id FROM {$T} WHERE phone = %s", $phone))) {
            echo '<div class="notice notice-error"><p>Số điện thoại này đã có đối tác.</p></div>';
        } else {
            $max = (int) $wpdb->get_var("SELECT COALESCE(MAX(CAST(SUBSTRING(ref_code, 5) AS UNSIGNED)), 0)
                                         FROM {$T} WHERE ref_code REGEXP '^GN-P[0-9]+$'");
            $ref   = gn_format_ref_code($max + 1);
            $token = wp_generate_password(32, false, false);
            gn_ensure_columns($T, gn_partner_role_column_sql());
            $hand = [
                'company' => $ten, 'contact' => $ten, 'email' => $email, 'phone' => $phone,
                'type' => $type, 'ref_code' => $ref, 'status' => 'active',   // thêm tay là duyệt luôn
                'portal_token' => $token, 'area' => $area, 'bank_info' => $bank,
            ];
            if (gn_column_exists($T, 'role')) $hand['role'] = gn_normalize_partner_role($type);
            $wpdb->insert($T, $hand);
            if ($wpdb->insert_id) {
                echo '<div class="notice notice-success"><p>Đã thêm <b>' . esc_html($ref) . ' · ' . esc_html($ten)
                   . '</b> ở trạng thái <b>active</b>. Mã QR dùng được ngay.</p></div>';
                if ($email && !empty($_POST['gui_mail'])) {
                    $portal = home_url('/cong-doi-tac/?t=' . $token);
                    @wp_mail($email, "Mã đối tác Gánh Ngon của bạn: $ref",
                        "Chào $ten,\n\nGánh Ngon đã tạo hồ sơ đối tác cho bạn.\n\nMã của bạn: $ref\n"
                      . "Link QR bàn thường: " . home_url(gn_partner_share_paths($ref)['table']) . "\n"
                      . "Link QR lẩu gà sầu riêng: " . home_url(gn_partner_share_paths($ref)['signature']) . "\n"
                      . "Cổng theo dõi doanh số riêng: $portal\n"
                      . "Giữ link cổng này riêng — ai có link là xem được số liệu của bạn.\n\n"
                      . "Hoa hồng luỹ tiến theo doanh số từng ngày: 5 triệu đầu 10%, phần 5–10 triệu 12%, "
                      . "phần vượt 10 triệu 15%. Tháng đạt 100 triệu được cộng thêm 2% tổng doanh số tháng.\n"
                      . "Chốt sổ ngày 1, đối soát 3 ngày, chuyển khoản ngày 5 hàng tháng.\n\n"
                      . "Hotline/Zalo: 0979 232 233\n— Gánh Ngon Phú Quốc",
                        ['Content-Type: text/plain; charset=UTF-8']);
                    echo '<div class="notice notice-info"><p>Đã gửi mã và link cổng tới ' . esc_html($email) . '.</p></div>';
                }
            } else {
                echo '<div class="notice notice-error"><p>Không lưu được. Kiểm tra lại database.</p></div>';
            }
        }
    }

    // Dọn dữ liệu kiểm thử. Marker: đối tác/khách/lô có dấu ZZ TEST hoặc note TEST.
    // Dọn TRƯỚC khi xoá đối tác để còn tìm được lô và hoa hồng theo partner_id.
    // Chạy lại nhiều lần vẫn an toàn.
    if (isset($_POST['gn_don_test']) && check_admin_referer('gn_don_test')) {
        $B = gn_tbl('bookings'); $V = gn_tbl('vouchers'); $X = gn_tbl('voucher_txn');
        $S = gn_tbl('scans'); $BT = gn_tbl('voucher_batches'); $CM = gn_tbl('commissions');
        $ids = $wpdb->get_col("SELECT id FROM {$T} WHERE contact LIKE 'ZZ TEST%' OR company LIKE 'ZZ TEST%'");
        $idIn = $ids ? implode(',', array_map('intval', $ids)) : '0';
        $n = [];

        // 1. lô voucher: của đối tác test HOẶC ghi chú TEST
        $bids = $wpdb->get_col("SELECT id FROM {$BT} WHERE partner_id IN ($idIn) OR note LIKE 'TEST%'");
        $bIn = $bids ? implode(',', array_map('intval', $bids)) : '0';
        // voucher thuộc lô đó + voucher lẻ mua thử
        $vids = $wpdb->get_col("SELECT id FROM {$V} WHERE buyer_name LIKE 'ZZ TEST%' OR batch_id IN ($bIn) OR partner_id IN ($idIn)");
        if ($vids) {
            $vIn = implode(',', array_map('intval', $vids));
            $n['giao dịch voucher'] = (int) $wpdb->query("DELETE FROM {$X} WHERE voucher_id IN ($vIn)");
            $n['voucher'] = (int) $wpdb->query("DELETE FROM {$V} WHERE id IN ($vIn)");
        }
        if ($bids) $n['lô voucher'] = (int) $wpdb->query("DELETE FROM {$BT} WHERE id IN ($bIn)");
        // sổ hoa hồng phẳng của đối tác test hoặc của các lô test
        $n['hoa hồng lô'] = (int) $wpdb->query("DELETE FROM {$CM} WHERE partner_id IN ($idIn) OR ref_id IN ($bIn)");
        $n['đơn đặt bàn'] = (int) $wpdb->query("DELETE FROM {$B} WHERE customer_name LIKE 'ZZ TEST%' OR partner_id IN ($idIn)");
        $n['lượt quét'] = (int) $wpdb->query("DELETE FROM {$S} WHERE partner_id IN ($idIn)");
        if ($ids) $n['đối tác'] = (int) $wpdb->query("DELETE FROM {$T} WHERE id IN ($idIn)");

        $mo = [];
        foreach ($n as $k => $v) if ($v > 0) $mo[] = "$v $k";
        echo '<div class="notice notice-success"><p>' . ($mo
            ? 'Đã xoá ' . esc_html(implode(' · ', $mo)) . '.'
            : 'Không còn dữ liệu thử nào.') . '</p></div>';
    }

    $q = isset($_GET['q']) ? sanitize_text_field(wp_unslash($_GET['q'])) : '';
    $role_f = isset($_GET['role']) ? sanitize_key(wp_unslash($_GET['role'])) : '';
    $role_query = gn_column_exists($T, 'role') ? $role_f : '';
    $q_plan = ($q === '') ? '' : $wpdb->esc_like($q);
    $probe = gn_partner_list_plan($q_plan, $role_query, 1, 0);
    $count_sql = "SELECT COUNT(*) FROM {$T} WHERE {$probe['where']}";
    $total = (int) ($probe['args']
        ? $wpdb->get_var($wpdb->prepare($count_sql, ...$probe['args']))
        : $wpdb->get_var($count_sql));
    $plan = gn_partner_list_plan($q_plan, $role_query, max(1, (int) ($_GET['paged'] ?? 1)), $total);
    $paged = $plan['page'];
    $pages = $plan['pages'];
    $list_sql = "SELECT * FROM {$T} WHERE {$plan['where']} ORDER BY FIELD(status,'pending','active','paused'), id DESC LIMIT %d OFFSET %d";
    $list_args = array_merge($plan['args'], [$plan['per'], $plan['offset']]);
    $ps = $wpdb->get_results($wpdb->prepare($list_sql, ...$list_args));
    $ym = current_time('Y-m');
    $pending_n = (int) $wpdb->get_var("SELECT COUNT(*) FROM {$T} WHERE status='pending'");
    ?>
    <div class="wrap gnw">
      <h1>Đối tác & hoa hồng</h1>
      <p class="sub"><?php echo (int) $total; ?> hồ sơ<?php echo $pending_n ? ' · ' . (int) $pending_n . ' chờ duyệt' : ''; ?>.
        Danh sách 25 người một trang, đủ cho chương trình tới 300 đại lý. Không có dữ liệu mẫu.
        Hồ sơ từ <code>/doi-tac/</code> ở trạng thái <b>pending</b> — bấm Duyệt thì mã QR mới gán đơn.</p>
      <form method="get" class="inline" style="margin-bottom:12px">
        <input type="hidden" name="page" value="gn-partners">
        <label>Tìm<input type="search" name="q" value="<?php echo esc_attr($q); ?>" placeholder="Tên, mã, điện thoại"></label>
        <label>Vai trò<select name="role">
          <option value="">Tất cả</option>
          <?php foreach (['partner','affiliate','koc','kol'] as $rr): ?>
            <option value="<?php echo esc_attr($rr); ?>" <?php selected($role_f, $rr); ?>><?php echo esc_html(gn_partner_role_label($rr)); ?></option>
          <?php endforeach; ?>
        </select></label>
        <button class="button">Lọc</button>
      </form>

      <div class="card">
        <h2>Thêm đối tác</h2>
        <form method="post"><?php wp_nonce_field('gn_partner_new'); ?>
          <div class="grid3">
            <div><label>Tên đối tác *</label>
              <input name="ten" class="regular-text" placeholder="Nguyễn Văn A / Công ty Vietravel" required style="width:100%"></div>
            <div><label>Số điện thoại / Zalo *</label>
              <input name="phone" class="regular-text" placeholder="09xx xxx xxx" required style="width:100%"></div>
            <div><label>Email <small style="font-weight:400;color:#646970">— để gửi mã và link cổng</small></label>
              <input name="email" type="email" class="regular-text" placeholder="ban@email.com" style="width:100%"></div>
            <div><label>Loại</label>
              <select name="type" style="width:100%">
                <option value="huong-dan-vien">Hướng dẫn viên</option>
                <option value="cong-ty-du-lich">Công ty du lịch / Lữ hành</option>
                <option value="khach-san">Khách sạn / Resort</option>
                <option value="tai-xe">Tài xế / Grab</option>
                <option value="kol">KOL</option>
                <option value="koc">KOC</option>
                <option value="affiliate">Affiliate</option>
                <option value="hiep-hoi">Hiệp hội du lịch / MICE</option>
                <option value="khac">Khác</option>
              </select></div>
            <div><label>Khu vực</label>
              <input name="area" class="regular-text" placeholder="Dương Đông, Phú Quốc" style="width:100%"></div>
            <div><label>Tài khoản nhận hoa hồng</label>
              <input name="bank_info" class="regular-text" placeholder="Vietcombank · 0071000xxx · NGUYEN VAN A" style="width:100%"></div>
          </div>
          <p style="margin-top:12px">
            <label style="font-weight:400"><input type="checkbox" name="gui_mail" value="1" checked>
              Gửi email kèm mã, link QR và link cổng theo dõi cho đối tác</label>
          </p>
          <p><button class="button button-primary" name="gn_them_doi_tac" value="1">Thêm và duyệt luôn</button></p>
        </form>
      </div>
      <table class="wp-list-table widefat striped">
        <thead><tr><th>Mã</th><th>Tên / Loại</th><th>Liên hệ</th><th>Doanh số kỳ này</th>
          <th>Phải trả</th><th>Trạng thái</th><th>Link & mã QR</th><th>Thao tác</th></tr></thead>
        <tbody>
        <?php if (!$ps) echo '<tr><td colspan="8">Chưa có đối tác nào.</td></tr>';
        foreach ($ps as $p):
          $k = gn_partner_period($p->id, $ym);
          $share = gn_partner_share_paths($p->ref_code);
          $qr_target = home_url($share['table']);
          $portal = home_url('/cong-doi-tac/?t=' . $p->portal_token);
          $cls = $p->status === 'active' ? 'ok' : ($p->status === 'pending' ? 'wait' : 'off'); ?>
          <tr>
            <td><code><?php echo esc_html($p->ref_code); ?></code></td>
            <td><b><?php echo esc_html($p->contact ?: $p->company); ?></b><br><small><?php
              $role_show = !empty($p->role) ? $p->role : gn_normalize_partner_role($p->type);
              echo esc_html(gn_partner_role_label($role_show) . ' · ' . $p->type . ' · ' . $p->area);
            ?></small></td>
            <td><?php echo esc_html($p->phone); ?><br><small><?php echo esc_html($p->email); ?></small></td>
            <td><?php echo gn_money($k['doanh_so']); ?></td>
            <td><b><?php echo gn_money($k['phai_tra']); ?></b><?php if ($k['thuong_2pt']) echo '<br><small>gồm thưởng ' . gn_money($k['thuong_2pt']) . '</small>'; ?></td>
            <td><span class="tag <?php echo $cls; ?>"><?php echo esc_html($p->status); ?></span></td>
            <td style="max-width:240px">
              <a href="<?php echo esc_url($qr_target); ?>" target="_blank"><?php echo esc_html($qr_target); ?></a><br>
              <a href="<?php echo esc_url(gn_qr_url($qr_target, 600)); ?>" target="_blank">Tải mã QR PNG 600px</a><br>
              <a href="<?php echo esc_url(home_url($share['signature'])); ?>" target="_blank">Link lẩu gà sầu riêng</a><br>
              <?php if ($p->portal_token): ?><a href="<?php echo esc_url($portal); ?>" target="_blank">Cổng theo dõi của đối tác</a><?php endif; ?>
            </td>
            <td>
              <form method="post" style="display:inline"><?php wp_nonce_field('gn_partner_act'); ?>
                <input type="hidden" name="pid" value="<?php echo (int) $p->id; ?>">
                <?php if ($p->status !== 'active'): ?>
                  <button class="button button-primary" name="gn_action" value="active">Duyệt</button>
                <?php else: ?>
                  <button class="button" name="gn_action" value="paused">Tạm dừng</button>
                <?php endif; ?>
                <button class="button" name="gn_action" value="token">Cấp token mới</button>
                <button class="button" name="gn_action" value="delete"
                  onclick="return confirm('Xoá hẳn đối tác này? Đơn đã gán vẫn giữ mã cũ nhưng sẽ không tính hoa hồng nữa.')">Xoá</button>
              </form>
            </td>
          </tr>
        <?php endforeach; ?>
        </tbody>
      </table>
      <?php if ($pages > 1): ?>
        <p class="sub">Trang <?php echo (int) $paged; ?> / <?php echo (int) $pages; ?>
          <?php if ($paged > 1): ?> · <a href="<?php echo esc_url(add_query_arg(['paged' => $paged - 1])); ?>">Trước</a><?php endif; ?>
          <?php if ($paged < $pages): ?> · <a href="<?php echo esc_url(add_query_arg(['paged' => $paged + 1])); ?>">Sau</a><?php endif; ?>
        </p>
      <?php endif; ?>
      <?php
      $co_test = (int) $wpdb->get_var("SELECT COUNT(*) FROM {$T} WHERE contact LIKE 'ZZ TEST%' OR company LIKE 'ZZ TEST%'")
               + (int) $wpdb->get_var("SELECT COUNT(*) FROM " . gn_tbl('bookings') . " WHERE customer_name LIKE 'ZZ TEST%'")
               + (int) $wpdb->get_var("SELECT COUNT(*) FROM " . gn_tbl('vouchers') . " WHERE buyer_name LIKE 'ZZ TEST%'")
               + (int) $wpdb->get_var("SELECT COUNT(*) FROM " . gn_tbl('voucher_batches') . " WHERE note LIKE 'TEST%'");
      if ($co_test): ?>
        <div class="card" style="border-color:#B45309;background:#FCEEDC">
          <h2 style="color:#B45309">Còn <?php echo (int) $co_test; ?> bản ghi kiểm thử</h2>
          <p class="sub" style="margin-bottom:10px">Dữ liệu do kiểm thử tự động tạo, tên bắt đầu bằng
            <code>ZZ TEST</code>. Chúng đang cộng vào doanh thu và hoa hồng trên màn Tổng quan nên số
            hiển thị chưa phải số thật. Xoá trước khi mở bán.</p>
          <form method="post"><?php wp_nonce_field('gn_don_test'); ?>
            <button class="button" name="gn_don_test" value="1"
              onclick="return confirm('Xoá toàn bộ đối tác, đơn đặt bàn và voucher có tên bắt đầu bằng ZZ TEST?')">
              Dọn dữ liệu thử</button>
          </form>
        </div>
      <?php endif; ?>

      <div class="note"><b>Bộ vật phẩm in.</b> Mã QR trỏ tới <code>/p/{mã}</code>.
        Thêm <code>?m=standee</code>, <code>?m=the</code>, <code>?m=poster</code>, <code>?m=sticker</code>
        vào cuối để biết vật phẩm nào ra khách. In tối thiểu 25×25mm, chừa viền trắng 4mm, không cán bóng.</div>
    </div><?php
}

/** Công cụ tại quầy: chốt doanh số, thu tiền voucher, quét trừ voucher. */
function gn_admin_counter() {
    if (!current_user_can(GN_CAP)) wp_die('Không có quyền');
    global $wpdb; gn_admin_css();
    $msg = '';

    if (isset($_POST['gn_do']) && check_admin_referer('gn_counter')) {
        $do = sanitize_text_field($_POST['gn_do']);
        if ($do === 'settle') {
            $code = sanitize_text_field($_POST['code']); $rev = (float) $_POST['revenue'];
            $b = $wpdb->get_row($wpdb->prepare("SELECT * FROM " . gn_tbl('bookings') . " WHERE booking_code=%s", $code));
            if (!$b) $msg = ['err', 'Không tìm thấy đơn ' . $code];
            else {
                $wpdb->update(gn_tbl('bookings'), ['revenue' => $rev, 'served_on' => current_time('Y-m-d'),
                    'booking_status' => 'served', 'payment_status' => 'paid'], ['id' => $b->id]);
                do_action('gn_booking_settled', $b->id, $rev);   // hoá đơn cảm ơn + báo hoa hồng
                $extra = '';
                if ($b->partner_id) {
                    $day = (float) $wpdb->get_var($wpdb->prepare("SELECT COALESCE(SUM(revenue),0) FROM " . gn_tbl('bookings') . "
                        WHERE partner_id=%d AND served_on=%s AND booking_status IN ('served','checked_in','completed')",
                        $b->partner_id, current_time('Y-m-d')));
                    $extra = ' Đối tác ' . $b->ref_code . ': doanh số hôm nay ' . gn_money($day)
                           . ', hoa hồng ' . gn_money(gn_commission_for_day($day)) . '.';
                }
                $msg = ['ok', 'Đã chốt ' . gn_money($rev) . ' cho đơn ' . $code . '.' . $extra];
            }
        } elseif ($do === 'vpay') {
            $c = sanitize_text_field($_POST['vcode']);
            $v = $wpdb->get_row($wpdb->prepare("SELECT id,price FROM " . gn_tbl('vouchers') . " WHERE code=%s", $c));
            if (!$v) $msg = ['err', 'Không tìm thấy voucher ' . $c];
            elseif (gn_voucher_mark_paid($v->id)) $msg = ['ok', 'Đã thu ' . gn_money($v->price) . ' cho voucher ' . $c . '. Voucher có hiệu lực ngay, email đã gửi lại cho khách.'];
            else $msg = ['err', 'Voucher ' . $c . ' không ở trạng thái chờ thanh toán.'];
        } elseif ($do === 'vredeem') {
            $r = gn_voucher_redeem(sanitize_text_field($_POST['vcode2']), (float) $_POST['vamount']);
            $msg = $r['ok'] ? ['ok', 'Đã trừ ' . gn_money($r['da_dung']) . ', số dư còn ' . gn_money($r['con_lai']) . '.'] : ['err', $r['msg']];
        }
    }
    ?>
    <div class="wrap gnw">
      <h1>Công cụ tại quầy</h1>
      <p class="sub">Ba việc nhân viên làm hằng ngày. Chốt doanh số là mắt xích quan trọng nhất — không chốt thì hoa hồng đối tác mãi bằng 0.</p>
      <?php if ($msg): ?><div class="notice notice-<?php echo $msg[0] === 'ok' ? 'success' : 'error'; ?>"><p><?php echo esc_html($msg[1]); ?></p></div><?php endif; ?>

      <div class="grid3">
        <div class="card">
          <h2>1. Chốt doanh số sau khi khách ăn xong</h2>
          <form method="post"><?php wp_nonce_field('gn_counter'); ?>
            <label>Mã đơn</label><input name="code" class="regular-text" placeholder="GN20260809ABCD" required>
            <label style="margin-top:8px">Tiền khách thực trả (sau giảm giá)</label>
            <input name="revenue" type="number" min="0" step="1000" class="regular-text" placeholder="1640000" required>
            <p><button class="button button-primary" name="gn_do" value="settle">Chốt doanh số</button></p>
          </form>
          <p class="sub">Nhập số tiền <b>thực trả</b>, không phải giá niêm yết. Hoa hồng tính trên số này.</p>
        </div>

        <div class="card">
          <h2>2. Thu tiền voucher giữ chỗ</h2>
          <form method="post"><?php wp_nonce_field('gn_counter'); ?>
            <label>Mã voucher</label><input name="vcode" class="regular-text" placeholder="GN-V-XXXX-XXXX" required>
            <p><button class="button button-primary" name="gn_do" value="vpay">Xác nhận đã thu tiền</button></p>
          </form>
          <p class="sub">Voucher <b>CHƯA THANH TOÁN</b> chưa có giá trị. Thu tiền xong mới nạp số dư và mới tính doanh số cho người giới thiệu.</p>
        </div>

        <div class="card">
          <h2>3. Quét voucher trừ hoá đơn</h2>
          <form method="post"><?php wp_nonce_field('gn_counter'); ?>
            <label>Mã voucher</label><input name="vcode2" class="regular-text" placeholder="GN-V-XXXX-XXXX" required>
            <label style="margin-top:8px">Số tiền cần trừ</label>
            <input name="vamount" type="number" min="0" step="1000" class="regular-text" required>
            <p><button class="button button-primary" name="gn_do" value="vredeem">Trừ vào hoá đơn</button></p>
          </form>
          <p class="sub">Trừ tối đa bằng số dư. Hết số dư thì voucher chuyển sang <b>đã dùng</b>.</p>
        </div>
      </div>

      <div class="card">
        <h2>Đơn chờ chốt doanh số</h2>
        <table class="wp-list-table widefat striped">
          <thead><tr><th>Mã đơn</th><th>Ngày</th><th>Khách</th><th>SĐT</th><th>Số khách</th><th>Nguồn</th></tr></thead>
          <tbody><?php
          $ws = $wpdb->get_results("SELECT * FROM " . gn_tbl('bookings') . "
              WHERE (revenue IS NULL OR revenue=0) AND booking_status NOT IN ('cancelled','no_show')
              ORDER BY booking_date DESC, id DESC LIMIT 40");
          if (!$ws) echo '<tr><td colspan="6">Không còn đơn nào chờ chốt.</td></tr>';
          foreach ($ws as $b): ?>
            <tr><td><code><?php echo esc_html($b->booking_code); ?></code></td>
              <td><?php echo esc_html($b->booking_date); ?></td>
              <td><?php echo esc_html($b->customer_name); ?></td>
              <td><?php echo esc_html($b->customer_phone); ?></td>
              <td><?php echo (int) $b->guests; ?></td>
              <td><?php
                echo $b->ref_code ? '<code>' . esc_html($b->ref_code) . '</code>' : 'Trực tiếp';
                if (!empty($b->signature_dish)) echo '<br><small>lẩu gà sầu riêng</small>';
                if (!empty($b->lead_class)) echo '<br><small>' . esc_html($b->lead_class) . '</small>';
              ?></td></tr>
          <?php endforeach; ?></tbody>
        </table>
      </div>
    </div><?php
}

/* --------------------------------------------------------------------------
   2. /cong-doi-tac/?t=TOKEN — đối tác tự xem doanh số
   -------------------------------------------------------------------------- */
function gn_portal_html() {
    global $wpdb;
    $token = isset($_GET['t']) ? sanitize_text_field($_GET['t']) : '';
    if (strlen($token) < 20) {
        return '<div class="gnp"><section class="gnp-sec"><div class="gnp-head">'
             . '<h3>Cần link riêng của bạn</h3><p class="gnp-sub">Cổng này mở bằng link riêng gửi trong email lúc duyệt hồ sơ, không dùng mật khẩu. '
             . 'Mất link thì nhắn Zalo 0979 232 233 để được gửi lại.</p></div></section></div>';
    }
    $p = $wpdb->get_row($wpdb->prepare("SELECT * FROM " . gn_tbl('partners') . " WHERE portal_token=%s", $token));
    if (!$p) return '<div class="gnp"><section class="gnp-sec"><div class="gnp-head"><h3>Link không đúng</h3>'
                  . '<p class="gnp-sub">Có thể link đã được cấp lại. Nhắn Zalo 0979 232 233 để lấy link mới.</p></div></section></div>';

    $ym = isset($_GET['ky']) ? sanitize_text_field($_GET['ky']) : current_time('Y-m');
    $today = current_time('Y-m-d');
    $k = gn_partner_period($p->id, $ym);
    $scans = (int) $wpdb->get_var($wpdb->prepare("SELECT COUNT(*) FROM " . gn_tbl('scans') . " WHERE partner_id=%d AND scanned_on=%s", $p->id, $today));
    $rev_today = (float) $wpdb->get_var($wpdb->prepare("SELECT COALESCE(SUM(revenue),0) FROM " . gn_tbl('bookings') . "
        WHERE partner_id=%d AND served_on=%s AND booking_status IN ('served','checked_in','completed')", $p->id, $today));
    $bd = gn_commission_breakdown($rev_today);
    $rows = $wpdb->get_results($wpdb->prepare("SELECT * FROM " . gn_tbl('bookings') . "
        WHERE partner_id=%d ORDER BY booking_date DESC, id DESC LIMIT 25", $p->id));

    ob_start(); ?>
    <div class="gnp">
      <section class="gnp-hero">
        <span class="gnp-rule"></span>
        <p class="gnp-eyebrow">Cổng đối tác · <?php echo esc_html($p->ref_code); ?> · <?php
          $role = !empty($p->role) ? $p->role : gn_normalize_partner_role($p->type ?? '');
          echo esc_html(gn_partner_role_label($role));
        ?></p>
        <h2><?php echo esc_html($p->contact ?: $p->company); ?></h2>
        <?php if ($p->status !== 'active'): ?>
          <p class="gnp-lead">Hồ sơ đang <b><?php echo esc_html($p->status); ?></b>. Mã QR chỉ gán đơn sau khi nhà hàng duyệt.</p>
        <?php endif; ?>
        <p class="gnp-lead">Hoa hồng luỹ tiến theo doanh số từng ngày: 5 triệu đầu 10%, phần 5–10 triệu 12%,
          phần vượt 10 triệu 15%. Tháng đạt 100 triệu được cộng thêm 2% tổng doanh số tháng.</p>
      </section>

      <section class="gnp-sec">
        <div class="gnp-portal">
          <div class="gnp-kpis">
            <div><span>Lượt quét QR hôm nay</span><b><?php echo $scans; ?></b><small><?php echo esc_html($today); ?></small></div>
            <div><span>Doanh số hôm nay</span><b><?php echo gn_money($rev_today); ?></b><small>chỉ tính khách đã đến</small></div>
            <div class="is-gold"><span>Hoa hồng hôm nay</span><b><?php echo gn_money(gn_commission_for_day($rev_today)); ?></b>
              <small><?php echo $rev_today > 0 ? round(gn_commission_for_day($rev_today) / $rev_today * 100, 1) . '% doanh số' : 'chưa có đơn'; ?></small></div>
            <div><span>Kỳ <?php echo esc_html($ym); ?></span><b><?php echo gn_money($k['phai_tra']); ?></b>
              <small><?php echo $k['dat_moc_thuong'] ? 'đã gồm thưởng 2%: ' . gn_money($k['thuong_2pt'])
                    : 'còn ' . gn_money($k['con_thieu']) . ' để đạt thưởng 2%'; ?></small></div>
          </div>

          <?php if ($rev_today > 0): ?>
          <div class="gnp-ladder" style="margin-bottom:16px">
            <?php foreach ($bd as $b): if ($b['doanh_so'] <= 0) continue; ?>
              <div style="flex:<?php echo (int) $b['doanh_so']; ?> 1 0">
                <span><?php echo gn_money($b['doanh_so']); ?> × <?php echo $b['ty_le']; ?>%</span>
                <b><?php echo gn_money($b['hoa_hong']); ?></b></div>
            <?php endforeach; ?>
          </div>
          <?php endif; ?>

          <div class="gnp-tablewrap">
            <table>
              <thead><tr><th>Ngày</th><th>Mã đơn</th><th>Khách</th><th>Số khách</th><th>Doanh số</th><th>Trạng thái</th></tr></thead>
              <tbody>
              <?php if (!$rows) echo '<tr><td colspan="6">Chưa có đơn nào từ mã của bạn.</td></tr>';
              foreach ($rows as $b):
                $served = in_array($b->booking_status, ['served', 'checked_in', 'completed'], true); ?>
                <tr><td><?php echo esc_html($b->booking_date); ?></td>
                  <td><?php echo esc_html($b->booking_code); ?></td>
                  <td><?php echo esc_html($b->customer_name); ?></td>
                  <td><?php echo (int) $b->guests; ?></td>
                  <td><?php echo $b->revenue > 0 ? '<b>' . gn_money($b->revenue) . '</b>' : '—'; ?></td>
                  <td><span class="gnp-tag <?php echo $served ? 'is-ok' : 'is-warn'; ?>">
                    <?php echo $served ? 'Đã đến' : 'Chờ đến'; ?></span></td></tr>
              <?php endforeach; ?>
              </tbody>
            </table>
          </div>
          <p class="gnp-note gnp-note--left">Hoa hồng chỉ chốt khi khách <b>đã đến và đã thanh toán</b>.
            Đơn còn "Chờ đến" chưa tính. Thấy số sai thì báo trong 3 ngày đầu tháng, nhắn Zalo 0979 232 233.</p>
        </div>
      </section>

      <section class="gnp-sec gnp-sec--sand">
        <div class="gnp-head"><span class="gnp-rule"></span><p class="gnp-eyebrow">Mã QR của bạn</p>
          <h3>In ra, đưa cho khách quét</h3></div>
        <?php $share = gn_partner_share_paths($p->ref_code); ?>
        <div class="gnp-split" style="margin-bottom:28px">
          <div>
            <h3>Bàn thường hôm nay</h3>
            <p class="gnp-sub"><code><?php echo esc_html(home_url($share['table'])); ?></code></p>
            <img src="<?php echo esc_url(gn_qr_url(home_url($share['table']), 220)); ?>" alt="QR bàn thường <?php echo esc_attr($p->ref_code); ?>" width="180" height="180" style="background:#fff;border-radius:12px;padding:8px">
          </div>
          <div>
            <h3>Lẩu gà sầu riêng</h3>
            <p class="gnp-sub"><code><?php echo esc_html(home_url($share['signature'])); ?></code></p>
            <img src="<?php echo esc_url(gn_qr_url(home_url($share['signature']), 220)); ?>" alt="QR lẩu gà sầu riêng <?php echo esc_attr($p->ref_code); ?>" width="180" height="180" style="background:#fff;border-radius:12px;padding:8px">
          </div>
        </div>
        <p class="gnp-sub">Thêm <code>?m=standee</code>, <code>?m=the</code>, <code>?m=poster</code> hoặc
          <code>?m=sticker</code> vào cuối link để biết vật phẩm nào ra khách. Giữ link cổng này riêng.</p>
      </section>
    </div><?php
    return ob_get_clean();
}

/* --------------------------------------------------------------------------
   3. /voucher/ — khách mua
   -------------------------------------------------------------------------- */
function gn_voucher_page_html() {
    global $wpdb;
    $code = isset($_GET['c']) ? sanitize_text_field($_GET['c']) : '';
    if ($code !== '') {
        $v = $wpdb->get_row($wpdb->prepare("SELECT * FROM " . gn_tbl('vouchers') . " WHERE code=%s", $code));
        if ($v) return gn_voucher_view_html($v);
    }
    $ref = gn_current_ref();
    $p = $ref ? gn_partner_by_code($ref) : null;
    ob_start(); ?>
    <div class="gnp">
      <section class="gnp-hero">
        <span class="gnp-rule"></span>
        <p class="gnp-eyebrow">Voucher Gánh Ngon</p>
        <h2>Mua trước, trả khi đến</h2>
        <p class="gnp-lead">Chọn mệnh giá, điền email. Voucher gửi ngay về email ở trạng thái giữ chỗ —
          đến nhà hàng trả tiền tại quầy là dùng được. Không mất phí nếu đổi ý.</p>
      </section>

      <?php if ($p): ?>
      <section class="gnp-sec" style="padding-bottom:0">
        <div class="gnp-rules" style="background:#F6EBD2">Bạn vào từ mã đối tác
          <b><?php echo esc_html($p->ref_code); ?> · <?php echo esc_html($p->contact ?: $p->company); ?></b>.
          Đơn này sẽ được ghi nhận cho người giới thiệu.</div>
      </section>
      <?php endif; ?>

      <section class="gnp-sec">
        <div class="gnp-head"><span class="gnp-rule"></span><p class="gnp-eyebrow">Chọn mệnh giá</p>
          <h3>Mua càng lớn càng lợi</h3></div>
        <form class="gnp-form" id="gnVoucherForm" style="max-width:620px;margin-inline:auto">
          <?php $gn_tiers = []; foreach (gn_voucher_tiers() as $gn_f => $gn_g) $gn_tiers[] = [$gn_f, $gn_g]; foreach ($gn_tiers as $i => $o): ?>
            <label style="flex-direction:row;align-items:center;gap:12px;border:1px solid var(--gn-border);
                          border-radius:12px;padding:14px 16px;cursor:pointer">
              <input type="radio" name="face" value="<?php echo $o[0]; ?>" data-price="<?php echo $o[1]; ?>"
                     <?php echo $i === 1 ? 'checked' : ''; ?> style="min-height:auto;width:auto">
              <span style="flex:1"><b style="font-size:17px"><?php echo gn_money($o[0]); ?></b><br>
                <small style="color:var(--gn-text-soft)">trả <?php echo gn_money($o[1]); ?> ·
                  lợi <?php echo gn_money($o[0] - $o[1]); ?></small></span>
            </label>
          <?php endforeach; ?>

          <label>Họ và tên *<input name="buyer_name" required placeholder="Nguyễn Thu Hà"></label>
          <label>Email nhận voucher *<input name="buyer_email" type="email" required placeholder="ban@email.com"></label>
          <label>Số điện thoại / Zalo<input name="buyer_phone" type="tel" inputmode="tel" placeholder="09xx xxx xxx"></label>
          <button type="submit" class="gnp-btn gnp-btn--gold gnp-btn--block">Nhận voucher giữ chỗ</button>
          <p class="gnp-fine">Chưa mất tiền lúc này. Voucher gửi về email ở trạng thái <b>CHƯA THANH TOÁN</b>,
            giữ chỗ 7 ngày. Đến nhà hàng trả tiền tại quầy là dùng được ngay.</p>
          <div id="gnVoucherOut" style="display:none"></div>
        </form>
      </section>
    </div>
    <script>
    (function(){
      var f=document.getElementById('gnVoucherForm');
      if(!f) return;
      f.addEventListener('submit',function(e){
        e.preventDefault();
        var sel=f.querySelector('input[name=face]:checked');
        var btn=f.querySelector('button[type=submit]');
        btn.disabled=true; btn.textContent='Đang gửi…';
        var d=new URLSearchParams({
          face_value:sel.value, price:sel.dataset.price,
          buyer_name:f.buyer_name.value, buyer_email:f.buyer_email.value, buyer_phone:f.buyer_phone.value
        });
        fetch('<?php echo esc_url(admin_url('admin-ajax.php')); ?>?action=gn_voucher_buy',
          {method:'POST',credentials:'include',
           headers:{'Content-Type':'application/x-www-form-urlencoded'},body:d.toString()})
        .then(function(r){return r.json()})
        .then(function(j){
          var o=document.getElementById('gnVoucherOut'); o.style.display='block';
          if(j.success){
            o.className='gnp-rules';
            o.innerHTML='<b>Xong.</b> Mã voucher <b>'+j.data.ma+'</b>. '+j.data.message+
              '<br>Giữ chỗ đến hết ngày '+j.data.giu_den+'.';
            btn.style.display='none';
          } else {
            o.className='gnp-rules'; o.style.background='#FBE9E7'; o.style.borderColor='#B42318';
            o.textContent=(j.data&&j.data.message)||'Không gửi được, gọi 0979 232 233 giúp.';
            btn.disabled=false; btn.textContent='Thử lại';
          }
        })
        .catch(function(){ btn.disabled=false; btn.textContent='Thử lại'; });
      });
    })();
    </script><?php
    return ob_get_clean();
}

/* gn_voucher_view_html() nay nằm ở cuối file — bản đầy đủ, hiện người mua,
   đối tác giới thiệu, ngày mua, giá trị, tiền nạp thêm, số dư, hạn dùng,
   lịch sử giao dịch và VietQR. Không khai báo lại ở đây. */

/** Gắn hai trang vào nội dung theo đường dẫn. */
add_filter('the_content', function ($content) {
    if (is_admin() || !in_the_loop() || !is_main_query() || !is_page()) return $content;
    $slug = get_post_field('post_name', get_queried_object_id());
    if ($slug === 'cong-doi-tac') return gn_portal_html();
    if ($slug === 'voucher')      return gn_voucher_page_html();
    if (function_exists('gn_is_advisor_page') && gn_is_advisor_page()) return gn_advisor_page_html();
    return $content;
}, 6);

function gn_is_advisor_page() {
    if (!is_page()) return false;
    $slug = (string) get_post_field('post_name', get_queried_object_id());
    return $slug === 'ai-tu-van' || strpos($slug, 'ai-tu-van') === 0;
}

function gn_advisor_page_html() {
    $lang = gn_cur_lang();
    $hello = gn_advisor_reply('xin chao', $lang);
    $chips = [
        'vi' => ['Giờ mở cửa', 'Chỉ đường', 'Đặt bàn hôm nay', 'Lẩu gà sầu riêng', 'Giá bao nhiêu?', 'Phòng VIP'],
        'en' => ['Opening hours', 'Directions', 'Book a table today', 'Durian chicken hotpot', 'How much does it cost?', 'VIP room'],
        'zh' => ['营业时间', '怎么走', '今天订桌', '榴莲鸡火锅', '多少钱', 'VIP包厢'],
        'ko' => ['영업시간', '오시는 길', '오늘 예약', '두리안 닭 샤브샤브', '가격', 'VIP룸'],
        'ru' => ['Часы работы', 'Как добраться', 'Стол на сегодня', 'Хотпот с дурианом', 'Сколько стоит', 'VIP'],
        'ar' => ['ساعات العمل', 'كيف أصل', 'طاولة اليوم', 'حلة الدجاج بالدوريان', 'كم السعر', 'VIP'],
    ];
    $ask = $chips[$lang] ?? $chips['en'];
    ob_start(); ?>
    <div class="gn-advisor">
      <p class="section-eyebrow" style="text-align:left"><?php echo esc_html(gn_t('sig_kicker')); ?></p>
      <h1><?php echo esc_html(gn_t('adv_title')); ?></h1>
      <p><?php echo esc_html($hello); ?></p>
      <div class="gn-advisor-chips" id="gnAdvisorChips">
        <?php foreach ($ask as $q): ?>
          <button type="button" data-q="<?php echo esc_attr($q); ?>"><?php echo esc_html($q); ?></button>
        <?php endforeach; ?>
      </div>
      <div class="gn-advisor-log" id="gnAdvisorLog" aria-live="polite"></div>
      <form id="gnAdvisorForm" class="gn-form-row" style="margin-top:12px">
        <input type="text" id="gnAdvisorText" required placeholder="<?php echo esc_attr(gn_t('adv_link')); ?>" aria-label="<?php echo esc_attr(gn_t('adv_link')); ?>">
        <button class="gn-cta-btn" type="submit"><?php echo esc_html(gn_t('qb_submit')); ?></button>
      </form>
      <p><a class="gn-cta-btn" href="<?php echo esc_url(home_url('/#gn-book-today')); ?>"><?php echo esc_html(gn_t('hero_cta1')); ?></a>
         <a class="gn-cta-btn ghost" href="<?php echo esc_url(gn_maps_url()); ?>"><?php echo esc_html(gn_t('loc_maps')); ?></a></p>
    </div>
    <script>
    (function(){
      var log=document.getElementById('gnAdvisorLog');
      var form=document.getElementById('gnAdvisorForm');
      var input=document.getElementById('gnAdvisorText');
      function say(text){var p=document.createElement('p');p.textContent=text;log.appendChild(p);log.scrollTop=log.scrollHeight;}
      function ask(msg){
        say(msg);
        var fd=new FormData();
        fd.append('action','gn_ai_chat');
        fd.append('nonce','<?php echo esc_js(wp_create_nonce('gn_ai')); ?>');
        fd.append('lang','<?php echo esc_js($lang); ?>');
        fd.append('message',msg);
        fetch('<?php echo esc_url(admin_url('admin-ajax.php')); ?>',{method:'POST',body:fd,credentials:'same-origin'})
          .then(function(r){return r.json();})
          .then(function(j){say((j&&j.data&&j.data.reply)?j.data.reply:'0979 232 233');})
          .catch(function(){say('0979 232 233');});
      }
      form.addEventListener('submit',function(e){e.preventDefault();var v=input.value.trim();if(!v)return;input.value='';ask(v);});
      document.getElementById('gnAdvisorChips').addEventListener('click',function(e){
        var b=e.target.closest('button'); if(!b) return; ask(b.getAttribute('data-q'));
      });
    })();
    </script>
    <?php
    return ob_get_clean();
}

add_filter('body_class', function ($classes) {
    if (function_exists('gn_is_advisor_page') && gn_is_advisor_page()) $classes[] = 'gn-advisor-page';
    return $classes;
});

add_filter('pre_get_document_title', function ($title) {
    if (function_exists('gn_is_advisor_page') && gn_is_advisor_page()) {
        return gn_t('adv_title') . ' — Gánh Ngon';
    }
    return $title;
}, 20);
add_filter('wpseo_title', function ($title) {
    if (function_exists('gn_is_advisor_page') && gn_is_advisor_page()) {
        return gn_t('adv_title') . ' — Gánh Ngon';
    }
    return $title;
}, 20);

/* GN — MÀN QUẢN TRỊ END */

/* ==========================================================================
   GN — VIETQR + TRANG TRA CỨU VOUCHER ĐẦY ĐỦ
   --------------------------------------------------------------------------
   Vì sao QR không nhét dữ liệu vào trong: số dư đổi mỗi lần nạp thêm và mỗi lần
   quét trừ. Nhét vào mã là đóng băng số liệu tại lúc in, hôm sau đã sai. QR trỏ
   tới trang tra cứu, quét ra thấy số HIỆN TẠI, và mã in một lần dùng mãi.
   ========================================================================== */

define('GN_BANK_BIN',   '970425');            // ABBANK — Ngân hàng TMCP An Bình
define('GN_BANK_NAME',  'ABBANK');
define('GN_BANK_ACC',   '2020333333');
define('GN_BANK_OWNER', 'NHA HANG GANH NGON');

/** Ảnh VietQR quét bằng app ngân hàng là ra sẵn số tiền và nội dung. */
function gn_vietqr_url($amount, $content, $template = 'compact2') {
    return 'https://img.vietqr.io/image/' . GN_BANK_BIN . '-' . GN_BANK_ACC . '-' . $template . '.png'
         . '?amount=' . (int) $amount
         . '&addInfo=' . rawurlencode($content)
         . '&accountName=' . rawurlencode(GN_BANK_OWNER);
}

/** Che bớt số điện thoại cho người lạ cầm mã: 0912345678 -> 0912***678 */
function gn_mask_phone($p) {
    $p = preg_replace('/\s+/', '', (string) $p);
    if (strlen($p) < 7) return $p;
    return substr($p, 0, 4) . str_repeat('*', max(0, strlen($p) - 7)) . substr($p, -3);
}
function gn_mask_email($e) {
    if (!$e || strpos($e, '@') === false) return $e;
    [$a, $b] = explode('@', $e, 2);
    return substr($a, 0, 2) . str_repeat('*', max(1, strlen($a) - 2)) . '@' . $b;
}

function gn_voucher_status_label($s) {
    return [
        'unpaid'   => ['CHƯA THANH TOÁN', 'is-warn'],
        'paid'     => ['CÒN HIỆU LỰC',    'is-ok'],
        'used'     => ['ĐÃ DÙNG HẾT',     'is-off'],
        'expired'  => ['HẾT HẠN',         'is-err'],
        'refunded' => ['ĐÃ HOÀN TIỀN',    'is-err'],
    ][$s] ?? [strtoupper($s), 'is-off'];
}

/**
 * Trang tra cứu voucher — quét mã QR là ra đây.
 * Khách thấy đủ thông tin của chính mình, số điện thoại và email che bớt.
 * Nhân viên đăng nhập thấy thêm thông tin đầy đủ và nút thao tác.
 */
function gn_voucher_view_html($v) {
    global $wpdb;
    $staff  = current_user_can(GN_CAP);
    $unpaid = ($v->status === 'unpaid');
    [$lbl, $cls] = gn_voucher_status_label($v->status);

    $partner = $v->partner_id
        ? $wpdb->get_row($wpdb->prepare("SELECT ref_code, contact, company, type FROM " . gn_tbl('partners') . " WHERE id=%d", $v->partner_id))
        : null;
    $txn = $wpdb->get_results($wpdb->prepare(
        "SELECT * FROM " . gn_tbl('voucher_txn') . " WHERE voucher_id=%d ORDER BY id ASC", $v->id));

    $topup_total = 0; $used_total = 0;
    foreach ($txn as $t) {
        if ($t->kind === 'topup')  $topup_total += (float) $t->amount;
        if ($t->kind === 'redeem') $used_total  += (float) $t->amount;
    }
    $kind_label = [
        'issue'  => 'Phát hành, giữ chỗ',
        'pay'    => 'Khách thanh toán',
        'topup'  => 'Nạp thêm',
        'redeem' => 'Trừ vào hoá đơn',
        'refund' => 'Hoàn tiền',
    ];
    $het_han = $v->expires_on && $v->expires_on < current_time('Y-m-d');

    ob_start(); ?>
    <div class="gnp">
      <section class="gnp-sec">
        <div class="gnp-head">
          <span class="gnp-rule"></span>
          <p class="gnp-eyebrow">Voucher Gánh Ngon</p>
          <h3><?php echo esc_html($v->code); ?></h3>
          <p class="gnp-sub"><span class="gnp-tag <?php echo esc_attr($cls); ?>"><?php echo esc_html($lbl); ?></span></p>
        </div>

        <!-- thẻ voucher -->
        <div class="voucher <?php echo $unpaid ? 'voucher--unpaid' : ''; ?>" style="max-width:560px;margin-inline:auto">
          <?php if ($unpaid): ?><div class="band">CHƯA THANH TOÁN · TRẢ TẠI NHÀ HÀNG</div><?php endif; ?>
          <div class="<?php echo $unpaid ? 'inner' : ''; ?>" style="display:flex;align-items:center">
            <div class="voucher__l">
              <span class="amt"><?php echo gn_money($unpaid ? $v->face_value : $v->balance); ?></span>
              <?php if ($unpaid): ?>
                <b style="color:#B45309">Cần trả <?php echo gn_money($v->price); ?></b>
              <?php else: ?>
                <small>Mệnh giá <?php echo gn_money($v->face_value); ?> · đã dùng <?php echo gn_money($used_total); ?></small>
              <?php endif; ?>
              <span class="voucher__code"><?php echo esc_html($v->code); ?></span>
              <small>Hạn dùng <?php echo esc_html(date('d/m/Y', strtotime($v->expires_on))); ?></small>
            </div>
            <div class="voucher__r">
              <div class="qr"><img src="<?php echo esc_url(gn_qr_url(home_url('/voucher/?c=' . $v->code), 220)); ?>"
                   alt="Mã QR voucher <?php echo esc_attr($v->code); ?>" width="96" height="96"
                   style="display:block;width:100%;height:100%"></div>
            </div>
          </div>
        </div>

        <!-- toàn bộ thông tin theo dõi -->
        <div class="gnp-portal" style="max-width:560px;margin:20px auto 0">
          <h4 style="margin:0 0 12px;font-size:16px">Thông tin voucher</h4>
          <div class="gnp-tablewrap">
            <table style="min-width:0">
              <tbody>
                <tr><th style="width:44%">Mã voucher</th><td><b><?php echo esc_html($v->code); ?></b></td></tr>
                <tr><th>Trạng thái</th><td><span class="gnp-tag <?php echo esc_attr($cls); ?>"><?php echo esc_html($lbl); ?></span></td></tr>
                <tr><th>Người mua</th><td><?php echo esc_html($v->buyer_name ?: '—'); ?></td></tr>
                <tr><th>Điện thoại</th><td><?php echo esc_html($staff ? ($v->buyer_phone ?: '—') : gn_mask_phone($v->buyer_phone)); ?></td></tr>
                <tr><th>Email</th><td><?php echo esc_html($staff ? ($v->buyer_email ?: '—') : gn_mask_email($v->buyer_email)); ?></td></tr>
                <tr><th>Ngày mua</th><td><?php echo esc_html(date('d/m/Y H:i', strtotime($v->created_at))); ?></td></tr>
                <tr><th>Ngày thanh toán</th><td><?php echo $v->paid_on ? esc_html(date('d/m/Y', strtotime($v->paid_on))) : '<span style="color:#B45309">chưa thanh toán</span>'; ?></td></tr>
                <tr><th>Đối tác giới thiệu</th><td><?php
                  echo $partner
                    ? '<b>' . esc_html($partner->ref_code) . '</b> · ' . esc_html($partner->contact ?: $partner->company)
                      . ' <small style="color:#6E5D4E">(' . esc_html($partner->type) . ')</small>'
                    : 'Khách tự mua trên web'; ?></td></tr>
                <tr><th>Mệnh giá ban đầu</th><td><?php echo gn_money((float) $v->face_value - $topup_total); ?></td></tr>
                <tr><th>Giá đã trả</th><td><?php echo gn_money($v->price); ?></td></tr>
                <tr><th>Đã nạp thêm</th><td><?php echo $topup_total > 0 ? '<b>' . gn_money($topup_total) . '</b>' : '—'; ?></td></tr>
                <tr><th>Tổng giá trị hiện tại</th><td><b><?php echo gn_money($v->face_value); ?></b></td></tr>
                <tr><th>Đã dùng</th><td><?php echo gn_money($used_total); ?></td></tr>
                <tr><th>Số dư còn lại</th><td><b style="color:#7A5A12;font-size:16px"><?php echo gn_money($v->balance); ?></b></td></tr>
                <tr><th>Hạn dùng</th><td><?php echo esc_html(date('d/m/Y', strtotime($v->expires_on)));
                  echo $het_han ? ' <span class="gnp-tag is-err">đã quá hạn</span>' : ''; ?></td></tr>
                <?php if ($unpaid && $v->hold_until): ?>
                <tr><th>Giữ chỗ đến</th><td><?php echo esc_html(date('d/m/Y', strtotime($v->hold_until))); ?>
                  <small style="color:#6E5D4E">— quá hạn tự huỷ, không mất phí</small></td></tr>
                <?php endif; ?>
              </tbody>
            </table>
          </div>

          <h4 style="margin:20px 0 10px;font-size:16px">Lịch sử giao dịch</h4>
          <div class="gnp-tablewrap">
            <table style="min-width:0">
              <thead><tr><th>Ngày</th><th>Việc</th><th>Số tiền</th><th>Ghi chú</th></tr></thead>
              <tbody>
              <?php foreach ($txn as $t): ?>
                <tr>
                  <td><?php echo esc_html(date('d/m/Y', strtotime($t->happened_on))); ?></td>
                  <td><?php echo esc_html($kind_label[$t->kind] ?? $t->kind); ?></td>
                  <td><?php echo $t->amount > 0 ? gn_money($t->amount) : '—'; ?></td>
                  <td><small><?php echo esc_html($t->note); ?></small></td>
                </tr>
              <?php endforeach; ?>
              <?php if (!$txn): ?><tr><td colspan="4">Chưa có giao dịch nào.</td></tr><?php endif; ?>
              </tbody>
            </table>
          </div>
        </div>

        <?php if ($unpaid && !$het_han): ?>
        <!-- trả trước bằng VietQR -->
        <div class="gnp-portal" style="max-width:560px;margin:16px auto 0;text-align:center">
          <h4 style="margin:0 0 6px;font-size:16px">Trả trước bằng VietQR</h4>
          <p class="gnp-sub" style="margin:0 0 14px">Quét bằng app ngân hàng, số tiền và nội dung đã điền sẵn.
            Không muốn trả trước thì cứ đến nhà hàng trả tại quầy.</p>
          <img src="<?php echo esc_url(gn_vietqr_url($v->price, 'GNV ' . $v->code)); ?>"
               alt="VietQR trả <?php echo esc_attr(gn_money($v->price)); ?>"
               style="max-width:260px;width:100%;background:#fff;border-radius:12px;padding:8px">
          <div style="margin-top:12px;font-size:14px;line-height:1.8;color:var(--gn-text-soft)">
            <b><?php echo esc_html(GN_BANK_NAME); ?></b> — <?php echo esc_html(GN_BANK_ACC); ?><br>
            <?php echo esc_html(GN_BANK_OWNER); ?><br>
            Số tiền <b><?php echo gn_money($v->price); ?></b><br>
            Nội dung <b>GNV <?php echo esc_html($v->code); ?></b>
          </div>
          <p class="gnp-fine">Chuyển xong nhắn Zalo 0979 232 233 kèm mã voucher, nhân viên xác nhận trong ít phút.</p>
        </div>
        <?php endif; ?>

        <?php if ($v->status === 'paid'): ?>
        <!-- nạp thêm -->
        <div class="gnp-portal" style="max-width:560px;margin:16px auto 0">
          <h4 style="margin:0 0 6px;font-size:16px">Nạp thêm vào voucher</h4>
          <p class="gnp-sub" style="margin:0 0 14px">Nạp càng nhiều càng lợi. Mỗi lần nạp, hạn dùng lùi thêm 12 tháng.
            <?php if ($partner) echo 'Tiền nạp cũng tính doanh số cho ' . esc_html($partner->ref_code) . '.'; ?></p>
          <form class="gnp-form" id="gnTopupForm" data-code="<?php echo esc_attr($v->code); ?>" style="padding:0;border:0;background:none">
            <?php foreach ([[200000,200000],[500000,450000],[1000000,880000],[2000000,1700000]] as $i => $o): ?>
              <label style="flex-direction:row;align-items:center;gap:12px;border:1px solid var(--gn-border);
                            border-radius:12px;padding:12px 14px;cursor:pointer">
                <input type="radio" name="topup" value="<?php echo $o[0]; ?>" data-price="<?php echo $o[1]; ?>"
                       <?php echo $i === 2 ? 'checked' : ''; ?> style="min-height:auto;width:auto">
                <span style="flex:1"><b>+<?php echo gn_money($o[0]); ?></b>
                  <small style="color:var(--gn-text-soft)"> · trả <?php echo gn_money($o[1]); ?><?php
                    if ($o[0] > $o[1]) echo ' · lợi ' . gn_money($o[0] - $o[1]); ?></small></span>
              </label>
            <?php endforeach; ?>
            <button type="submit" class="gnp-btn gnp-btn--gold gnp-btn--block">Lấy mã VietQR để nạp</button>
            <div id="gnTopupOut" style="display:none;text-align:center;margin-top:16px"></div>
          </form>
        </div>
        <script>
        (function(){
          var f=document.getElementById('gnTopupForm'); if(!f) return;
          f.addEventListener('submit',function(e){
            e.preventDefault();
            var s=f.querySelector('input[name=topup]:checked');
            var out=document.getElementById('gnTopupOut');
            var price=s.dataset.price, code=f.dataset.code;
            var qr='https://img.vietqr.io/image/<?php echo GN_BANK_BIN; ?>-<?php echo GN_BANK_ACC; ?>-compact2.png'
                  +'?amount='+price+'&addInfo='+encodeURIComponent('GNTOPUP '+code)
                  +'&accountName=<?php echo rawurlencode(GN_BANK_OWNER); ?>';
            out.style.display='block';
            out.innerHTML='<img src="'+qr+'" alt="VietQR nạp thêm" style="max-width:260px;width:100%;'
              +'background:#fff;border-radius:12px;padding:8px">'
              +'<div style="margin-top:12px;font-size:14px;line-height:1.8">'
              +'<b><?php echo esc_js(GN_BANK_NAME); ?></b> — <?php echo esc_js(GN_BANK_ACC); ?><br>'
              +'Số tiền <b>'+Number(price).toLocaleString('vi-VN')+'đ</b><br>'
              +'Nội dung <b>GNTOPUP '+code+'</b></div>'
              +'<p class="gnp-fine">Chuyển xong nhắn Zalo 0979 232 233 kèm mã voucher. '
              +'Nhân viên xác nhận là số dư cộng ngay.</p>';
          });
        })();
        </script>
        <?php endif; ?>

        <?php if ($staff): ?>
        <div class="gnp-rules" style="max-width:560px;margin:16px auto 0">
          <p class="gnp-eyebrow">Dành cho nhân viên</p>
          Bạn đang đăng nhập nên thấy số điện thoại và email đầy đủ.
          Thu tiền và trừ hoá đơn làm ở <a href="<?php echo esc_url(admin_url('admin.php?page=gn-counter')); ?>">wp-admin → Gánh Ngon → Tại quầy</a>.
        </div>
        <?php endif; ?>
      </section>
    </div><?php
    return ob_get_clean();
}

/* GN — VIETQR + TRA CỨU VOUCHER END */

/* ==========================================================================
   GN — PHÁT HÀNH VOUCHER THEO LÔ CHO ĐỐI TÁC (bán sỉ)
   --------------------------------------------------------------------------
   Khác hẳn voucher lẻ khách tự mua qua QR:

     Voucher lẻ         : khách trả từng cái, hoa hồng LUỸ TIẾN theo doanh số ngày.
     Voucher lô (ở đây) : nhà hàng phát cả ngàn cái cho một đối tác, đối tác trả
                          MỘT CỤC, hoa hồng PHẲNG một tỷ lệ (mặc định 10%).

   Ví dụ chủ nhà hàng đưa ra:
     Phát 1000 voucher, mỗi cái 50.000đ  -> tổng mệnh giá 50.000.000đ
     Hoa hồng 10%                        -> 5.000.000đ cho đối tác
     Đối tác trả nhà hàng một cục        -> 50.000.000 - 5.000.000 = 45.000.000đ
     Khách dùng, có ai nạp thêm 8.000.000đ -> hoa hồng thêm 10% = 800.000đ

   Vì hoa hồng lô là PHẲNG, không đi qua công thức luỹ tiến, phải ghi vào một sổ
   riêng (sao_commissions) rồi cộng vào "phải trả" của đối tác. Tách bạch để không
   lẫn hai loại hoa hồng — đối tác nào cũng có thể vừa bán lô vừa dẫn khách lẻ.

   Kế toán:
     Tiền đối tác trả (45tr)     = doanh thu bán voucher sỉ (tiền vào thật).
     Tổng mệnh giá lưu hành (50tr) = NỢ PHẢI TRẢ, nghĩa vụ phục vụ khi khách dùng.
     Chênh 5tr                    = chiết khấu/hoa hồng, chi phí bán hàng.
   ========================================================================== */

if (!defined('ABSPATH')) exit;

define('GN_BATCH_RATE_DEFAULT', 10);   // phần trăm hoa hồng phẳng mặc định

/* ---------- lược đồ ---------- */
function gn_batch_migrate() {
    global $wpdb;
    $charset = $wpdb->get_charset_collate();
    require_once ABSPATH . 'wp-admin/includes/upgrade.php';

    // Lô phát hành
    dbDelta("CREATE TABLE " . gn_tbl('voucher_batches') . " (
        id INT AUTO_INCREMENT PRIMARY KEY,
        batch_code VARCHAR(24) NOT NULL,
        partner_id INT NOT NULL,
        ref_code VARCHAR(50) NULL,
        quantity INT NOT NULL DEFAULT 0,
        face_value DECIMAL(12,2) NOT NULL DEFAULT 0,
        total_face DECIMAL(14,2) NOT NULL DEFAULT 0,
        commission_rate DECIMAL(5,2) NOT NULL DEFAULT 10,
        commission_amount DECIMAL(14,2) NOT NULL DEFAULT 0,
        amount_due DECIMAL(14,2) NOT NULL DEFAULT 0,
        status VARCHAR(20) NOT NULL DEFAULT 'draft',
        expires_on DATE NULL,
        settled_on DATE NULL,
        note VARCHAR(255) NULL,
        created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
        UNIQUE KEY batch_code (batch_code),
        KEY partner (partner_id, status)
    ) $charset");

    // Sổ hoa hồng phẳng (lô + nạp thêm vào voucher lô). Tách khỏi luỹ tiến.
    dbDelta("CREATE TABLE " . gn_tbl('commissions') . " (
        id INT AUTO_INCREMENT PRIMARY KEY,
        partner_id INT NOT NULL,
        ref_code VARCHAR(50) NULL,
        kind VARCHAR(20) NOT NULL,
        base_amount DECIMAL(14,2) NOT NULL DEFAULT 0,
        rate DECIMAL(5,2) NOT NULL DEFAULT 0,
        amount DECIMAL(14,2) NOT NULL DEFAULT 0,
        ref_id INT NULL,
        note VARCHAR(255) NULL,
        happened_on DATE NOT NULL,
        paid TINYINT NOT NULL DEFAULT 0,
        created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
        KEY partner_month (partner_id, happened_on)
    ) $charset");

    // Voucher cần biết mình thuộc lô nào
    if (!gn_column_exists(gn_tbl('vouchers'), 'batch_id')) {
        $wpdb->query("ALTER TABLE " . gn_tbl('vouchers') . " ADD COLUMN batch_id INT NULL DEFAULT NULL");
        $wpdb->query("ALTER TABLE " . gn_tbl('vouchers') . " ADD INDEX gn_batch (batch_id)");
    }
    update_option('gn_batch_version', '1.0.1');
}
add_action('init', function () {
    if (get_option('gn_batch_version') !== '1.0.1') gn_batch_migrate();
}, 6);

function gn_batch_ghi_hoa_hong($partner_id, $ref_code, $kind, $base, $rate, $ref_id, $note) {
    global $wpdb;
    $amount = round((float) $base * (float) $rate / 100);
    $wpdb->insert(gn_tbl('commissions'), [
        'partner_id'  => (int) $partner_id,
        'ref_code'    => $ref_code,
        'kind'        => $kind,
        'base_amount' => (float) $base,
        'rate'        => (float) $rate,
        'amount'      => $amount,
        'ref_id'      => $ref_id ? (int) $ref_id : null,
        'note'        => $note,
        'happened_on' => current_time('Y-m-d'),
    ]);
    return $amount;
}

/** Tổng hoa hồng phẳng của một đối tác trong một kỳ YYYY-MM. */
function gn_batch_commission_period($partner_id, $ym) {
    global $wpdb;
    $from = $ym . '-01';
    $to   = date('Y-m-t', strtotime($from));
    $rows = $wpdb->get_results($wpdb->prepare(
        "SELECT kind, SUM(amount) amt, COUNT(*) so FROM " . gn_tbl('commissions') . "
         WHERE partner_id = %d AND happened_on BETWEEN %s AND %s
         GROUP BY kind", $partner_id, $from, $to));
    $out = ['tong' => 0, 'lo' => 0, 'topup' => 0, 'chi_tiet' => []];
    foreach ($rows as $r) {
        $out['tong'] += (float) $r->amt;
        if ($r->kind === 'batch') $out['lo'] += (float) $r->amt;
        if ($r->kind === 'batch_topup') $out['topup'] += (float) $r->amt;
        $out['chi_tiet'][$r->kind] = ['tien' => round($r->amt), 'so' => (int) $r->so];
    }
    $out['tong'] = round($out['tong']);
    return $out;
}

/**
 * Phát hành một lô. Sinh N voucher ở trạng thái 'unpaid' cho tới khi đối tác
 * trả tiền một cục; lúc đó cả lô mới thành 'paid' và dùng được.
 */
function gn_batch_issue($partner_id, $quantity, $face_value, $rate, $note = '', $months = 12) {
    global $wpdb;
    $p = $wpdb->get_row($wpdb->prepare("SELECT * FROM " . gn_tbl('partners') . " WHERE id = %d", $partner_id));
    if (!$p) return ['loi' => 'Không tìm thấy đối tác'];
    if ($p->status !== 'active') return ['loi' => 'Đối tác chưa được duyệt (đang ' . $p->status . ')'];

    $quantity = max(1, (int) $quantity);
    $face_value = round((float) $face_value);
    $rate = (float) $rate;
    if ($quantity > 5000) return ['loi' => 'Một lô tối đa 5000 voucher, chia nhỏ ra'];
    if ($face_value <= 0) return ['loi' => 'Mệnh giá phải lớn hơn 0'];
    if ($rate < 0 || $rate > 50) return ['loi' => 'Tỷ lệ hoa hồng phải từ 0 đến 50%'];

    $total_face = $face_value * $quantity;
    $commission = round($total_face * $rate / 100);
    $amount_due = $total_face - $commission;
    $code = 'GN-B-' . strtoupper(substr(md5(uniqid('', true)), 0, 8));
    $expires = date('Y-m-d', strtotime("+$months months"));

    $wpdb->insert(gn_tbl('voucher_batches'), [
        'batch_code' => $code, 'partner_id' => $p->id, 'ref_code' => $p->ref_code,
        'quantity' => $quantity, 'face_value' => $face_value, 'total_face' => $total_face,
        'commission_rate' => $rate, 'commission_amount' => $commission, 'amount_due' => $amount_due,
        'status' => 'issued', 'expires_on' => $expires, 'note' => sanitize_text_field($note),
    ]);
    $batch_id = $wpdb->insert_id;
    if (!$batch_id) return ['loi' => 'Không tạo được lô'];

    // Sinh voucher. Chèn theo mẻ để không quá tải một câu lệnh.
    $abc = 'ABCDEFGHJKLMNPQRSTUVWXYZ23456789';
    $vtbl = gn_tbl('vouchers');
    $now = current_time('mysql');
    $made = 0;
    $batch_rows = [];
    for ($i = 0; $i < $quantity; $i++) {
        $s = '';
        for ($j = 0; $j < 8; $j++) $s .= $abc[random_int(0, strlen($abc) - 1)];
        $vc = 'GN-V-' . substr($s, 0, 4) . '-' . substr($s, 4, 4);
        $batch_rows[] = $wpdb->prepare("(%s,%d,%s,%d,%f,%f,%f,%s,%s,%s)",
            $vc, $p->id, $p->ref_code, $batch_id, $face_value, $face_value, 0, 'unpaid', $expires, $now);
        if (count($batch_rows) >= 200) {
            $wpdb->query("INSERT INTO {$vtbl}
                (code,partner_id,ref_code,batch_id,face_value,price,balance,status,expires_on,created_at)
                VALUES " . implode(',', $batch_rows));
            $made += count($batch_rows); $batch_rows = [];
        }
    }
    if ($batch_rows) {
        $wpdb->query("INSERT INTO {$vtbl}
            (code,partner_id,ref_code,batch_id,face_value,price,balance,status,expires_on,created_at)
            VALUES " . implode(',', $batch_rows));
        $made += count($batch_rows);
    }

    return [
        'batch_code' => $code, 'batch_id' => $batch_id, 'da_tao' => $made,
        'tong_menh_gia' => round($total_face), 'hoa_hong' => $commission,
        'doi_tac_phai_tra' => round($amount_due), 'ty_le' => $rate,
    ];
}

/**
 * Đối tác trả tiền một cục. Cả lô chuyển sang dùng được, ghi hoa hồng phẳng vào sổ.
 * Chạy lại lần hai không cộng đôi (kiểm status trước).
 */
function gn_batch_settle($batch_id) {
    global $wpdb;
    $b = $wpdb->get_row($wpdb->prepare("SELECT * FROM " . gn_tbl('voucher_batches') . " WHERE id = %d", $batch_id));
    if (!$b) return ['loi' => 'Không tìm thấy lô'];
    if ($b->status === 'settled') return ['loi' => 'Lô này đã thu tiền rồi'];

    // Voucher trong lô: unpaid -> paid, nạp số dư
    $wpdb->query($wpdb->prepare(
        "UPDATE " . gn_tbl('vouchers') . " SET status = 'paid', balance = face_value, paid_on = %s
         WHERE batch_id = %d AND status = 'unpaid'", current_time('Y-m-d'), $batch_id));

    $wpdb->update(gn_tbl('voucher_batches'),
        ['status' => 'settled', 'settled_on' => current_time('Y-m-d')], ['id' => $batch_id]);

    // Hoa hồng phẳng cho đối tác, ghi trên TỔNG MỆNH GIÁ
    $hh = gn_batch_ghi_hoa_hong($b->partner_id, $b->ref_code, 'batch',
        $b->total_face, $b->commission_rate, $batch_id,
        'Lô ' . $b->batch_code . ' · ' . (int) $b->quantity . ' voucher');

    return [
        'batch_code' => $b->batch_code, 'trang_thai' => 'settled',
        'da_thu_tu_doi_tac' => round($b->amount_due),
        'hoa_hong_ghi_so' => $hh,
        'voucher_dung_duoc' => (int) $b->quantity,
    ];
}

/**
 * Khi nạp thêm vào một voucher THUỘC LÔ, đối tác của lô ăn hoa hồng phẳng trên
 * tiền nạp. Móc vào hook gn_voucher_topped_up nếu theme bắn ra; nếu không thì
 * gọi trực tiếp từ chỗ nạp thêm.
 */
function gn_batch_on_topup($voucher_id, $add_amount) {
    global $wpdb;
    $v = $wpdb->get_row($wpdb->prepare(
        "SELECT batch_id, partner_id, ref_code FROM " . gn_tbl('vouchers') . " WHERE id = %d", $voucher_id));
    if (!$v || !$v->batch_id || !$v->partner_id) return;   // chỉ voucher thuộc lô
    $b = $wpdb->get_row($wpdb->prepare(
        "SELECT commission_rate, batch_code FROM " . gn_tbl('voucher_batches') . " WHERE id = %d", $v->batch_id));
    if (!$b) return;
    gn_batch_ghi_hoa_hong($v->partner_id, $v->ref_code, 'batch_topup',
        $add_amount, $b->commission_rate, $v->batch_id,
        'Nạp thêm vào voucher lô ' . $b->batch_code);
}
add_action('gn_voucher_topped_up', 'gn_batch_on_topup', 10, 2);

/* ==========================================================================
   MÀN QUẢN TRỊ — wp-admin → Gánh Ngon → Voucher lô
   ========================================================================== */

add_action('admin_menu', function () {
    add_submenu_page('gn-home', 'Voucher lô cho đối tác', 'Voucher lô', GN_CAP,
        'gn-batch', 'gn_batch_admin');
}, 15);

function gn_batch_admin() {
    if (!current_user_can(GN_CAP)) wp_die('Không có quyền');
    global $wpdb; gn_admin_css();
    $BT = gn_tbl('voucher_batches');

    if (isset($_POST['gn_phat_lo']) && check_admin_referer('gn_batch_new')) {
        $r = gn_batch_issue(
            (int) $_POST['partner_id'], (int) $_POST['quantity'],
            (float) $_POST['face_value'], (float) $_POST['rate'],
            sanitize_text_field($_POST['note'] ?? ''));
        if (isset($r['loi'])) {
            echo '<div class="notice notice-error"><p>' . esc_html($r['loi']) . '</p></div>';
        } else {
            echo '<div class="notice notice-success"><p>Đã phát lô <b>' . esc_html($r['batch_code']) . '</b>: '
               . number_format($r['da_tao']) . ' voucher · tổng mệnh giá ' . gn_money($r['tong_menh_gia'])
               . ' · hoa hồng ' . gn_money($r['hoa_hong']) . ' · đối tác phải trả <b>'
               . gn_money($r['doi_tac_phai_tra']) . '</b>. Lô đang chờ đối tác thanh toán một cục.</p></div>';
        }
    }
    if (isset($_POST['gn_thu_lo']) && check_admin_referer('gn_batch_settle')) {
        $r = gn_batch_settle((int) $_POST['batch_id']);
        echo isset($r['loi'])
            ? '<div class="notice notice-error"><p>' . esc_html($r['loi']) . '</p></div>'
            : '<div class="notice notice-success"><p>Đã thu ' . gn_money($r['da_thu_tu_doi_tac'])
              . ' cho lô <b>' . esc_html($r['batch_code']) . '</b>. ' . number_format($r['voucher_dung_duoc'])
              . ' voucher có hiệu lực. Ghi hoa hồng ' . gn_money($r['hoa_hong_ghi_so']) . ' vào sổ.</p></div>';
    }

    $partners = $wpdb->get_results("SELECT id, ref_code, contact, company FROM " . gn_tbl('partners') . " WHERE status = 'active' ORDER BY ref_code");
    $batches = $wpdb->get_results("SELECT b.*, p.contact, p.company FROM {$BT} b
        LEFT JOIN " . gn_tbl('partners') . " p ON p.id = b.partner_id ORDER BY b.id DESC LIMIT 50");
    ?>
    <div class="wrap gnw">
      <h1>Voucher lô cho đối tác</h1>
      <p class="sub">Bán sỉ cho đối tác: phát cả lô, đối tác trả một cục, hoa hồng phẳng.
        Khác với voucher lẻ khách tự mua qua QR (hoa hồng luỹ tiến theo ngày).</p>

      <?php if (!$partners): ?>
        <div class="notice notice-warning"><p>Chưa có đối tác nào ở trạng thái <b>active</b>.
          Vào <a href="?page=gn-partners">Đối tác</a> thêm và duyệt trước.</p></div>
      <?php else: ?>
      <div class="card">
        <h2>Phát lô mới</h2>
        <form method="post"><?php wp_nonce_field('gn_batch_new'); ?>
          <div class="grid3">
            <div><label>Đối tác *</label>
              <select name="partner_id" required style="width:100%">
                <?php foreach ($partners as $p): ?>
                  <option value="<?php echo (int) $p->id; ?>"><?php echo esc_html($p->ref_code . ' · ' . ($p->contact ?: $p->company)); ?></option>
                <?php endforeach; ?>
              </select></div>
            <div><label>Số lượng voucher *</label>
              <input type="number" name="quantity" min="1" max="5000" value="1000" required style="width:100%" id="gnb_qty"></div>
            <div><label>Mệnh giá mỗi voucher (đồng) *</label>
              <input type="number" name="face_value" min="1000" step="1000" value="50000" required style="width:100%" id="gnb_face"></div>
            <div><label>Hoa hồng (%) *</label>
              <input type="number" name="rate" min="0" max="50" step="0.5" value="10" required style="width:100%" id="gnb_rate"></div>
            <div style="grid-column:span 2"><label>Ghi chú</label>
              <input name="note" placeholder="Ví dụ: lô Tết 2027, in kèm bao lì xì" style="width:100%"></div>
          </div>
          <div class="note" id="gnb_preview" style="margin:14px 0">Nhập số liệu để xem trước.</div>
          <p><button class="button button-primary" name="gn_phat_lo" value="1">Phát lô</button></p>
        </form>
      </div>
      <script>
      (function(){
        var q=document.getElementById('gnb_qty'),f=document.getElementById('gnb_face'),
            r=document.getElementById('gnb_rate'),out=document.getElementById('gnb_preview');
        function vnd(n){return new Intl.NumberFormat('vi-VN').format(Math.round(n))+'đ';}
        function up(){
          var total=(+q.value||0)*(+f.value||0), hh=total*(+r.value||0)/100;
          out.innerHTML='<b>'+new Intl.NumberFormat('vi-VN').format(+q.value||0)+'</b> voucher × '+vnd(+f.value||0)
            +' = tổng mệnh giá <b>'+vnd(total)+'</b><br>Hoa hồng '+(+r.value||0)+'% = <b>'+vnd(hh)
            +'</b> · Đối tác trả một cục <b style="color:#7A5A12">'+vnd(total-hh)+'</b>';
        }
        [q,f,r].forEach(function(el){el.addEventListener('input',up);}); up();
      })();
      </script>
      <?php endif; ?>

      <div class="card">
        <h2>Các lô đã phát</h2>
        <div class="gnp-tablewrap" style="overflow-x:auto">
        <table class="wp-list-table widefat striped">
          <thead><tr><th>Mã lô</th><th>Đối tác</th><th>SL</th><th>Mệnh giá</th><th>Tổng</th>
            <th>HH %</th><th>Hoa hồng</th><th>Đối tác trả</th><th>Trạng thái</th><th>Đã dùng</th><th>Thao tác</th></tr></thead>
          <tbody>
          <?php if (!$batches) echo '<tr><td colspan="11">Chưa phát lô nào.</td></tr>';
          foreach ($batches as $b):
            $da_dung = (int) $wpdb->get_var($wpdb->prepare(
              "SELECT COUNT(*) FROM " . gn_tbl('vouchers') . " WHERE batch_id = %d AND status IN ('used','paid') AND balance < face_value", $b->id));
            $cls = $b->status === 'settled' ? 'ok' : ($b->status === 'issued' ? 'wait' : 'off'); ?>
            <tr>
              <td><code><?php echo esc_html($b->batch_code); ?></code></td>
              <td><?php echo esc_html($b->ref_code . ' · ' . ($b->contact ?: $b->company)); ?></td>
              <td><?php echo number_format($b->quantity); ?></td>
              <td><?php echo gn_money($b->face_value); ?></td>
              <td><?php echo gn_money($b->total_face); ?></td>
              <td><?php echo rtrim(rtrim((string) $b->commission_rate, '0'), '.'); ?>%</td>
              <td><?php echo gn_money($b->commission_amount); ?></td>
              <td><b><?php echo gn_money($b->amount_due); ?></b></td>
              <td><span class="tag <?php echo $cls; ?>"><?php
                echo $b->status === 'settled' ? 'đã thu tiền' : ($b->status === 'issued' ? 'chờ thu tiền' : $b->status); ?></span></td>
              <td><?php echo number_format($da_dung); ?></td>
              <td><?php if ($b->status === 'issued'): ?>
                <form method="post" style="display:inline"><?php wp_nonce_field('gn_batch_settle'); ?>
                  <input type="hidden" name="batch_id" value="<?php echo (int) $b->id; ?>">
                  <button class="button button-primary" name="gn_thu_lo" value="1"
                    onclick="return confirm('Xác nhận đã thu <?php echo esc_js(gn_money($b->amount_due)); ?> từ đối tác? Cả lô sẽ dùng được và hoa hồng vào sổ.')">
                    Xác nhận đã thu tiền</button>
                </form>
              <?php else: echo '—'; endif; ?></td>
            </tr>
          <?php endforeach; ?>
          </tbody>
        </table>
        </div>
        <div class="note"><b>Cách hoạt động.</b> Phát lô xong, voucher ở trạng thái CHƯA THANH TOÁN,
          chưa dùng được. Đối tác trả một cục (tổng mệnh giá trừ hoa hồng) rồi bấm
          <b>Xác nhận đã thu tiền</b> — cả lô có hiệu lực ngay, khách quét dùng được, và hoa hồng
          vào sổ. Khách nạp thêm vào voucher của lô thì đối tác ăn tiếp hoa hồng phẳng trên tiền nạp.</div>
      </div>
    </div>
    <?php
}

/* GN — VOUCHER LÔ END */

/* ==========================================================================
   GN — HOÁ ĐƠN TỰ ĐỘNG CHO KHÁCH + THÔNG BÁO ĐỐI SOÁT CHO ĐỐI TÁC
   --------------------------------------------------------------------------
   Nội dung thư theo đúng mẫu chủ nhà hàng duyệt.

   Điểm cần chú ý về con số gửi cho đối tác: hoa hồng tính LUỸ TIẾN trên doanh số
   CẢ NGÀY (5tr đầu 10%, 5–10tr 12%, vượt 10tr 15%), nên một đơn lẻ không có tỷ lệ
   cố định. Số tiền của riêng đơn đó = hoa hồng cả ngày SAU đơn trừ hoa hồng cả
   ngày TRƯỚC đơn. Cộng các phần chênh này lại đúng bằng tổng hoa hồng ngày, nên
   đối tác cộng tay cũng khớp.

   Ba mốc kích hoạt:
     gn_voucher_paid       khách trả tiền voucher  -> hoá đơn khách + báo đối tác
     gn_voucher_topped_up  khách nạp thêm          -> hoá đơn khách + báo đối tác
     gn_voucher_redeemed   khách dùng voucher      -> hoá đơn khách (hoa hồng đã chốt lúc trả tiền)
     gn_booking_settled    chốt doanh số bữa ăn    -> hoá đơn khách + báo đối tác
   ========================================================================== */

define('GN_HOTLINE',       '0979 232 233');
define('GN_EMAIL_HOTRO',   'contact@ganhngon.com');
define('GN_EMAIL_DOITAC',  'partner@ganhngon.com');

function gn_mail_shell($than, $mau_dai, $chu_dai) {
    return '<div style="background:#F0E9DC;padding:24px 12px">
  <table role="presentation" cellpadding="0" cellspacing="0" style="max-width:600px;margin:0 auto;width:100%;background:#fff;border-radius:12px;overflow:hidden">
    <tr><td style="background:#2C1810;padding:26px 24px;text-align:center">
      <div style="font:600 26px/1.2 Georgia,serif;letter-spacing:.05em;color:#D4AF37">GÁNH NGON</div>
      <div style="font:600 9px/1.4 Arial,sans-serif;letter-spacing:.08em;color:#C9B79E;margin-top:4px">ĐẶC SẢN VIỆT NAM · PHÚ QUỐC</div>
    </td></tr>
    <tr><td style="background:' . $mau_dai . ';color:#fff;padding:11px 24px;font:700 12px/1.5 Arial,sans-serif;letter-spacing:.04em">' . esc_html($chu_dai) . '</td></tr>
    <tr><td style="padding:28px 24px;font:400 15px/1.75 Arial,sans-serif;color:#3D3128">' . $than . '</td></tr>
    <tr><td style="background:#1A0E07;padding:20px 24px;text-align:center;font:400 12px/1.7 Arial,sans-serif;color:#C9B79E">
      Gánh Ngon · 113 Trần Hưng Đạo, Dương Đông, Phú Quốc<br>
      ' . esc_html(GN_HOTLINE) . ' · Zalo · WhatsApp · ' . esc_html(GN_EMAIL_HOTRO) . '
    </td></tr>
  </table></div>';
}

/** Danh sách gạch đầu dòng, khoá in thường, giá trị in đậm. */
function gn_mail_list($rows) {
    $out = '<ul style="margin:0 0 18px;padding-left:20px">';
    foreach ($rows as $k => $v) {
        $dam = str_starts_with((string) $k, '*');
        $k = ltrim((string) $k, '*');
        $out .= '<li style="margin-bottom:7px">' . esc_html($k) . ': '
              . ($dam ? '<b style="color:#7A5A12;font-size:16px">' : '<b>')
              . esc_html($v) . '</b></li>';
    }
    return $out . '</ul>';
}

function gn_invoice_no($prefix, $id) {
    return $prefix . date('Ymd') . '-' . str_pad((string) $id, 5, '0', STR_PAD_LEFT);
}

/** Ngày chuyển khoản của kỳ: ngày 5 tháng kế tiếp. */
function gn_payout_date() {
    return date('d/m/Y', strtotime('first day of next month +4 days', strtotime(current_time('Y-m-d'))));
}

/* ==========================================================================
   HOÁ ĐƠN CHO KHÁCH — theo mẫu đã duyệt
   ========================================================================== */
function gn_send_customer_invoice($args) {
    if (empty($args['email'])) return;
    $than =
      '<p style="margin:0 0 16px">Kính chào <b>' . esc_html($args['ten_khach']) . '</b>,</p>'
    . '<p style="margin:0 0 16px">Cảm ơn Quý khách đã tin tưởng và sử dụng dịch vụ của <b>Gánh Ngon</b>.</p>'
    . '<p style="margin:0 0 12px">Gánh Ngon xin gửi thông tin hóa đơn cho dịch vụ Quý khách vừa sử dụng:</p>'
    . gn_mail_list([
        'Mã đơn hàng'        => $args['ma_don'],
        'Dịch vụ'            => $args['dich_vu'],
        'Ngày sử dụng'       => $args['ngay'],
        '*Tổng thanh toán'   => $args['tong'],
        'Mã hóa đơn'         => $args['ma_hoa_don'],
      ])
    . '<p style="margin:0 0 16px">Hóa đơn điện tử có thể xem tại: '
    . '<a href="' . esc_url($args['link']) . '" style="color:#7A5A12">' . esc_html($args['link']) . '</a></p>'
    . '<p style="margin:0 0 16px">Nếu cần hỗ trợ về hóa đơn hoặc dịch vụ, Quý khách vui lòng liên hệ với Gánh Ngon qua '
    . '<b>' . esc_html(GN_HOTLINE) . '</b> hoặc <a href="mailto:' . esc_attr(GN_EMAIL_HOTRO) . '" style="color:#7A5A12">'
    . esc_html(GN_EMAIL_HOTRO) . '</a>.</p>'
    . '<p style="margin:0 0 20px">Cảm ơn Quý khách và hẹn gặp lại trong những trải nghiệm tiếp theo cùng <b>Gánh Ngon</b>.</p>'
    . '<p style="margin:0;color:#6E5D4E">Trân trọng,<br><b style="color:#1F1710">Gánh Ngon</b><br>'
    . '<a href="https://ganhngon.com" style="color:#7A5A12">ganhngon.com</a></p>';

    @wp_mail($args['email'],
        'Hóa đơn Gánh Ngon · ' . $args['ma_don'],
        gn_mail_shell($than, '#1E7A4C', 'ĐÃ THANH TOÁN ' . $args['tong']),
        ['Content-Type: text/html; charset=UTF-8']);
}

/* ==========================================================================
   THÔNG BÁO ĐỐI SOÁT CHO ĐỐI TÁC — theo mẫu đã duyệt
   ========================================================================== */
function gn_send_partner_notice($partner_id, $args) {
    if (!$partner_id) return;
    global $wpdb;
    $p = $wpdb->get_row($wpdb->prepare("SELECT * FROM " . gn_tbl('partners') . " WHERE id=%d", $partner_id));
    if (!$p || empty($p->email)) return;

    $ten_dt   = $p->contact ?: $p->company;
    $gia_tri  = (float) $args['gia_tri'];
    $nhan     = (float) $args['doi_tac_nhan'];
    $phi      = max(0, $gia_tri - $nhan);
    $link     = $p->portal_token ? home_url('/cong-doi-tac/?t=' . $p->portal_token) : home_url('/doi-tac/');

    $than =
      '<p style="margin:0 0 16px">Kính chào <b>' . esc_html($ten_dt) . '</b>,</p>'
    . '<p style="margin:0 0 16px">Gánh Ngon xin thông báo khách hàng đã hoàn tất sử dụng dịch vụ thuộc đơn hàng '
    . '<b>#' . esc_html($args['ma_don']) . '</b> giới thiệu bởi <b>' . esc_html($ten_dt)
    . ' (' . esc_html($p->ref_code) . ')</b>.</p>'
    . '<p style="margin:0 0 12px">Thông tin giao dịch:</p>'
    . gn_mail_list([
        'Khách hàng'                     => $args['ten_khach'],
        'Dịch vụ'                        => $args['dich_vu'],
        'Ngày sử dụng'                   => $args['ngay'],
        'Giá trị đơn hàng'               => gn_money($gia_tri),
        'Phí dịch vụ Gánh Ngon giữ lại'  => gn_money($phi),
        '*Số tiền đối tác được nhận'     => gn_money($nhan),
        'Dự kiến thanh toán'             => gn_payout_date(),
      ])
    . '<div style="background:#FAF7F0;border-left:3px solid #D4AF37;padding:12px 16px;margin:0 0 18px;font-size:13px;line-height:1.7;color:#5A4B3E">'
    . 'Hoa hồng tính luỹ tiến trên doanh số <b>cả ngày</b>: 5 triệu đầu 10%, phần 5–10 triệu 12%, phần vượt 10 triệu 15%. '
    . 'Số tiền của riêng đơn này là phần chênh khi doanh số ngày tăng từ ' . gn_money($args['ngay_truoc'])
    . ' lên ' . gn_money($args['ngay_sau']) . '. Cộng các đơn trong ngày lại sẽ khớp đúng tổng hoa hồng ngày là '
    . '<b>' . gn_money($args['hoa_hong_ngay']) . '</b>.'
    . '</div>'
    . '<p style="margin:0 0 16px">Khoản tiền trên sẽ được Gánh Ngon đối soát và thanh toán theo chính sách hợp tác hiện hành.</p>'
    . '<p style="margin:0 0 16px">Quý Đối tác có thể xem chi tiết giao dịch và lịch sử đối soát tại: '
    . '<a href="' . esc_url($link) . '" style="color:#7A5A12">' . esc_html($link) . '</a></p>'
    . '<p style="margin:0 0 16px">Nếu có thắc mắc về giao dịch hoặc số tiền đối soát, vui lòng liên hệ '
    . '<a href="mailto:' . esc_attr(GN_EMAIL_DOITAC) . '" style="color:#7A5A12">' . esc_html(GN_EMAIL_DOITAC) . '</a>.</p>'
    . '<p style="margin:0 0 20px">Cảm ơn Quý Đối tác đã đồng hành cùng <b>Gánh Ngon</b>.</p>'
    . '<p style="margin:0;color:#6E5D4E">Trân trọng,<br><b style="color:#1F1710">Gánh Ngon – Bộ phận Đối tác</b><br>'
    . '<a href="https://ganhngon.com" style="color:#7A5A12">ganhngon.com</a></p>';

    @wp_mail($p->email,
        'Đối soát Gánh Ngon · đơn #' . $args['ma_don'] . ' · nhận ' . gn_money($nhan),
        gn_mail_shell($than, '#7A5A12', 'ĐỐI TÁC NHẬN ' . gn_money($nhan)),
        ['Content-Type: text/html; charset=UTF-8']);

    if (function_exists('gn_send_telegram')) {
        gn_send_telegram('💰 <b>' . $p->ref_code . '</b> đơn ' . esc_html($args['ma_don'])
            . ' ' . gn_money($gia_tri) . ' · đối tác nhận ' . gn_money($nhan));
    }
}

/**
 * Doanh số hợp lệ trong ngày của một đối tác, tính đến thời điểm gọi.
 * Dùng để lấy phần chênh hoa hồng của riêng giao dịch vừa phát sinh.
 */
function gn_partner_day_revenue($partner_id, $date = null) {
    global $wpdb;
    $date = $date ?: current_time('Y-m-d');
    $r = (float) $wpdb->get_var($wpdb->prepare(
        "SELECT COALESCE(SUM(revenue),0) FROM " . gn_tbl('bookings') . "
         WHERE partner_id=%d AND served_on=%s AND booking_status IN ('served','checked_in','completed')",
        $partner_id, $date));
    $r += (float) $wpdb->get_var($wpdb->prepare(
        "SELECT COALESCE(SUM(CASE WHEN kind IN ('pay','topup') THEN amount ELSE -amount END),0)
         FROM " . gn_tbl('voucher_txn') . "
         WHERE partner_id=%d AND happened_on=%s AND kind IN ('pay','topup','refund')",
        $partner_id, $date));
    return max(0, $r);
}

/** Gói chung: tính phần chênh rồi gửi thư cho đối tác. */
function gn_partner_notice_for($partner_id, $gia_tri, $meta) {
    if (!$partner_id) return;
    $sau    = gn_partner_day_revenue($partner_id);          // đã gồm giao dịch vừa ghi
    $truoc  = max(0, $sau - (float) $gia_tri);
    $chenh  = gn_commission_for_day($sau) - gn_commission_for_day($truoc);
    gn_send_partner_notice($partner_id, array_merge($meta, [
        'gia_tri'       => $gia_tri,
        'doi_tac_nhan'  => max(0, $chenh),
        'ngay_truoc'    => $truoc,
        'ngay_sau'      => $sau,
        'hoa_hong_ngay' => gn_commission_for_day($sau),
    ]));
}

/* ==========================================================================
   GẮN VÀO CÁC MỐC
   ========================================================================== */

add_action('gn_voucher_paid', function ($voucher_id, $paid) {
    global $wpdb;
    $v = $wpdb->get_row($wpdb->prepare("SELECT * FROM " . gn_tbl('vouchers') . " WHERE id=%d", $voucher_id));
    if (!$v) return;
    $dich_vu = 'Voucher tiền mặt ' . gn_money($v->face_value);
    gn_send_customer_invoice([
        'email'      => $v->buyer_email,
        'ten_khach'  => $v->buyer_name ?: 'Quý khách',
        'ma_don'     => $v->code,
        'dich_vu'    => $dich_vu,
        'ngay'       => date('d/m/Y', current_time('timestamp')),
        'tong'       => gn_money($paid),
        'ma_hoa_don' => gn_invoice_no('GNV', $v->id),
        'link'       => home_url('/voucher/?c=' . $v->code),
    ]);
    gn_partner_notice_for($v->partner_id, $paid, [
        'ma_don'    => $v->code,
        'ten_khach' => $v->buyer_name ?: 'Khách lẻ',
        'dich_vu'   => $dich_vu,
        'ngay'      => date('d/m/Y', current_time('timestamp')),
    ]);
}, 10, 2);

add_action('gn_voucher_topped_up', function ($voucher_id, $add_face, $paid) {
    global $wpdb;
    $v = $wpdb->get_row($wpdb->prepare("SELECT * FROM " . gn_tbl('vouchers') . " WHERE id=%d", $voucher_id));
    if (!$v) return;
    $dich_vu = 'Nạp thêm ' . gn_money($add_face) . ' vào voucher';
    gn_send_customer_invoice([
        'email'      => $v->buyer_email,
        'ten_khach'  => $v->buyer_name ?: 'Quý khách',
        'ma_don'     => $v->code,
        'dich_vu'    => $dich_vu,
        'ngay'       => date('d/m/Y', current_time('timestamp')),
        'tong'       => gn_money($paid),
        'ma_hoa_don' => gn_invoice_no('GNT', $v->id),
        'link'       => home_url('/voucher/?c=' . $v->code),
    ]);
    gn_partner_notice_for($v->partner_id, $paid, [
        'ma_don'    => $v->code,
        'ten_khach' => $v->buyer_name ?: 'Khách lẻ',
        'dich_vu'   => $dich_vu,
        'ngay'      => date('d/m/Y', current_time('timestamp')),
    ]);
}, 10, 3);

/** Dùng voucher: gửi hoá đơn cho khách. Hoa hồng đã chốt từ lúc trả tiền nên không báo lại đối tác. */
add_action('gn_voucher_redeemed', function ($voucher_id, $used, $left) {
    global $wpdb;
    $v = $wpdb->get_row($wpdb->prepare("SELECT * FROM " . gn_tbl('vouchers') . " WHERE id=%d", $voucher_id));
    if (!$v) return;
    gn_send_customer_invoice([
        'email'      => $v->buyer_email,
        'ten_khach'  => $v->buyer_name ?: 'Quý khách',
        'ma_don'     => $v->code,
        'dich_vu'    => 'Dùng voucher trừ vào hóa đơn'
                        . ((float) $left > 0 ? ' · số dư còn ' . gn_money($left) : ' · đã dùng hết'),
        'ngay'       => date('d/m/Y', current_time('timestamp')),
        'tong'       => gn_money($used),
        'ma_hoa_don' => gn_invoice_no('GNR', $v->id),
        'link'       => home_url('/voucher/?c=' . $v->code),
    ]);
}, 10, 3);

add_action('gn_booking_settled', function ($booking_id, $revenue) {
    global $wpdb;
    $b = $wpdb->get_row($wpdb->prepare("SELECT * FROM " . gn_tbl('bookings') . " WHERE id=%d", $booking_id));
    if (!$b) return;
    $dich_vu = 'Dùng bữa tại nhà hàng · ' . (int) $b->guests . ' khách';
    $ngay = date('d/m/Y', strtotime($b->served_on ?: current_time('Y-m-d')));
    gn_send_customer_invoice([
        'email'      => $b->customer_email,
        'ten_khach'  => $b->customer_name ?: 'Quý khách',
        'ma_don'     => $b->booking_code,
        'dich_vu'    => $dich_vu,
        'ngay'       => $ngay,
        'tong'       => gn_money($revenue),
        'ma_hoa_don' => gn_invoice_no('GNB', $b->id),
        'link'       => home_url('/dat-ban/?ma=' . rawurlencode($b->booking_code)),
    ]);
    gn_partner_notice_for($b->partner_id, $revenue, [
        'ma_don'    => $b->booking_code,
        'ten_khach' => $b->customer_name ?: 'Khách lẻ',
        'dich_vu'   => $dich_vu,
        'ngay'      => $ngay,
    ]);
}, 10, 2);

/* GN — HOÁ ĐƠN VÀ ĐỐI SOÁT END */

/* ==========================================================================
   GN — SỬA NỐT CÁC LỖI ĐO ĐƯỢC KHI SOI TỪNG TRANG
   ========================================================================== */

/**
 * Link tel: không nhất quán: nội dung trang dùng tel:0979232233, chân trang dùng
 * tel:+84979232233. Bản không có mã quốc gia hỏng với khách quốc tế — đúng nhóm
 * khách trang đối tác và trang đoàn nhắm tới. Chuẩn hoá hết về +84.
 */
function gn_normalize_tel_links($html) {
    if (!is_string($html) || strpos($html, 'tel:') === false) return $html;
    return preg_replace_callback(
        '/href=(["\'])tel:([^"\']+)\1/i',
        function ($m) {
            $d = preg_replace('/[^\d+]/', '', $m[2]);
            if (str_starts_with($d, '0'))      $d = '+84' . substr($d, 1);
            elseif (str_starts_with($d, '84')) $d = '+' . $d;
            return 'href=' . $m[1] . 'tel:' . $d . $m[1];
        },
        $html
    );
}
add_filter('the_content', 'gn_normalize_tel_links', 98);
add_filter('widget_text', 'gn_normalize_tel_links', 98);
add_filter('render_block', 'gn_normalize_tel_links', 98);

/**
 * <input type="date"> hiển thị theo locale TRÌNH DUYỆT của khách, HTML không ép
 * được. Máy đặt en-US sẽ thấy mm/dd/yyyy trên trang tiếng Việt — đo được trên
 * trang chủ, /dat-ban/ và /khach-doan-tiec-rieng/.
 *
 * Không thay bằng ô chữ tự viết vì sẽ mất bộ chọn ngày gốc của điện thoại, vốn
 * dùng tốt hơn hẳn. Thay vào đó hiện thêm dòng ngày dạng dd/mm/yyyy ngay dưới ô,
 * cập nhật theo lựa chọn, để khách không bao giờ hiểu nhầm tháng với ngày.
 * Đồng thời chặn chọn ngày quá khứ và giới hạn 12 tháng.
 */
function gn_date_input_helper() {
    if (is_admin()) return; ?>
<script>
(function () {
  function vn(d) {
    if (!d) return '';
    var p = d.split('-');
    return p.length === 3 ? p[2] + '/' + p[1] + '/' + p[0] : '';
  }
  function setup(inp) {
    if (inp.dataset.gnDate) return;
    inp.dataset.gnDate = '1';
    // Ghép ngày theo GIỜ ĐỊA PHƯƠNG, KHÔNG dùng toISOString — nó đổi sang UTC
    // nên nửa đêm giờ Việt Nam thành 17h hôm trước, min lùi một ngày, khách đặt
    // được bàn hôm qua. Nhà hàng lại mở tới 2 giờ sáng nên lỗi này rất dễ lọt.
    var iso = function (dt) {
      var m = dt.getMonth() + 1, d = dt.getDate();
      return dt.getFullYear() + '-' + (m < 10 ? '0' + m : m) + '-' + (d < 10 ? '0' + d : d);
    };
    var today = new Date();
    if (!inp.min) inp.min = iso(today);
    if (!inp.max) { var mx = new Date(today); mx.setFullYear(mx.getFullYear() + 1); inp.max = iso(mx); }

    var hint = document.createElement('small');
    hint.className = 'gn-date-hint';
    hint.style.cssText = 'display:block;margin-top:4px;font:500 12px/1.5 inherit;color:#6E5D4E';
    inp.insertAdjacentElement('afterend', hint);

    var show = function () {
      hint.textContent = inp.value
        ? 'Đã chọn: ' + vn(inp.value) + ' (ngày/tháng/năm)'
        : 'Định dạng ngày/tháng/năm';
      hint.style.color = inp.value ? '#1E7A4C' : '#6E5D4E';
    };
    inp.addEventListener('change', show);
    inp.addEventListener('input', show);
    show();
  }
  function scan() { document.querySelectorAll('input[type=date]').forEach(setup); }

  // ── Nút hamburger cho menu mobile ──
  // Theme ẩn .gn-nav ở <=860px mà không có nút thay thế. Bơm một nút ba gạch vào
  // header, bấm là bật/tắt class trên body để CSS xổ menu xuống.
  function nav() {
    var header = document.querySelector('.gn-header, header.gn-header') || document.querySelector('.gn-nav') && document.querySelector('.gn-nav').parentElement;
    var navEl = document.querySelector('.gn-nav');
    if (!navEl || document.querySelector('.gn-nav-toggle')) return;
    var host = navEl.parentElement || header;
    if (!host) return;
    var btn = document.createElement('button');
    btn.className = 'gn-nav-toggle';
    btn.setAttribute('aria-label', 'Mở menu');
    btn.setAttribute('aria-expanded', 'false');
    btn.innerHTML = '<span></span>';
    btn.addEventListener('click', function () {
      var open = document.body.classList.toggle('gn-nav-open');
      btn.setAttribute('aria-expanded', open ? 'true' : 'false');
      btn.setAttribute('aria-label', open ? 'Đóng menu' : 'Mở menu');
    });
    host.appendChild(btn);
    // bấm một mục là đóng lại
    navEl.addEventListener('click', function (e) {
      if (e.target.closest('a')) document.body.classList.remove('gn-nav-open');
    });
  }

  // ── Chặn submit form đặt bàn ──
  // Form /dat-ban/ và /doi-tac/ POST thẳng tới admin-ajax, bấm gửi là khách rơi
  // vào trang trắng in JSON trần. Chặn submit, fetch, hiện kết quả ngay trên trang.
  function bindForms() {
    var forms = document.querySelectorAll('form[action*="admin-ajax.php"]');
    forms.forEach(function (f) {
      if (f.dataset.gnAjax) return;
      f.dataset.gnAjax = '1';
      f.addEventListener('submit', function (e) {
        e.preventDefault();
        var btn = f.querySelector('[type=submit], button:not([type])');
        var oldTxt = btn ? btn.textContent : '';
        if (btn) { btn.disabled = true; btn.textContent = 'Đang gửi…'; }
        var box = f.querySelector('.gn-form-result');
        if (!box) {
          box = document.createElement('div');
          box.className = 'gn-form-result';
          box.style.cssText = 'margin-top:14px;padding:14px 16px;border-radius:12px;font:500 15px/1.5 inherit;display:none';
          f.appendChild(box);
        }
        fetch(f.action, { method: 'POST', credentials: 'include', body: new FormData(f) })
          .then(function (r) { return r.json().catch(function () { return { success: true }; }); })
          .then(function (j) {
            box.style.display = 'block';
            var ok = j && (j.success === true || (j.data && !j.data.message) || false);
            if (ok || (j && j.success)) {
              box.style.background = '#E4F2EA'; box.style.color = '#1E7A4C';
              box.textContent = (j.data && j.data.message) || 'Đã nhận yêu cầu. Nhân viên Gánh Ngon sẽ liên hệ xác nhận trong ít phút.';
              f.reset();
            } else {
              box.style.background = '#FBE9E7'; box.style.color = '#B42318';
              box.textContent = (j && j.data && j.data.message) || 'Có lỗi, vui lòng gọi 0979 232 233 giúp.';
            }
            if (btn) { btn.disabled = false; btn.textContent = oldTxt; }
            box.scrollIntoView({ behavior: 'smooth', block: 'center' });
          })
          .catch(function () {
            box.style.display = 'block'; box.style.background = '#FBE9E7'; box.style.color = '#B42318';
            box.textContent = 'Mạng trục trặc, thử lại hoặc gọi 0979 232 233.';
            if (btn) { btn.disabled = false; btn.textContent = oldTxt; }
          });
      });
    });
  }

  function all() { scan(); nav(); bindForms(); }
  if (document.readyState === 'loading') document.addEventListener('DOMContentLoaded', all);
  else all();
  new MutationObserver(all).observe(document.documentElement, { childList: true, subtree: true });
})();
</script>
<?php }
add_action('wp_footer', 'gn_date_input_helper', 30);

/* GN — SỬA NỐT LỖI END */

/* ===== KẾT NỐI WCC — MCP SERVER (nối vào functions.php) ===== */

/**
 * Token MCP đang dùng. Ưu tiên hằng số trong wp-config.php (không đi vào database,
 * an toàn nhất); nếu không có thì lấy token do nút "Bật kết nối" sinh ra và lưu
 * trong option. Nhờ vậy chủ nhà hàng chỉ cần bấm một nút, không phải sửa file.
 */
function gn_wcc_token() {
    if (defined('GN_MCP_TOKEN') && GN_MCP_TOKEN !== '') return (string) GN_MCP_TOKEN;
    return (string) get_option('gn_wcc_token', '');
}

const GN_MCP_NS       = 'gn-mcp/v1';
const GN_MCP_PROTO    = '2024-11-05';
const GN_MCP_TZ       = 'Asia/Ho_Chi_Minh';
const GN_MCP_IDEM_TTL = 7 * DAY_IN_SECONDS;

/* ═══════════════════════════════════════════════════════════════════════════
   TIỆN ÍCH
   ═══════════════════════════════════════════════════════════════════════════ */

/** Ngày hôm nay theo giờ Việt Nam, không phụ thuộc múi giờ máy chủ. */
function gn_mcp_today() {
    return (new DateTime('now', new DateTimeZone(GN_MCP_TZ)))->format('Y-m-d');
}

/** Ép về số nguyên đồng. Mọi số tiền ra khỏi tệp này đều đi qua đây. */
function gn_mcp_vnd($n) { return (int) round((float) $n); }

/** Chuẩn hoá ngày người gọi đưa vào; rỗng thì lấy hôm nay. */
function gn_mcp_ngay($s, $mac_dinh = null) {
    $s = trim((string) $s);
    if ($s === '') { return $mac_dinh ?: gn_mcp_today(); }
    $d = DateTime::createFromFormat('Y-m-d', $s, new DateTimeZone(GN_MCP_TZ));
    return ($d && $d->format('Y-m-d') === $s) ? $s : ($mac_dinh ?: gn_mcp_today());
}

function gn_mcp_tbl($ten) {
    if (function_exists('gn_tbl')) { return gn_tbl($ten); }
    global $wpdb;
    return $wpdb->prefix . 'sao_' . $ten;   // dự phòng khi theme chưa nạp
}

/** Theme đã nạp đủ hàm nghiệp vụ chưa. */
function gn_mcp_san_sang() {
    return function_exists('gn_commission_for_day')
        && function_exists('gn_partner_period')
        && function_exists('gn_tbl');
}

/**
 * Chống gọi trùng. Khách bấm hai lần, mạng chập chờn, WCC gửi lại — đều tạo bản
 * ghi trùng nếu không chặn. Lưu kết quả theo khoá, gọi lại trả nguyên kết quả cũ.
 */
function gn_mcp_idem_doc($key) {
    if ($key === '') { return null; }
    $v = get_transient('gn_mcp_idem_' . md5($key));
    return is_array($v) ? $v : null;
}
function gn_mcp_idem_ghi($key, $ket_qua) {
    if ($key === '') { return $ket_qua; }
    set_transient('gn_mcp_idem_' . md5($key), $ket_qua, GN_MCP_IDEM_TTL);
    return $ket_qua;
}

/* ═══════════════════════════════════════════════════════════════════════════
   ĐỊNH NGHĨA TOOL
   Ba nhóm theo mức rủi ro. Người vận hành WCC gán risk_level khi dò lần đầu:
     đọc     -> risk 0, AI gọi thẳng
     ghi nhẹ -> risk 1, nhắc rồi chạy
     tiền    -> để NULL hoặc L3, BẮT BUỘC người duyệt
   ═══════════════════════════════════════════════════════════════════════════ */

function gn_mcp_tools() {
    $ngay = ['type' => 'string', 'description' => 'Ngày YYYY-MM-DD theo giờ Việt Nam. Bỏ trống là hôm nay.'];
    $idem = ['type' => 'string', 'description' => 'Khoá chống gọi trùng. BẮT BUỘC. Gọi lại cùng khoá trả kết quả cũ, không làm lại.'];

    return [
        /* ── ĐỌC ───────────────────────────────────────────────────────── */
        [
            'name' => 'gn_doanh_thu',
            'description' => 'Doanh thu nhà hàng trong khoảng ngày, tách riêng khách tự đặt và khách qua đối tác. Chỉ tính đơn khách ĐÃ ĐẾN và đã thanh toán. Số tiền là số nguyên đồng.',
            'inputSchema' => ['type' => 'object', 'properties' => [
                'tu_ngay' => $ngay, 'den_ngay' => $ngay,
            ]],
        ],
        [
            'name' => 'gn_don_dat_ban',
            'description' => 'Danh sách đơn đặt bàn, lọc theo ngày, trạng thái hoặc mã đối tác.',
            'inputSchema' => ['type' => 'object', 'properties' => [
                'tu_ngay' => $ngay, 'den_ngay' => $ngay,
                'trang_thai' => ['type' => 'string', 'description' => 'pending | served | cancelled. Bỏ trống là tất cả.'],
                'ma_doi_tac' => ['type' => 'string', 'description' => 'Ví dụ GN-P042. Bỏ trống là tất cả.'],
                'gioi_han' => ['type' => 'integer', 'description' => 'Tối đa 200, mặc định 50.'],
            ]],
        ],
        [
            'name' => 'gn_don_cho_chot',
            'description' => 'Đơn đã qua ngày phục vụ nhưng chưa chốt doanh số. Chưa chốt thì hoa hồng đối tác vẫn bằng 0 — dùng danh sách này để nhắc nhân viên.',
            'inputSchema' => ['type' => 'object', 'properties' => [
                'gioi_han' => ['type' => 'integer', 'description' => 'Tối đa 200, mặc định 50.'],
            ]],
        ],
        [
            'name' => 'gn_doi_tac',
            'description' => 'Danh sách đối tác kèm doanh số kỳ và hoa hồng phải trả.',
            'inputSchema' => ['type' => 'object', 'properties' => [
                'trang_thai' => ['type' => 'string', 'description' => 'pending | active | paused. Bỏ trống là tất cả.'],
                'ky' => ['type' => 'string', 'description' => 'Kỳ YYYY-MM. Bỏ trống là tháng này.'],
            ]],
        ],
        [
            'name' => 'gn_hoa_hong_ky',
            'description' => 'Chi tiết hoa hồng một kỳ của một đối tác, có bảng doanh số từng ngày và thưởng 2% nếu tháng đạt 100 triệu.',
            'inputSchema' => ['type' => 'object', 'required' => ['ma_doi_tac'], 'properties' => [
                'ma_doi_tac' => ['type' => 'string', 'description' => 'Ví dụ GN-P042.'],
                'ky' => ['type' => 'string', 'description' => 'Kỳ YYYY-MM. Bỏ trống là tháng này.'],
            ]],
        ],
        [
            'name' => 'gn_tinh_hoa_hong',
            'description' => 'Máy tính hoa hồng thuần, không đụng dữ liệu. Đưa doanh số một ngày, trả về ba bậc luỹ tiến (0-5tr 10%, 5-10tr 12%, trên 10tr 15%) và tổng tiền. Đây là máy tính DUY NHẤT — WCC không được tự tính lại.',
            'inputSchema' => ['type' => 'object', 'required' => ['doanh_so'], 'properties' => [
                'doanh_so' => ['type' => 'integer', 'description' => 'Doanh số một ngày, số nguyên đồng.'],
            ]],
        ],
        [
            'name' => 'gn_voucher',
            'description' => 'Tra cứu một voucher: trạng thái, mệnh giá, số dư, người mua, đối tác giới thiệu, và lịch sử giao dịch.',
            'inputSchema' => ['type' => 'object', 'required' => ['ma'], 'properties' => [
                'ma' => ['type' => 'string', 'description' => 'Ví dụ GN-V-4K7P-92XM.'],
            ]],
        ],
        [
            'name' => 'gn_voucher_ton',
            'description' => 'Tổng voucher đang lưu hành (nợ phải trả, KHÔNG phải doanh thu) và voucher giữ chỗ khách chưa trả tiền.',
            'inputSchema' => ['type' => 'object', 'properties' => []],
        ],
        [
            'name' => 'gn_luot_quet',
            'description' => 'Lượt quét mã QR theo đối tác và theo vật phẩm in (standee, thẻ bỏ túi, poster, sticker, QR số). Dùng để biết vật phẩm nào ra khách.',
            'inputSchema' => ['type' => 'object', 'properties' => [
                'tu_ngay' => $ngay, 'den_ngay' => $ngay,
                'ma_doi_tac' => ['type' => 'string'],
            ]],
        ],

        /* ── GHI NHẸ ───────────────────────────────────────────────────── */
        [
            'name' => 'gn_tao_doi_tac',
            'description' => 'GHI DỮ LIỆU. Tạo hồ sơ đối tác mới ở trạng thái active, sinh mã GN-Pxxx và token cổng theo dõi.',
            'inputSchema' => ['type' => 'object', 'required' => ['ten', 'dien_thoai', 'idempotency_key'], 'properties' => [
                'ten' => ['type' => 'string'],
                'dien_thoai' => ['type' => 'string'],
                'email' => ['type' => 'string'],
                'loai' => ['type' => 'string', 'description' => 'huong-dan-vien | cong-ty-du-lich | khach-san | tai-xe | kol | hiep-hoi | khac'],
                'khu_vuc' => ['type' => 'string'],
                'idempotency_key' => $idem,
            ]],
        ],
        [
            'name' => 'gn_duyet_doi_tac',
            'description' => 'GHI DỮ LIỆU. Chuyển đối tác từ pending sang active. Chưa duyệt thì mã QR của họ không gán được đơn.',
            'inputSchema' => ['type' => 'object', 'required' => ['ma_doi_tac', 'idempotency_key'], 'properties' => [
                'ma_doi_tac' => ['type' => 'string'],
                'idempotency_key' => $idem,
            ]],
        ],
        [
            'name' => 'gn_gui_lai_link_cong',
            'description' => 'GHI DỮ LIỆU. Gửi lại email chứa link cổng theo dõi doanh số cho đối tác. Gửi email thật, không rút lại được.',
            'inputSchema' => ['type' => 'object', 'required' => ['ma_doi_tac', 'idempotency_key'], 'properties' => [
                'ma_doi_tac' => ['type' => 'string'],
                'cap_token_moi' => ['type' => 'boolean', 'description' => 'true thì cấp token mới, link cũ hết hiệu lực ngay.'],
                'idempotency_key' => $idem,
            ]],
        ],

        /* ── ĐỤNG TIỀN — để risk_level NULL hoặc L3, BẮT BUỘC người duyệt ── */
        [
            'name' => 'gn_chot_doanh_so',
            'description' => 'ĐỤNG TIỀN — CẦN NGƯỜI DUYỆT. Ghi doanh số thực thu cho một đơn sau khi khách ăn xong. Quyết định hoa hồng phải trả cho đối tác. Nhập số tiền khách THỰC TRẢ sau giảm giá, không phải giá niêm yết.',
            'inputSchema' => ['type' => 'object', 'required' => ['ma_don', 'doanh_so', 'idempotency_key'], 'properties' => [
                'ma_don' => ['type' => 'string'],
                'doanh_so' => ['type' => 'integer', 'description' => 'Số nguyên đồng.'],
                'idempotency_key' => $idem,
            ]],
        ],
        [
            'name' => 'gn_thu_tien_voucher',
            'description' => 'ĐỤNG TIỀN — CẦN NGƯỜI DUYỆT. Đánh dấu voucher giữ chỗ đã thanh toán, nạp số dư thật và ghi doanh số cho đối tác giới thiệu. Không thu hồi được.',
            'inputSchema' => ['type' => 'object', 'required' => ['ma', 'idempotency_key'], 'properties' => [
                'ma' => ['type' => 'string'],
                'idempotency_key' => $idem,
            ]],
        ],
        [
            'name' => 'gn_tru_voucher',
            'description' => 'ĐỤNG TIỀN — CẦN NGƯỜI DUYỆT. Trừ tiền từ số dư voucher vào hoá đơn. Tiêu tiền của khách.',
            'inputSchema' => ['type' => 'object', 'required' => ['ma', 'so_tien', 'idempotency_key'], 'properties' => [
                'ma' => ['type' => 'string'],
                'so_tien' => ['type' => 'integer', 'description' => 'Số nguyên đồng, phải lớn hơn 0.'],
                'idempotency_key' => $idem,
            ]],
        ],
        [
            'name' => 'gn_tam_dung_doi_tac',
            'description' => 'ĐỤNG TIỀN — CẦN NGƯỜI DUYỆT. Tạm dừng đối tác. Mã QR đã in và phát ra ngoài đời sẽ ngừng gán đơn ngay lập tức.',
            'inputSchema' => ['type' => 'object', 'required' => ['ma_doi_tac', 'idempotency_key'], 'properties' => [
                'ma_doi_tac' => ['type' => 'string'],
                'idempotency_key' => $idem,
            ]],
        ],
    ];
}

/* ═══════════════════════════════════════════════════════════════════════════
   THỰC THI TOOL
   ═══════════════════════════════════════════════════════════════════════════ */

function gn_mcp_goi_tool($ten, $args) {
    global $wpdb;
    if (!gn_mcp_san_sang()) {
        return ['loi' => 'Theme ganhngon-restaurant chưa nạp lớp thương mại. Kiểm tra functions.php.'];
    }
    $args = is_array($args) ? $args : [];
    $tz   = GN_MCP_TZ;
    $B = gn_mcp_tbl('bookings'); $P = gn_mcp_tbl('partners');
    $V = gn_mcp_tbl('vouchers'); $X = gn_mcp_tbl('voucher_txn'); $S = gn_mcp_tbl('scans');
    $DA_DEN = "('served','checked_in','completed')";

    switch ($ten) {

    /* ── ĐỌC ── */
    case 'gn_doanh_thu': {
        $tu  = gn_mcp_ngay($args['tu_ngay'] ?? '');
        $den = gn_mcp_ngay($args['den_ngay'] ?? '', $tu);
        $r = $wpdb->get_row($wpdb->prepare(
            "SELECT COALESCE(SUM(revenue),0) tong,
                    COALESCE(SUM(CASE WHEN partner_id IS NOT NULL THEN revenue END),0) qua_doi_tac,
                    COUNT(*) so_don
             FROM {$B} WHERE served_on BETWEEN %s AND %s AND booking_status IN {$DA_DEN}", $tu, $den));
        $vou = gn_mcp_vnd($wpdb->get_var($wpdb->prepare(
            "SELECT COALESCE(SUM(amount),0) FROM {$X}
             WHERE happened_on BETWEEN %s AND %s AND kind IN ('pay','topup')", $tu, $den)));
        $tong = gn_mcp_vnd($r->tong); $dt = gn_mcp_vnd($r->qua_doi_tac);
        return [
            'tu_ngay' => $tu, 'den_ngay' => $den, 'tz' => $tz,
            'doanh_thu_dat_ban' => $tong,
            'khach_tu_dat' => $tong - $dt,
            'qua_doi_tac' => $dt,
            'voucher_khach_tra' => $vou,
            'so_don' => (int) $r->so_don,
            'ghi_chu' => 'Chỉ tính đơn khách đã đến và đã thanh toán. Voucher tính vào ngày khách trả tiền.',
        ];
    }

    case 'gn_don_dat_ban': {
        $tu  = gn_mcp_ngay($args['tu_ngay'] ?? '');
        $den = gn_mcp_ngay($args['den_ngay'] ?? '', $tu);
        $gh  = min(200, max(1, (int) ($args['gioi_han'] ?? 50)));
        $sql = "SELECT booking_code, booking_date, customer_name, customer_phone, guests,
                       guest_type, booking_status, ref_code, revenue, served_on
                FROM {$B} WHERE booking_date BETWEEN %s AND %s";
        $p = [$tu, $den];
        if (!empty($args['trang_thai'])) { $sql .= " AND booking_status = %s"; $p[] = sanitize_text_field($args['trang_thai']); }
        if (!empty($args['ma_doi_tac'])) { $sql .= " AND ref_code = %s"; $p[] = strtoupper(sanitize_text_field($args['ma_doi_tac'])); }
        $sql .= " ORDER BY booking_date DESC, id DESC LIMIT " . $gh;
        $rows = $wpdb->get_results($wpdb->prepare($sql, $p));
        return ['tz' => $tz, 'so_dong' => count($rows), 'don' => array_map(function ($b) {
            return [
                'ma_don' => $b->booking_code, 'ngay' => $b->booking_date,
                'khach' => $b->customer_name, 'dien_thoai' => $b->customer_phone,
                'so_khach' => (int) $b->guests, 'cho_ngoi' => $b->guest_type,
                'trang_thai' => $b->booking_status,
                'ma_doi_tac' => $b->ref_code ?: null,
                'doanh_so' => gn_mcp_vnd($b->revenue),
                'ngay_phuc_vu' => $b->served_on,
            ];
        }, $rows)];
    }

    case 'gn_don_cho_chot': {
        $gh = min(200, max(1, (int) ($args['gioi_han'] ?? 50)));
        $rows = $wpdb->get_results(
            "SELECT booking_code, booking_date, customer_name, customer_phone, guests, ref_code
             FROM {$B}
             WHERE (revenue IS NULL OR revenue = 0)
               AND booking_status NOT IN ('cancelled','no_show')
             ORDER BY booking_date ASC, id ASC LIMIT " . $gh);
        return [
            'tz' => $tz, 'so_dong' => count($rows),
            'ghi_chu' => 'Chưa chốt doanh số thì hoa hồng đối tác vẫn bằng 0.',
            'don' => array_map(function ($b) {
                return ['ma_don' => $b->booking_code, 'ngay' => $b->booking_date,
                        'khach' => $b->customer_name, 'dien_thoai' => $b->customer_phone,
                        'so_khach' => (int) $b->guests, 'ma_doi_tac' => $b->ref_code ?: null];
            }, $rows),
        ];
    }

    case 'gn_doi_tac': {
        $ky = preg_match('/^\d{4}-\d{2}$/', (string) ($args['ky'] ?? '')) ? $args['ky'] : substr(gn_mcp_today(), 0, 7);
        $sql = "SELECT * FROM {$P}";
        $p = [];
        if (!empty($args['trang_thai'])) { $sql .= " WHERE status = %s"; $p[] = sanitize_text_field($args['trang_thai']); }
        $sql .= " ORDER BY id DESC";
        $rows = $p ? $wpdb->get_results($wpdb->prepare($sql, $p)) : $wpdb->get_results($sql);
        $out = [];
        foreach ($rows as $r) {
            $k = gn_partner_period($r->id, $ky);
            $out[] = [
                'ma' => $r->ref_code, 'ten' => $r->contact ?: $r->company,
                'loai' => $r->type, 'khu_vuc' => $r->area, 'trang_thai' => $r->status,
                'doanh_so_ky' => gn_mcp_vnd($k['doanh_so']),
                'hoa_hong' => gn_mcp_vnd($k['hoa_hong']),
                'thuong_2pt' => gn_mcp_vnd($k['thuong_2pt']),
                'phai_tra' => gn_mcp_vnd($k['phai_tra']),
                'dat_moc_thuong' => (bool) $k['dat_moc_thuong'],
            ];
        }
        return ['ky' => $ky, 'tz' => $tz, 'so_doi_tac' => count($out), 'doi_tac' => $out];
    }

    case 'gn_hoa_hong_ky': {
        $ma = strtoupper(sanitize_text_field($args['ma_doi_tac'] ?? ''));
        $ky = preg_match('/^\d{4}-\d{2}$/', (string) ($args['ky'] ?? '')) ? $args['ky'] : substr(gn_mcp_today(), 0, 7);
        $r = $wpdb->get_row($wpdb->prepare("SELECT * FROM {$P} WHERE ref_code = %s", $ma));
        if (!$r) { return ['loi' => 'Không tìm thấy đối tác ' . $ma]; }
        $k = gn_partner_period($r->id, $ky);
        return [
            'ma' => $r->ref_code, 'ten' => $r->contact ?: $r->company, 'ky' => $ky, 'tz' => $tz,
            'doanh_so' => gn_mcp_vnd($k['doanh_so']),
            'hoa_hong_luy_tien' => gn_mcp_vnd($k['hoa_hong']),
            'thuong_2pt' => gn_mcp_vnd($k['thuong_2pt']),
            'dat_moc_thuong' => (bool) $k['dat_moc_thuong'],
            'con_thieu_de_dat_thuong' => gn_mcp_vnd($k['con_thieu']),
            'phai_tra' => gn_mcp_vnd($k['phai_tra']),
            'ty_le_thuc_phan_tram' => $k['ty_le_thuc'],
            'so_ngay_co_doanh_so' => (int) $k['so_ngay'],
            'theo_ngay' => array_map(function ($d) {
                return ['ngay' => $d['ngay'], 'doanh_so' => gn_mcp_vnd($d['doanh_so']), 'hoa_hong' => gn_mcp_vnd($d['hoa_hong'])];
            }, $k['theo_ngay']),
        ];
    }

    case 'gn_tinh_hoa_hong': {
        $ds = gn_mcp_vnd($args['doanh_so'] ?? 0);
        $bac = gn_commission_breakdown($ds);
        $hh = gn_mcp_vnd(gn_commission_for_day($ds));
        return [
            'doanh_so' => $ds, 'hoa_hong' => $hh,
            'ty_le_thuc_phan_tram' => $ds > 0 ? round($hh / $ds * 100, 2) : 0,
            'cac_bac' => array_map(function ($b) {
                return ['tu' => gn_mcp_vnd($b['tu']), 'den' => $b['den'] === null ? null : gn_mcp_vnd($b['den']),
                        'ty_le' => $b['ty_le'], 'doanh_so' => gn_mcp_vnd($b['doanh_so']), 'hoa_hong' => gn_mcp_vnd($b['hoa_hong'])];
            }, $bac),
            'ghi_chu' => 'Đây là máy tính duy nhất. WCC không được tự tính lại theo công thức khác.',
        ];
    }

    case 'gn_voucher': {
        $ma = strtoupper(sanitize_text_field($args['ma'] ?? ''));
        $v = $wpdb->get_row($wpdb->prepare("SELECT * FROM {$V} WHERE code = %s", $ma));
        if (!$v) { return ['loi' => 'Không tìm thấy voucher ' . $ma]; }
        $txn = $wpdb->get_results($wpdb->prepare("SELECT kind, amount, happened_on, note FROM {$X} WHERE voucher_id = %d ORDER BY id", $v->id));
        return [
            'ma' => $v->code, 'trang_thai' => $v->status, 'tz' => $tz,
            'menh_gia' => gn_mcp_vnd($v->face_value),
            'gia_ban' => gn_mcp_vnd($v->price),
            'so_du' => gn_mcp_vnd($v->balance),
            'nguoi_mua' => $v->buyer_name,
            'ma_doi_tac' => $v->ref_code ?: null,
            'giu_den' => $v->hold_until, 'han_dung' => $v->expires_on, 'ngay_tra_tien' => $v->paid_on,
            'giao_dich' => array_map(function ($t) {
                return ['loai' => $t->kind, 'so_tien' => gn_mcp_vnd($t->amount), 'ngay' => $t->happened_on, 'ghi_chu' => $t->note];
            }, $txn),
        ];
    }

    case 'gn_voucher_ton': {
        return [
            'tz' => $tz,
            'luu_hanh' => gn_mcp_vnd($wpdb->get_var("SELECT COALESCE(SUM(balance),0) FROM {$V} WHERE status = 'paid'")),
            'giu_cho_chua_tra' => gn_mcp_vnd($wpdb->get_var("SELECT COALESCE(SUM(price),0) FROM {$V} WHERE status = 'unpaid'")),
            'ghi_chu' => 'Voucher lưu hành là NỢ PHẢI TRẢ, không phải doanh thu. Ghi thành doanh thu vào ngày khách dùng.',
        ];
    }

    case 'gn_luot_quet': {
        $tu  = gn_mcp_ngay($args['tu_ngay'] ?? '');
        $den = gn_mcp_ngay($args['den_ngay'] ?? '', $tu);
        $sql = "SELECT p.ref_code, s.medium, s.target, COUNT(*) so_luot
                FROM {$S} s JOIN {$P} p ON p.id = s.partner_id
                WHERE s.scanned_on BETWEEN %s AND %s";
        $pr = [$tu, $den];
        if (!empty($args['ma_doi_tac'])) { $sql .= " AND p.ref_code = %s"; $pr[] = strtoupper(sanitize_text_field($args['ma_doi_tac'])); }
        $sql .= " GROUP BY p.ref_code, s.medium, s.target ORDER BY so_luot DESC LIMIT 200";
        $rows = $wpdb->get_results($wpdb->prepare($sql, $pr));
        return ['tu_ngay' => $tu, 'den_ngay' => $den, 'tz' => $tz,
                'luot_quet' => array_map(function ($r) {
                    return ['ma_doi_tac' => $r->ref_code, 'vat_pham' => $r->medium,
                            'dich' => $r->target, 'so_luot' => (int) $r->so_luot];
                }, $rows)];
    }

    /* ── GHI NHẸ ── */
    case 'gn_tao_doi_tac': {
        $key = (string) ($args['idempotency_key'] ?? '');
        if ($key === '') { return ['loi' => 'Thiếu idempotency_key']; }
        $cu = gn_mcp_idem_doc($key); if ($cu) { return $cu + ['tu_bo_nho_chong_trung' => true]; }

        $ten = sanitize_text_field($args['ten'] ?? '');
        $dt  = sanitize_text_field($args['dien_thoai'] ?? '');
        if ($ten === '' || $dt === '') { return ['loi' => 'Thiếu tên hoặc số điện thoại']; }
        if ($wpdb->get_var($wpdb->prepare("SELECT id FROM {$P} WHERE phone = %s", $dt))) {
            return ['loi' => 'Số điện thoại này đã có đối tác'];
        }
        $max = (int) $wpdb->get_var("SELECT COALESCE(MAX(CAST(SUBSTRING(ref_code, 5) AS UNSIGNED)),0) FROM {$P} WHERE ref_code REGEXP '^GN-P[0-9]+$'");
        $ref = gn_format_ref_code($max + 1);
        $tok = wp_generate_password(32, false, false);
        $type = sanitize_text_field($args['loai'] ?? 'khac');
        gn_ensure_columns($P, gn_partner_role_column_sql());
        $hand = [
            'company' => $ten, 'contact' => $ten,
            'email' => sanitize_email($args['email'] ?? ''), 'phone' => $dt,
            'type' => $type,
            'ref_code' => $ref, 'status' => 'active', 'portal_token' => $tok,
            'area' => sanitize_text_field($args['khu_vuc'] ?? ''),
        ];
        if (gn_column_exists($P, 'role')) $hand['role'] = gn_normalize_partner_role($type);
        $wpdb->insert($P, $hand);
        if (!$wpdb->insert_id) { return ['loi' => 'Không lưu được hồ sơ']; }
        $share = gn_partner_share_paths($ref);
        return gn_mcp_idem_ghi($key, [
            'ma' => $ref, 'trang_thai' => 'active',
            'link_qr' => home_url($share['table']),
            'link_qr_mon' => home_url($share['signature']),
            'link_cong' => home_url('/cong-doi-tac/?t=' . $tok),
        ]);
    }

    case 'gn_duyet_doi_tac': {
        $key = (string) ($args['idempotency_key'] ?? '');
        if ($key === '') { return ['loi' => 'Thiếu idempotency_key']; }
        $cu = gn_mcp_idem_doc($key); if ($cu) { return $cu + ['tu_bo_nho_chong_trung' => true]; }
        $ma = strtoupper(sanitize_text_field($args['ma_doi_tac'] ?? ''));
        $n = $wpdb->update($P, ['status' => 'active'], ['ref_code' => $ma]);
        if ($n === false || $n === 0) { return ['loi' => 'Không tìm thấy đối tác ' . $ma . ' hoặc đã active']; }
        return gn_mcp_idem_ghi($key, ['ma' => $ma, 'trang_thai' => 'active']);
    }

    case 'gn_gui_lai_link_cong': {
        $key = (string) ($args['idempotency_key'] ?? '');
        if ($key === '') { return ['loi' => 'Thiếu idempotency_key']; }
        $cu = gn_mcp_idem_doc($key); if ($cu) { return $cu + ['tu_bo_nho_chong_trung' => true]; }
        $ma = strtoupper(sanitize_text_field($args['ma_doi_tac'] ?? ''));
        $r = $wpdb->get_row($wpdb->prepare("SELECT * FROM {$P} WHERE ref_code = %s", $ma));
        if (!$r) { return ['loi' => 'Không tìm thấy đối tác ' . $ma]; }
        if (!$r->email) { return ['loi' => 'Đối tác ' . $ma . ' chưa có email']; }
        $tok = $r->portal_token;
        if (!empty($args['cap_token_moi']) || !$tok) {
            $tok = wp_generate_password(32, false, false);
            $wpdb->update($P, ['portal_token' => $tok], ['id' => $r->id]);
        }
        $link = home_url('/cong-doi-tac/?t=' . $tok);
        @wp_mail($r->email, 'Link cổng theo dõi doanh số — ' . $ma,
            "Chào " . ($r->contact ?: $r->company) . ",\n\nLink cổng theo dõi doanh số riêng của bạn:\n$link\n\n"
          . "Giữ link này riêng — ai có link là xem được số liệu của bạn.\n\n— Gánh Ngon Phú Quốc",
            ['Content-Type: text/plain; charset=UTF-8']);
        return gn_mcp_idem_ghi($key, ['ma' => $ma, 'da_gui_toi' => $r->email, 'token_moi' => !empty($args['cap_token_moi'])]);
    }

    /* ── ĐỤNG TIỀN ── */
    case 'gn_chot_doanh_so': {
        $key = (string) ($args['idempotency_key'] ?? '');
        if ($key === '') { return ['loi' => 'Thiếu idempotency_key']; }
        $cu = gn_mcp_idem_doc($key); if ($cu) { return $cu + ['tu_bo_nho_chong_trung' => true]; }
        $ma = sanitize_text_field($args['ma_don'] ?? '');
        $ds = gn_mcp_vnd($args['doanh_so'] ?? 0);
        if ($ds < 0) { return ['loi' => 'Doanh số không được âm']; }
        $b = $wpdb->get_row($wpdb->prepare("SELECT * FROM {$B} WHERE booking_code = %s", $ma));
        if (!$b) { return ['loi' => 'Không tìm thấy đơn ' . $ma]; }
        $hom_nay = gn_mcp_today();
        $wpdb->update($B, ['revenue' => $ds, 'served_on' => $hom_nay,
                           'booking_status' => 'served', 'payment_status' => 'paid'], ['id' => $b->id]);
        $ngay_dt = 0; $hh = 0;
        if ($b->partner_id) {
            $ngay_dt = gn_mcp_vnd($wpdb->get_var($wpdb->prepare(
                "SELECT COALESCE(SUM(revenue),0) FROM {$B}
                 WHERE partner_id = %d AND served_on = %s AND booking_status IN {$DA_DEN}",
                $b->partner_id, $hom_nay)));
            $hh = gn_mcp_vnd(gn_commission_for_day($ngay_dt));
        }
        return gn_mcp_idem_ghi($key, [
            'ma_don' => $ma, 'doanh_so_don' => $ds, 'ngay_phuc_vu' => $hom_nay, 'tz' => $tz,
            'ma_doi_tac' => $b->ref_code ?: null,
            'doanh_so_ngay_cua_doi_tac' => $ngay_dt,
            'hoa_hong_ngay_cua_doi_tac' => $hh,
        ]);
    }

    case 'gn_thu_tien_voucher': {
        $key = (string) ($args['idempotency_key'] ?? '');
        if ($key === '') { return ['loi' => 'Thiếu idempotency_key']; }
        $cu = gn_mcp_idem_doc($key); if ($cu) { return $cu + ['tu_bo_nho_chong_trung' => true]; }
        $ma = strtoupper(sanitize_text_field($args['ma'] ?? ''));
        $v = $wpdb->get_row($wpdb->prepare("SELECT id, price FROM {$V} WHERE code = %s", $ma));
        if (!$v) { return ['loi' => 'Không tìm thấy voucher ' . $ma]; }
        if (!function_exists('gn_voucher_mark_paid')) { return ['loi' => 'Theme chưa nạp gn_voucher_mark_paid']; }
        if (!gn_voucher_mark_paid($v->id)) { return ['loi' => 'Voucher không ở trạng thái chờ thanh toán']; }
        return gn_mcp_idem_ghi($key, ['ma' => $ma, 'da_thu' => gn_mcp_vnd($v->price), 'trang_thai' => 'paid', 'tz' => $tz]);
    }

    case 'gn_tru_voucher': {
        $key = (string) ($args['idempotency_key'] ?? '');
        if ($key === '') { return ['loi' => 'Thiếu idempotency_key']; }
        $cu = gn_mcp_idem_doc($key); if ($cu) { return $cu + ['tu_bo_nho_chong_trung' => true]; }
        if (!function_exists('gn_voucher_redeem')) { return ['loi' => 'Theme chưa nạp gn_voucher_redeem']; }
        $r = gn_voucher_redeem(strtoupper(sanitize_text_field($args['ma'] ?? '')), gn_mcp_vnd($args['so_tien'] ?? 0));
        if (empty($r['ok'])) { return ['loi' => $r['msg'] ?? 'Không trừ được']; }
        return gn_mcp_idem_ghi($key, ['da_dung' => gn_mcp_vnd($r['da_dung']), 'con_lai' => gn_mcp_vnd($r['con_lai']), 'tz' => $tz]);
    }

    case 'gn_tam_dung_doi_tac': {
        $key = (string) ($args['idempotency_key'] ?? '');
        if ($key === '') { return ['loi' => 'Thiếu idempotency_key']; }
        $cu = gn_mcp_idem_doc($key); if ($cu) { return $cu + ['tu_bo_nho_chong_trung' => true]; }
        $ma = strtoupper(sanitize_text_field($args['ma_doi_tac'] ?? ''));
        $n = $wpdb->update($P, ['status' => 'paused'], ['ref_code' => $ma]);
        if ($n === false || $n === 0) { return ['loi' => 'Không tìm thấy đối tác ' . $ma . ' hoặc đã tạm dừng']; }
        return gn_mcp_idem_ghi($key, ['ma' => $ma, 'trang_thai' => 'paused',
            'canh_bao' => 'Mã QR đã in và phát ra ngoài đời ngừng gán đơn ngay lập tức.']);
    }

    }
    return ['loi' => 'Không có tool tên ' . $ten];
}

/* ═══════════════════════════════════════════════════════════════════════════
   GIAO THỨC MCP — JSON-RPC 2.0 qua HTTP POST
   ═══════════════════════════════════════════════════════════════════════════ */

function gn_mcp_ket_qua($id, $result) {
    return ['jsonrpc' => '2.0', 'id' => $id, 'result' => $result];
}
function gn_mcp_loi($id, $code, $message) {
    return ['jsonrpc' => '2.0', 'id' => $id, 'error' => ['code' => $code, 'message' => $message]];
}

add_action('rest_api_init', function () {
    register_rest_route(GN_MCP_NS, '/rpc', [
        'methods'  => 'POST',
        'callback' => 'gn_mcp_xu_ly',
        // Token trong header Authorization. WCC lưu ở McpServer.headers (đã mã hoá).
        'permission_callback' => function (WP_REST_Request $req) {
            $token = gn_wcc_token();
            if ($token === '') {
                return new WP_Error('gn_mcp_chua_bat', 'Kết nối WCC chưa bật. Vào wp-admin → Gánh Ngon → Kết nối WCC → Bật.', ['status' => 503]);
            }
            $h = (string) $req->get_header('authorization');
            if (stripos($h, 'Bearer ') !== 0) {
                return new WP_Error('gn_mcp_thieu_token', 'Thiếu header Authorization: Bearer', ['status' => 401]);
            }
            // hash_equals: so sánh thời gian cố định, không để lộ token qua kênh thời gian
            if (!hash_equals($token, trim(substr($h, 7)))) {
                return new WP_Error('gn_mcp_token_sai', 'Token không đúng', ['status' => 401]);
            }
            return true;
        },
    ]);
});

function gn_mcp_xu_ly(WP_REST_Request $req) {
    $body = $req->get_json_params();
    if (!is_array($body)) { return new WP_REST_Response(gn_mcp_loi(null, -32700, 'JSON hỏng'), 200); }

    // Hỗ trợ gọi theo lô: WCC có thể gửi mảng nhiều lệnh trong một lượt.
    $la_lo = isset($body[0]) && is_array($body[0]);
    $cac_lenh = $la_lo ? $body : [$body];
    $tra = [];

    foreach ($cac_lenh as $lenh) {
        $id  = $lenh['id'] ?? null;
        $pt  = (string) ($lenh['method'] ?? '');
        $ps  = isset($lenh['params']) && is_array($lenh['params']) ? $lenh['params'] : [];

        switch ($pt) {
        case 'initialize':
            $tra[] = gn_mcp_ket_qua($id, [
                'protocolVersion' => isset($ps['protocolVersion']) ? (string) $ps['protocolVersion'] : GN_MCP_PROTO,
                'capabilities' => ['tools' => ['listChanged' => false]],
                'serverInfo' => ['name' => 'ganhngon-mcp', 'version' => '1.0.0'],
                'instructions' =>
                    "Số liệu nhà hàng Gánh Ngon Phú Quốc.\n"
                  . "Mọi số tiền là SỐ NGUYÊN ĐỒNG. Mọi ngày là YYYY-MM-DD theo giờ Việt Nam (Asia/Ho_Chi_Minh).\n"
                  . "Hoa hồng đối tác luỹ tiến theo doanh số TỪNG NGÀY: 0-5tr 10%, 5-10tr 12%, trên 10tr 15%; "
                  . "cộng 2% tổng doanh số tháng nếu tháng đạt 100 triệu. gn_tinh_hoa_hong là máy tính DUY NHẤT, đừng tự tính lại.\n"
                  . "Bốn tool gn_chot_doanh_so, gn_thu_tien_voucher, gn_tru_voucher, gn_tam_dung_doi_tac đụng tiền thật "
                  . "và cần người duyệt. Mọi tool ghi đều bắt buộc idempotency_key.",
            ]);
            break;

        case 'notifications/initialized':
            break;   // thông báo, không trả lời

        case 'ping':
            $tra[] = gn_mcp_ket_qua($id, new stdClass());
            break;

        case 'tools/list':
            $tra[] = gn_mcp_ket_qua($id, ['tools' => gn_mcp_tools()]);
            break;

        case 'tools/call': {
            $ten  = (string) ($ps['name'] ?? '');
            $args = isset($ps['arguments']) && is_array($ps['arguments']) ? $ps['arguments'] : [];
            $hop_le = false;
            foreach (gn_mcp_tools() as $t) { if ($t['name'] === $ten) { $hop_le = true; break; } }
            if (!$hop_le) { $tra[] = gn_mcp_loi($id, -32602, 'Không có tool tên ' . $ten); break; }

            try {
                $kq = gn_mcp_goi_tool($ten, $args);
            } catch (\Throwable $e) {
                // Lỗi trả về trong result với isError, KHÔNG ném lỗi giao thức —
                // để AI đọc được nguyên nhân thay vì chỉ thấy "gọi hỏng".
                $kq = ['loi' => 'Lỗi khi chạy tool: ' . $e->getMessage()];
            }
            $co_loi = isset($kq['loi']);
            $tra[] = gn_mcp_ket_qua($id, [
                'content' => [['type' => 'text', 'text' => wp_json_encode($kq, JSON_UNESCAPED_UNICODE | JSON_PRETTY_PRINT)]],
                'isError' => $co_loi,
            ]);
            break;
        }

        default:
            $tra[] = gn_mcp_loi($id, -32601, 'Không hỗ trợ method ' . $pt);
        }
    }

    if (!$tra) { return new WP_REST_Response(null, 204); }   // toàn thông báo
    return new WP_REST_Response($la_lo ? $tra : $tra[0], 200);
}

/* ═══════════════════════════════════════════════════════════════════════════
   MÀN KIỂM TRA TRONG WP-ADMIN
   ═══════════════════════════════════════════════════════════════════════════ */


/* ═══════════════════════════════════════════════════════════════════════════
   ĐẨY SỰ KIỆN SANG WCC (webhook một chiều)
   --------------------------------------------------------------------------
   Không bao giờ nằm trong luồng phục vụ khách: có chuyện thì ghi hàng đợi rồi
   trả trang ngay, một tiến trình nền đẩy sau. Khách đặt bàn xong phải thấy "đã
   nhận" kể cả khi WCC đang tắt.
   ═══════════════════════════════════════════════════════════════════════════ */

const GN_WCC_QUEUE = 'gn_wcc_queue';
const GN_WCC_CRON  = 'gn_wcc_retry';
const GN_WCC_MAX   = 100;

function gn_wcc_webhook() { return trim((string) get_option('gn_wcc_webhook', '')); }
function gn_wcc_bat()     { return get_option('gn_wcc_enabled', '0') === '1'; }

/** Bắn một sự kiện. UUID chống trùng để WCC bỏ qua bản gửi lại. */
function gn_wcc_event($loai, array $data) {
    if (!gn_wcc_bat()) return;
    $payload = [
        'su_kien'    => $loai,
        'su_kien_id' => wp_generate_uuid4(),
        'tz'         => 'Asia/Ho_Chi_Minh',
        'site'       => home_url(),
        'gui_luc'    => (new DateTime('now', new DateTimeZone('Asia/Ho_Chi_Minh')))->format('c'),
        'du_lieu'    => $data,
    ];
    gn_wcc_gui($payload, true);
}

function gn_wcc_gui(array $payload, $lan_dau = true) {
    $url = gn_wcc_webhook();
    if ($url === '') return false;
    $token = gn_wcc_token();
    $res = wp_remote_post($url, [
        'timeout'  => 8,
        'blocking' => true,
        'headers'  => [
            'Content-Type'  => 'application/json; charset=utf-8',
            'Authorization' => $token !== '' ? 'Bearer ' . $token : '',
        ],
        'body' => wp_json_encode($payload, JSON_UNESCAPED_UNICODE),
    ]);
    if (is_wp_error($res)) { if ($lan_dau) gn_wcc_xep_hang($payload); return false; }
    $ma = (int) wp_remote_retrieve_response_code($res);
    if ($ma >= 200 && $ma < 300) return true;
    if ($lan_dau && ($ma >= 500 || $ma === 429)) gn_wcc_xep_hang($payload);
    return false;
}

function gn_wcc_xep_hang(array $payload) {
    $q = get_option(GN_WCC_QUEUE, []);
    if (!is_array($q)) $q = [];
    if (count($q) >= GN_WCC_MAX) array_shift($q);
    $q[] = $payload;
    update_option(GN_WCC_QUEUE, $q, false);
    if (!wp_next_scheduled(GN_WCC_CRON)) wp_schedule_single_event(time() + 300, GN_WCC_CRON);
}

add_action(GN_WCC_CRON, function () {
    $q = get_option(GN_WCC_QUEUE, []);
    if (!is_array($q) || !$q) return;
    $con = [];
    foreach ($q as $p) if (!gn_wcc_gui($p, false)) $con[] = $p;
    update_option(GN_WCC_QUEUE, $con, false);
    if ($con && !wp_next_scheduled(GN_WCC_CRON)) wp_schedule_single_event(time() + 900, GN_WCC_CRON);
});

/* ── Móc 8 sự kiện vào các hành động đã có sẵn trong theme ── */

add_action('gn_booking_created', function ($booking_id, $code, $ref) {
    global $wpdb;
    $b = $wpdb->get_row($wpdb->prepare("SELECT * FROM " . gn_tbl('bookings') . " WHERE id = %d", $booking_id));
    if (!$b) return;
    gn_wcc_event('dat_ban.tao', [
        'ma_don' => $b->booking_code, 'khach' => $b->customer_name, 'dien_thoai' => $b->customer_phone,
        'email' => $b->customer_email, 'ngay' => $b->booking_date, 'so_khach' => (int) $b->guests,
        'cho_ngoi' => $b->guest_type, 'ghi_chu' => $b->notes, 'ma_doi_tac' => $b->ref_code ?: null,
    ]);
    if ((int) $b->guests >= 10) {
        gn_wcc_event('doan.lon', ['ma_don' => $b->booking_code, 'so_khach' => (int) $b->guests,
            'ngay' => $b->booking_date, 'ghi_chu' => $b->notes]);
    }
}, 20, 3);

add_action('gn_booking_settled', function ($booking_id, $revenue, $ref_code, $day_revenue) {
    global $wpdb;
    $b = $wpdb->get_row($wpdb->prepare("SELECT booking_code, served_on FROM " . gn_tbl('bookings') . " WHERE id = %d", $booking_id));
    gn_wcc_event('dat_ban.chot', [
        'ma_don' => $b ? $b->booking_code : null, 'doanh_so' => (int) round($revenue),
        'ngay_phuc_vu' => $b ? $b->served_on : null, 'ma_doi_tac' => $ref_code ?: null,
        'doanh_so_ngay_doi_tac' => (int) round($day_revenue),
        'hoa_hong_ngay' => $ref_code ? (int) gn_commission_for_day($day_revenue) : 0,
    ]);
}, 20, 4);

add_action('gn_partner_registered', function ($ref, $name, $phone, $type) {
    gn_wcc_event('doi_tac.dang_ky', ['ma' => $ref, 'ten' => $name, 'dien_thoai' => $phone, 'loai' => $type]);
}, 20, 4);

add_action('gn_voucher_issued', function ($voucher_id) {
    global $wpdb;
    $v = $wpdb->get_row($wpdb->prepare("SELECT * FROM " . gn_tbl('vouchers') . " WHERE id = %d", $voucher_id));
    if ($v) gn_wcc_event('voucher.phat_hanh', ['ma' => $v->code, 'menh_gia' => (int) round($v->face_value),
        'gia' => (int) round($v->price), 'ma_doi_tac' => $v->ref_code ?: null, 'giu_den' => $v->hold_until]);
}, 20, 1);

add_action('gn_voucher_paid', function ($voucher_id) {
    global $wpdb;
    $v = $wpdb->get_row($wpdb->prepare("SELECT * FROM " . gn_tbl('vouchers') . " WHERE id = %d", $voucher_id));
    if ($v) gn_wcc_event('voucher.thanh_toan', ['ma' => $v->code, 'da_thu' => (int) round($v->price),
        'ma_doi_tac' => $v->ref_code ?: null]);
}, 20, 1);

add_action('gn_voucher_redeemed', function ($voucher_id, $used, $left) {
    global $wpdb;
    $v = $wpdb->get_row($wpdb->prepare("SELECT code, ref_code FROM " . gn_tbl('vouchers') . " WHERE id = %d", $voucher_id));
    if ($v) gn_wcc_event('voucher.su_dung', ['ma' => $v->code, 'da_dung' => (int) round($used),
        'con_lai' => (int) round($left), 'ma_doi_tac' => $v->ref_code ?: null]);
}, 20, 3);

/* ═══════════════════════════════════════════════════════════════════════════
   TRANG KẾT NỐI WCC — một nút bật/tắt
   ═══════════════════════════════════════════════════════════════════════════ */

add_action('admin_menu', function () {
    add_submenu_page('gn-home', 'Kết nối WCC', 'Kết nối WCC', 'manage_options', 'gn-wcc', 'gn_wcc_admin');
}, 20);

function gn_wcc_admin() {
    if (!current_user_can('manage_options')) wp_die('Không có quyền');

    if (isset($_POST['gn_wcc_act']) && check_admin_referer('gn_wcc')) {
        $act = sanitize_text_field($_POST['gn_wcc_act']);
        if ($act === 'bat') {
            if (get_option('gn_wcc_token', '') === '' && !defined('GN_MCP_TOKEN')) {
                update_option('gn_wcc_token', 'wcc_' . wp_generate_password(40, false, false), false);
            }
            update_option('gn_wcc_webhook', esc_url_raw($_POST['webhook'] ?? ''), false);
            update_option('gn_wcc_enabled', '1', false);
            echo '<div class="notice notice-success"><p>Đã bật kết nối WCC.</p></div>';
        } elseif ($act === 'tat') {
            update_option('gn_wcc_enabled', '0', false);
            echo '<div class="notice notice-warning"><p>Đã tắt kết nối. Token và cấu hình vẫn giữ, bật lại là chạy.</p></div>';
        } elseif ($act === 'token_moi') {
            update_option('gn_wcc_token', 'wcc_' . wp_generate_password(40, false, false), false);
            echo '<div class="notice notice-success"><p>Đã cấp token mới. Cập nhật lại bên WCC — token cũ hết hiệu lực.</p></div>';
        } elseif ($act === 'thu') {
            $old = get_option('gn_wcc_enabled', '0');
            update_option('gn_wcc_enabled', '1', false);
            $ok = gn_wcc_gui(['su_kien' => 'ket_noi.thu', 'su_kien_id' => wp_generate_uuid4(),
                'site' => home_url(), 'du_lieu' => ['thong_diep' => 'Ganh Ngon gui thu']], false);
            update_option('gn_wcc_enabled', $old, false);
            echo $ok
                ? '<div class="notice notice-success"><p>WCC nhận được. Webhook thông.</p></div>'
                : '<div class="notice notice-error"><p>WCC chưa nhận được — kiểm tra lại URL webhook và token bên WCC.</p></div>';
        }
    }

    $bat = gn_wcc_bat();
    $token = gn_wcc_token();
    $webhook = gn_wcc_webhook();
    $mcp_url = rest_url(GN_MCP_NS . '/rpc');
    $con_hang = count((array) get_option(GN_WCC_QUEUE, []));
    $tools = gn_mcp_tools();
    ?>
    <div class="wrap" style="max-width:1000px">
      <h1>Kết nối Work Command Center</h1>
      <p style="font-size:14px;color:#50575e">Nối hai chiều: Gánh Ngon đẩy sự kiện (đặt bàn, voucher, hoa hồng)
        sang WCC, và WCC gọi ngược vào để đọc số liệu lẫn ra lệnh — mọi lệnh đụng tiền đều qua người duyệt bên WCC.</p>

      <div class="card" style="max-width:none;padding:20px 24px">
        <h2 style="margin-top:0">Trạng thái:
          <?php echo $bat ? '<span style="color:#1E7A4C">● ĐANG BẬT</span>' : '<span style="color:#B45309">○ ĐANG TẮT</span>'; ?>
        </h2>
        <form method="post"><?php wp_nonce_field('gn_wcc'); ?>
          <table class="form-table">
            <tr><th>URL webhook của WCC</th>
              <td><input type="url" name="webhook" value="<?php echo esc_attr($webhook); ?>"
                    class="large-text" placeholder="https://wcc.../api/webhooks/&lt;token&gt;/">
                <p class="description">Lấy từ WCC: Cài đặt → Kết nối MCP / API → nguồn webhook. Nơi Gánh Ngon đẩy sự kiện tới.</p></td></tr>
          </table>
          <?php if (!$bat): ?>
            <button class="button button-primary button-hero" name="gn_wcc_act" value="bat">Bật kết nối</button>
          <?php else: ?>
            <button class="button button-primary" name="gn_wcc_act" value="bat">Lưu URL</button>
            <button class="button" name="gn_wcc_act" value="thu">Gửi thử sang WCC</button>
            <button class="button" name="gn_wcc_act" value="tat"
              onclick="return confirm('Tắt kết nối? Sự kiện sẽ ngừng đẩy sang WCC.')">Tắt kết nối</button>
          <?php endif; ?>
        </form>
      </div>

      <?php if ($token !== ''): ?>
      <div class="card" style="max-width:none;padding:20px 24px">
        <h2 style="margin-top:0">Khai vào WCC để nó gọi ngược lại</h2>
        <p>Bên WCC: Cài đặt → Kết nối MCP / API → thêm máy chủ MCP với đúng ba dòng sau:</p>
        <table class="widefat striped" style="max-width:760px">
          <tbody>
            <tr><th style="width:150px">transport</th><td><code>http</code></td></tr>
            <tr><th>url</th><td><code><?php echo esc_html($mcp_url); ?></code></td></tr>
            <tr><th>headers</th><td><code>{"Authorization": "Bearer <?php echo esc_html($token); ?>"}</code></td></tr>
          </tbody>
        </table>
        <p style="margin-top:12px">
          <?php if (!defined('GN_MCP_TOKEN')): ?>
          <form method="post" style="display:inline"><?php wp_nonce_field('gn_wcc'); ?>
            <button class="button" name="gn_wcc_act" value="token_moi"
              onclick="return confirm('Cấp token mới? Phải cập nhật lại bên WCC, token cũ hết hiệu lực ngay.')">Cấp token mới</button>
          </form>
          <?php else: ?>
          <span class="description">Token đang lấy từ hằng số GN_MCP_TOKEN trong wp-config.php.</span>
          <?php endif; ?>
        </p>
      </div>
      <?php endif; ?>

      <div class="card" style="max-width:none;padding:20px 24px">
        <h2 style="margin-top:0"><?php echo count($tools); ?> việc WCC làm được với Gánh Ngon</h2>
        <?php if ($con_hang > 0): ?>
          <div class="notice notice-warning inline"><p><b><?php echo $con_hang; ?> sự kiện</b> đang chờ đẩy lại
            (WCC vừa bận hoặc chưa cấu hình đúng). Hệ thống tự thử lại, không mất.</p></div>
        <?php endif; ?>
        <table class="widefat striped">
          <thead><tr><th style="width:210px">Việc</th><th>Mô tả</th><th style="width:130px">Mức duyệt</th></tr></thead>
          <tbody>
          <?php foreach ($tools as $t):
            $tien = strpos($t['description'], 'ĐỤNG TIỀN') === 0;
            $ghi  = strpos($t['description'], 'GHI DỮ LIỆU') === 0; ?>
            <tr>
              <td><code><?php echo esc_html($t['name']); ?></code></td>
              <td><?php echo esc_html($t['description']); ?></td>
              <td><?php echo $tien ? '<b style="color:#B42318">Cần người duyệt</b>'
                    : ($ghi ? '<span style="color:#B45309">Nhắc rồi chạy</span>'
                            : '<span style="color:#1E7A4C">Tự động</span>'); ?></td>
            </tr>
          <?php endforeach; ?>
          </tbody>
        </table>
        <div class="notice notice-info inline" style="margin-top:14px"><p>
          Bốn việc đụng tiền khi WCC dò thấy sẽ mặc định <b>bị chặn</b> cho tới khi người vận hành WCC gán mức —
          đó là ý đồ "AI làm, người duyệt". Không có việc xoá đối tác qua WCC; xoá chỉ làm tay ở đây.</p></div>
      </div>
    </div>
    <?php
}

/* GN — KẾT NỐI WCC END */
